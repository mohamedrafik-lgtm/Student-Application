import type { NextConfig } from "next";

const nextConfig: NextConfig = {
	outputFileTracingRoot: process.env.INIT_CWD || process.cwd(),
};

export default nextConfig;
