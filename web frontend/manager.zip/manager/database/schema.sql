CREATE DATABASE IF NOT EXISTS tiba_manager
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE tiba_manager;

CREATE TABLE IF NOT EXISTS users (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  full_name VARCHAR(120) NOT NULL,
  email VARCHAR(190) NULL,
  phone VARCHAR(30) NULL,
  role ENUM('admin', 'user') NOT NULL DEFAULT 'user',
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email (email),
  UNIQUE KEY uq_users_phone (phone),
  CONSTRAINT chk_users_email_or_phone CHECK (email IS NOT NULL OR phone IS NOT NULL)
);

CREATE TABLE IF NOT EXISTS sessions (
  sid CHAR(36) NOT NULL,
  user_id BIGINT UNSIGNED NOT NULL,
  expires_at DATETIME NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (sid),
  UNIQUE KEY uq_sessions_user_id (user_id),
  KEY idx_sessions_user_id (user_id),
  KEY idx_sessions_expires_at (expires_at),
  CONSTRAINT fk_sessions_user FOREIGN KEY (user_id)
    REFERENCES users(id)
    ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS seed_history (
  name VARCHAR(180) NOT NULL,
  executed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (name)
);

CREATE TABLE IF NOT EXISTS programs (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(160) NOT NULL,
  description LONGTEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_programs_name (name)
);

CREATE TABLE IF NOT EXISTS plans (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  program_id BIGINT UNSIGNED NOT NULL,
  name VARCHAR(160) NOT NULL,
  description LONGTEXT NOT NULL,
  price_egp DECIMAL(10,2) NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  duration_code ENUM('unspecified', 'month_1', 'month_3', 'month_6', 'year_1', 'year_2', 'year_3', 'custom') NOT NULL DEFAULT 'unspecified',
  duration_custom_label VARCHAR(120) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_plans_program_id (program_id),
  KEY idx_plans_is_active (is_active),
  UNIQUE KEY uq_plans_program_name (program_id, name),
  CONSTRAINT fk_plans_program FOREIGN KEY (program_id)
    REFERENCES programs(id)
    ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS payment_methods (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  method_code ENUM('vodafone_cash') NOT NULL DEFAULT 'vodafone_cash',
  phone_number VARCHAR(30) NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_payment_method_code_phone (method_code, phone_number),
  KEY idx_payment_methods_active (is_active)
);

CREATE TABLE IF NOT EXISTS purchases (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id BIGINT UNSIGNED NOT NULL,
  plan_id BIGINT UNSIGNED NOT NULL,
  payment_method_id BIGINT UNSIGNED NULL,
  payment_method_code ENUM('vodafone_cash') NOT NULL DEFAULT 'vodafone_cash',
  payment_phone_to VARCHAR(30) NOT NULL,
  transfer_from_phone VARCHAR(30) NOT NULL,
  amount_egp DECIMAL(10,2) NOT NULL,
  status ENUM('in_review', 'preparing', 'approved', 'rejected') NOT NULL DEFAULT 'in_review',
  admin_note VARCHAR(255) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_purchases_user_id (user_id),
  KEY idx_purchases_plan_id (plan_id),
  KEY idx_purchases_status (status),
  KEY idx_purchases_payment_method_id (payment_method_id),
  CONSTRAINT fk_purchases_user FOREIGN KEY (user_id)
    REFERENCES users(id)
    ON DELETE CASCADE,
  CONSTRAINT fk_purchases_plan FOREIGN KEY (plan_id)
    REFERENCES plans(id)
    ON DELETE CASCADE,
  CONSTRAINT fk_purchases_payment_method FOREIGN KEY (payment_method_id)
    REFERENCES payment_methods(id)
    ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS purchase_messages (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  purchase_id BIGINT UNSIGNED NOT NULL,
  sender_user_id BIGINT UNSIGNED NOT NULL,
  sender_role ENUM('admin', 'user') NOT NULL,
  message_text TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_purchase_messages_purchase_id (purchase_id),
  KEY idx_purchase_messages_sender_user_id (sender_user_id),
  CONSTRAINT fk_purchase_messages_purchase FOREIGN KEY (purchase_id)
    REFERENCES purchases(id)
    ON DELETE CASCADE,
  CONSTRAINT fk_purchase_messages_sender_user FOREIGN KEY (sender_user_id)
    REFERENCES users(id)
    ON DELETE CASCADE
);
