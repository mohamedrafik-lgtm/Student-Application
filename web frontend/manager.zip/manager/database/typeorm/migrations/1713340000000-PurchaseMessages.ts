import type { MigrationInterface, QueryRunner } from "typeorm";

export class PurchaseMessages1713340000000 implements MigrationInterface {
  public readonly name = "PurchaseMessages1713340000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE IF NOT EXISTS purchase_messages (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        purchase_id BIGINT UNSIGNED NOT NULL,
        sender_user_id BIGINT UNSIGNED NOT NULL,
        sender_role ENUM('admin', 'user') NOT NULL,
        message_text TEXT NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_purchase_messages_purchase_id (purchase_id),
        KEY idx_purchase_messages_sender_user_id (sender_user_id),
        CONSTRAINT fk_purchase_messages_purchase FOREIGN KEY (purchase_id)
          REFERENCES purchases(id)
          ON DELETE CASCADE,
        CONSTRAINT fk_purchase_messages_sender_user FOREIGN KEY (sender_user_id)
          REFERENCES users(id)
          ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
    );
  }

  public async down(): Promise<void> {
    // Intentionally left empty to avoid destructive rollback in production.
  }
}
