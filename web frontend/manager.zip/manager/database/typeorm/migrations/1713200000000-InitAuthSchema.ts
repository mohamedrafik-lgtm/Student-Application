import type { MigrationInterface, QueryRunner } from "typeorm";

export class InitAuthSchema1713200000000 implements MigrationInterface {
  public readonly name = "InitAuthSchema1713200000000";

  private async columnExists(
    queryRunner: QueryRunner,
    tableName: string,
    columnName: string,
  ): Promise<boolean> {
    const schemaName = String(queryRunner.connection.options.database ?? "");

    const rows = (await queryRunner.query(
      `SELECT COUNT(*) AS count
       FROM information_schema.COLUMNS
       WHERE TABLE_SCHEMA = ?
         AND TABLE_NAME = ?
         AND COLUMN_NAME = ?`,
      [schemaName, tableName, columnName],
    )) as Array<{ count: number | string }>;

    return Number(rows[0]?.count ?? 0) > 0;
  }

  private async indexExists(
    queryRunner: QueryRunner,
    tableName: string,
    indexName: string,
  ): Promise<boolean> {
    const schemaName = String(queryRunner.connection.options.database ?? "");

    const rows = (await queryRunner.query(
      `SELECT COUNT(*) AS count
       FROM information_schema.STATISTICS
       WHERE TABLE_SCHEMA = ?
         AND TABLE_NAME = ?
         AND INDEX_NAME = ?`,
      [schemaName, tableName, indexName],
    )) as Array<{ count: number | string }>;

    return Number(rows[0]?.count ?? 0) > 0;
  }

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE IF NOT EXISTS users (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        full_name VARCHAR(120) NOT NULL,
        email VARCHAR(190) NULL,
        phone VARCHAR(30) NULL,
        role ENUM('admin', 'user') NOT NULL DEFAULT 'user',
        password_hash VARCHAR(255) NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_users_email (email),
        UNIQUE KEY uq_users_phone (phone),
        CONSTRAINT chk_users_email_or_phone CHECK (email IS NOT NULL OR phone IS NOT NULL)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
    );

    if (!(await this.columnExists(queryRunner, "users", "role"))) {
      await queryRunner.query(
        `ALTER TABLE users
         ADD COLUMN role ENUM('admin', 'user') NOT NULL DEFAULT 'user'
         AFTER phone`,
      );
    }

    await queryRunner.query(
      `UPDATE users
       SET role = 'user'
       WHERE role IS NULL OR role = ''`,
    );

    await queryRunner.query(
      `CREATE TABLE IF NOT EXISTS sessions (
        sid CHAR(36) NOT NULL,
        user_id BIGINT UNSIGNED NOT NULL,
        expires_at DATETIME NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (sid),
        KEY idx_sessions_user_id (user_id),
        KEY idx_sessions_expires_at (expires_at),
        CONSTRAINT fk_sessions_user FOREIGN KEY (user_id)
          REFERENCES users(id)
          ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
    );

    if (!(await this.indexExists(queryRunner, "sessions", "uq_sessions_user_id"))) {
      await queryRunner.query(
        `DELETE s1
         FROM sessions s1
         INNER JOIN sessions s2
           ON s1.user_id = s2.user_id
          AND (
            s1.expires_at < s2.expires_at
            OR (s1.expires_at = s2.expires_at AND s1.sid < s2.sid)
          )`,
      );

      await queryRunner.query(
        `ALTER TABLE sessions
         ADD CONSTRAINT uq_sessions_user_id UNIQUE (user_id)`,
      );
    }

    await queryRunner.query(
      `CREATE TABLE IF NOT EXISTS seed_history (
        name VARCHAR(180) NOT NULL,
        executed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (name)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
    );
  }

  public async down(): Promise<void> {
    // Intentionally left empty to avoid destructive rollback in production.
  }
}
