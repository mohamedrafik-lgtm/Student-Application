import type { MigrationInterface, QueryRunner } from "typeorm";

export class PaymentMethodsAndPurchases1713330000000 implements MigrationInterface {
  public readonly name = "PaymentMethodsAndPurchases1713330000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE IF NOT EXISTS payment_methods (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        method_code ENUM('vodafone_cash') NOT NULL DEFAULT 'vodafone_cash',
        phone_number VARCHAR(30) NOT NULL,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_payment_method_code_phone (method_code, phone_number),
        KEY idx_payment_methods_active (is_active)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
    );

    await queryRunner.query(
      `CREATE TABLE IF NOT EXISTS purchases (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        plan_id BIGINT UNSIGNED NOT NULL,
        payment_method_id BIGINT UNSIGNED NULL,
        payment_method_code ENUM('vodafone_cash') NOT NULL DEFAULT 'vodafone_cash',
        payment_phone_to VARCHAR(30) NOT NULL,
        transfer_from_phone VARCHAR(30) NOT NULL,
        amount_egp DECIMAL(10,2) NOT NULL,
        status ENUM('in_review', 'preparing', 'approved', 'rejected') NOT NULL DEFAULT 'in_review',
        admin_note VARCHAR(255) NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_purchases_user_id (user_id),
        KEY idx_purchases_plan_id (plan_id),
        KEY idx_purchases_status (status),
        KEY idx_purchases_payment_method_id (payment_method_id),
        CONSTRAINT fk_purchases_user FOREIGN KEY (user_id)
          REFERENCES users(id)
          ON DELETE CASCADE,
        CONSTRAINT fk_purchases_plan FOREIGN KEY (plan_id)
          REFERENCES plans(id)
          ON DELETE CASCADE,
        CONSTRAINT fk_purchases_payment_method FOREIGN KEY (payment_method_id)
          REFERENCES payment_methods(id)
          ON DELETE SET NULL
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
    );
  }

  public async down(): Promise<void> {
    // Intentionally left empty to avoid destructive rollback in production.
  }
}
