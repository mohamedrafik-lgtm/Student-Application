import type { MigrationInterface, QueryRunner } from "typeorm";

export class ProgramDescriptionLongText1713310000000 implements MigrationInterface {
  public readonly name = "ProgramDescriptionLongText1713310000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE programs
       MODIFY COLUMN description LONGTEXT NOT NULL`,
    );
  }

  public async down(): Promise<void> {
    // Intentionally left empty to avoid destructive rollback in production.
  }
}
