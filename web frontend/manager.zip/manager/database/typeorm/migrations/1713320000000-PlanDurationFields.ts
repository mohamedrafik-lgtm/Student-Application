import type { MigrationInterface, QueryRunner } from "typeorm";

export class PlanDurationFields1713320000000 implements MigrationInterface {
  public readonly name = "PlanDurationFields1713320000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE plans
       ADD COLUMN duration_code ENUM('unspecified', 'month_1', 'month_3', 'month_6', 'year_1', 'year_2', 'year_3', 'custom') NOT NULL DEFAULT 'unspecified' AFTER is_active,
       ADD COLUMN duration_custom_label VARCHAR(120) NULL AFTER duration_code`,
    );

    await queryRunner.query(
      `UPDATE plans
       SET duration_code = 'unspecified',
           duration_custom_label = NULL
       WHERE duration_code IS NULL OR duration_code = ''`,
    );
  }

  public async down(): Promise<void> {
    // Intentionally left empty to avoid destructive rollback in production.
  }
}
