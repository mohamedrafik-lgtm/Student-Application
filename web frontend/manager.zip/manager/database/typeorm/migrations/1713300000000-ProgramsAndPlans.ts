import type { MigrationInterface, QueryRunner } from "typeorm";

export class ProgramsAndPlans1713300000000 implements MigrationInterface {
  public readonly name = "ProgramsAndPlans1713300000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE IF NOT EXISTS programs (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        name VARCHAR(160) NOT NULL,
        description TEXT NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_programs_name (name)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
    );

    await queryRunner.query(
      `CREATE TABLE IF NOT EXISTS plans (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        program_id BIGINT UNSIGNED NOT NULL,
        name VARCHAR(160) NOT NULL,
        description LONGTEXT NOT NULL,
        price_egp DECIMAL(10,2) NOT NULL,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_plans_program_id (program_id),
        KEY idx_plans_is_active (is_active),
        UNIQUE KEY uq_plans_program_name (program_id, name),
        CONSTRAINT fk_plans_program FOREIGN KEY (program_id)
          REFERENCES programs(id)
          ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
    );
  }

  public async down(): Promise<void> {
    // Intentionally left empty to avoid destructive rollback in production.
  }
}
