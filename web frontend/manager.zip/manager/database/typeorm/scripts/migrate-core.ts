import { appDataSource } from "../data-source";
import { ensureDatabaseExists } from "./create-database";

export async function applyMigrations(options?: {
  destroyAfter?: boolean;
}): Promise<number> {
  const destroyAfter = options?.destroyAfter ?? true;

  await ensureDatabaseExists();

  if (!appDataSource.isInitialized) {
    await appDataSource.initialize();
  }

  try {
    const results = await appDataSource.runMigrations({ transaction: "all" });
    return results.length;
  } finally {
    if (destroyAfter && appDataSource.isInitialized) {
      await appDataSource.destroy();
    }
  }
}
