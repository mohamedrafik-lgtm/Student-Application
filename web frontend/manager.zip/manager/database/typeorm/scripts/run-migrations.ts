import { applyMigrations } from "./migrate-core";

async function main() {
  const count = await applyMigrations({ destroyAfter: true });

  if (count === 0) {
    console.log("No pending migrations.");
    return;
  }

  console.log(`Applied ${count} migration(s).`);
}

main().catch((error) => {
  console.error("Migration run failed:", error);
  process.exitCode = 1;
});
