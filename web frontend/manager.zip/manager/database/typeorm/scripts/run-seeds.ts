import { appDataSource } from "../data-source";
import { AdminAccountSeeder } from "../seeds/admin-account.seeder";
import { ensureDatabaseExists } from "./create-database";
import { applyMigrations } from "./migrate-core";
import type { EntityManager } from "typeorm";

interface Seeder {
  name: string;
  repeatable?: boolean;
  run: (manager: EntityManager) => Promise<void>;
}

const seeders: Seeder[] = [AdminAccountSeeder];

async function createSeedHistoryTable() {
  await appDataSource.query(
    `CREATE TABLE IF NOT EXISTS seed_history (
      name VARCHAR(180) NOT NULL,
      executed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  );
}

export async function runSeeders(): Promise<void> {
  await ensureDatabaseExists();
  await applyMigrations({ destroyAfter: false });

  if (!appDataSource.isInitialized) {
    await appDataSource.initialize();
  }

  try {
    await createSeedHistoryTable();

    for (const seeder of seeders) {
      const existing = (await appDataSource.query(
        `SELECT name FROM seed_history WHERE name = ? LIMIT 1`,
        [seeder.name],
      )) as Array<{ name: string }>;

      const shouldRun = seeder.repeatable || existing.length === 0;

      if (!shouldRun) {
        continue;
      }

      await appDataSource.transaction(async (manager) => {
        await seeder.run(manager);

        if (existing.length === 0) {
          await manager.query(
            `INSERT INTO seed_history (name) VALUES (?)`,
            [seeder.name],
          );
        } else {
          await manager.query(
            `UPDATE seed_history SET executed_at = CURRENT_TIMESTAMP WHERE name = ?`,
            [seeder.name],
          );
        }
      });

      console.log(`Seeder executed: ${seeder.name}`);
    }
  } finally {
    if (appDataSource.isInitialized) {
      await appDataSource.destroy();
    }
  }
}
