import { loadEnvConfig } from "@next/env";
import mysql from "mysql2/promise";
import { pathToFileURL } from "node:url";

loadEnvConfig(process.cwd());

function required(key: string): string {
  const value = process.env[key];
  if (!value) {
    throw new Error(`Missing required environment variable: ${key}`);
  }
  return value;
}

function safeDatabaseName(name: string): string {
  if (!/^[A-Za-z0-9_]+$/.test(name)) {
    throw new Error(
      "DB_NAME contains invalid characters. Allowed: letters, numbers, underscore.",
    );
  }

  return name;
}

export async function ensureDatabaseExists(): Promise<void> {
  const dbName = safeDatabaseName(required("DB_NAME"));
  const host = required("DB_HOST");
  const port = Number.parseInt(process.env.DB_PORT ?? "3306", 10);
  const user = required("DB_USER");
  const password = process.env.DB_PASSWORD ?? "";

  if (Number.isNaN(port)) {
    throw new Error("DB_PORT must be a valid number.");
  }

  const connection = await mysql.createConnection({
    host,
    port,
    user,
    password,
  });

  try {
    await connection.query(
      `CREATE DATABASE IF NOT EXISTS \`${dbName}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`,
    );
  } finally {
    await connection.end();
  }
}

async function main() {
  await ensureDatabaseExists();
  console.log("Database checked and ready.");
}

const directRunEntry = process.argv[1]
  ? pathToFileURL(process.argv[1]).href
  : null;

if (directRunEntry && import.meta.url === directRunEntry) {
  main().catch((error) => {
    console.error("Failed to create/check database:", error);
    process.exitCode = 1;
  });
}
