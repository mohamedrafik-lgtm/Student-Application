import "reflect-metadata";

import { loadEnvConfig } from "@next/env";
import { DataSource } from "typeorm";

import { InitAuthSchema1713200000000 } from "./migrations/1713200000000-InitAuthSchema";
import { ProgramsAndPlans1713300000000 } from "./migrations/1713300000000-ProgramsAndPlans";
import { ProgramDescriptionLongText1713310000000 } from "./migrations/1713310000000-ProgramDescriptionLongText";
import { PlanDurationFields1713320000000 } from "./migrations/1713320000000-PlanDurationFields";
import { PaymentMethodsAndPurchases1713330000000 } from "./migrations/1713330000000-PaymentMethodsAndPurchases";
import { PurchaseMessages1713340000000 } from "./migrations/1713340000000-PurchaseMessages";

loadEnvConfig(process.cwd());

const dbPort = Number.parseInt(process.env.DB_PORT ?? "3306", 10);

if (Number.isNaN(dbPort)) {
  throw new Error("DB_PORT must be a valid number for TypeORM DataSource.");
}

if (!process.env.DB_NAME) {
  throw new Error("DB_NAME is required for TypeORM DataSource.");
}

if (!process.env.DB_HOST || !process.env.DB_USER) {
  throw new Error("DB_HOST and DB_USER are required for TypeORM DataSource.");
}

export const appDataSource = new DataSource({
  type: "mysql",
  host: process.env.DB_HOST,
  port: dbPort,
  username: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  charset: "utf8mb4_unicode_ci",
  logging: false,
  synchronize: false,
  migrationsRun: false,
  migrationsTableName: "typeorm_migrations",
  migrations: [
    InitAuthSchema1713200000000,
    ProgramsAndPlans1713300000000,
    ProgramDescriptionLongText1713310000000,
    PlanDurationFields1713320000000,
    PaymentMethodsAndPurchases1713330000000,
    PurchaseMessages1713340000000,
  ],
});
