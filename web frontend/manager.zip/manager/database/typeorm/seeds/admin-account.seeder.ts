import bcrypt from "bcryptjs";
import type { EntityManager } from "typeorm";

export const AdminAccountSeeder = {
  name: "admin-account",
  repeatable: true,
  async run(manager: EntityManager): Promise<void> {
    const adminName = process.env.ADMIN_FULL_NAME ?? "TIBA Super Admin";
    const adminEmail = process.env.ADMIN_EMAIL ?? "admin@tibasoftware.com";
    const adminPhone = process.env.ADMIN_PHONE ?? "+201000000000";
    const adminPassword = process.env.ADMIN_PASSWORD;

    if (!adminPassword) {
      throw new Error("ADMIN_PASSWORD must be set before running seeders.");
    }

    const passwordHash = await bcrypt.hash(adminPassword, 12);

    const rows = (await manager.query(
      `SELECT id
       FROM users
       WHERE email = ? OR phone = ?
       LIMIT 1`,
      [adminEmail, adminPhone],
    )) as Array<{ id: number }>;

    const existing = rows[0];

    if (!existing) {
      await manager.query(
        `INSERT INTO users (full_name, email, phone, role, password_hash)
         VALUES (?, ?, ?, 'admin', ?)`,
        [adminName, adminEmail, adminPhone, passwordHash],
      );

      return;
    }

    await manager.query(
      `UPDATE users
       SET full_name = ?,
           email = ?,
           phone = ?,
           role = 'admin',
           password_hash = ?,
           updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`,
      [adminName, adminEmail, adminPhone, passwordHash, existing.id],
    );
  },
};
