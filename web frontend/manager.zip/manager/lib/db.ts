import mysql from "mysql2/promise";

import { env } from "@/lib/env";

const globalForDb = globalThis as typeof globalThis & {
  __tibaMysqlPool?: ReturnType<typeof mysql.createPool>;
};

const parsedPoolLimit = Number.parseInt(
  process.env.DB_POOL_CONNECTION_LIMIT ?? "4",
  10,
);

const connectionLimit = Number.isNaN(parsedPoolLimit)
  ? 4
  : Math.max(1, Math.min(parsedPoolLimit, 20));

const pool =
  globalForDb.__tibaMysqlPool ??
  mysql.createPool({
    host: env.DB_HOST,
    port: env.DB_PORT,
    user: env.DB_USER,
    password: env.DB_PASSWORD,
    database: env.DB_NAME,
    waitForConnections: true,
    connectionLimit,
    maxIdle: Math.max(1, Math.floor(connectionLimit / 2)),
    idleTimeout: 60_000,
    queueLimit: 0,
    enableKeepAlive: true,
    keepAliveInitialDelay: 0,
    timezone: "Z",
  });

if (env.NODE_ENV !== "production") {
  globalForDb.__tibaMysqlPool = pool;
}

export const db = pool;
