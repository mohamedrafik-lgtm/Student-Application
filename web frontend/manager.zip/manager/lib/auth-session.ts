import { cookies } from "next/headers";

import type { UserRole } from "@/lib/auth-types";
import {
  createSessionRecord,
  deleteExpiredSessions,
  deleteSessionRecord,
  getUserBySession,
  type AuthUser,
} from "@/lib/auth-db";
import {
  createSessionToken,
  getExpiredSessionCookieOptions,
  getSessionCookieOptions,
  SESSION_COOKIE_NAME,
  verifySessionToken,
} from "@/lib/session-token";

function isTooManyConnectionsError(error: unknown): boolean {
  return (
    typeof error === "object" &&
    error !== null &&
    "code" in error &&
    (error as { code?: string }).code === "ER_CON_COUNT_ERROR"
  );
}

export async function beginUserSession(
  userId: number,
  role: UserRole,
): Promise<void> {
  const { token, sid, expiresAt } = await createSessionToken(userId, role);

  await createSessionRecord({ sid, userId, expiresAt });

  const cookieStore = await cookies();
  cookieStore.set(SESSION_COOKIE_NAME, token, getSessionCookieOptions());
}

export async function endCurrentSession(): Promise<void> {
  const cookieStore = await cookies();
  const token = cookieStore.get(SESSION_COOKIE_NAME)?.value;

  if (token) {
    const payload = await verifySessionToken(token);
    if (payload) {
      await deleteSessionRecord(payload.sid);
    }
  }

  cookieStore.set(SESSION_COOKIE_NAME, "", getExpiredSessionCookieOptions());
}

export async function getUserFromSessionToken(
  token: string | undefined,
): Promise<AuthUser | null> {
  if (!token) {
    return null;
  }

  const payload = await verifySessionToken(token);
  if (!payload) {
    return null;
  }

  let user: AuthUser | null;

  try {
    await deleteExpiredSessions();
    user = await getUserBySession(payload.sid, payload.uid);
  } catch (error) {
    if (isTooManyConnectionsError(error)) {
      return null;
    }
    throw error;
  }

  if (!user) {
    return null;
  }

  return user;
}

export async function getCurrentUser(): Promise<AuthUser | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get(SESSION_COOKIE_NAME)?.value;
  return getUserFromSessionToken(token);
}
