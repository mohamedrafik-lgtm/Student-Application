import type { ResultSetHeader, RowDataPacket } from "mysql2/promise";

import { db } from "@/lib/db";
import type { UserRole } from "@/lib/auth-types";
import type { LoginInput } from "@/lib/validation";

interface UserPublicRow extends RowDataPacket {
  id: number;
  full_name: string;
  email: string | null;
  phone: string | null;
  role: UserRole;
  created_at: Date | string;
}

interface UserWithPasswordRow extends UserPublicRow {
  password_hash: string;
}

export interface AuthUser {
  id: number;
  fullName: string;
  email: string | null;
  phone: string | null;
  role: UserRole;
  createdAt: string;
}

export interface AuthUserWithPassword extends AuthUser {
  passwordHash: string;
}

export type AdminManagedUser = AuthUser;

function toIso(value: Date | string): string {
  if (value instanceof Date) {
    return value.toISOString();
  }
  return new Date(value).toISOString();
}

function mapPublicUser(row: UserPublicRow): AuthUser {
  return {
    id: row.id,
    fullName: row.full_name,
    email: row.email,
    phone: row.phone,
    role: row.role,
    createdAt: toIso(row.created_at),
  };
}

function mapUserWithPassword(row: UserWithPasswordRow): AuthUserWithPassword {
  return {
    ...mapPublicUser(row),
    passwordHash: row.password_hash,
  };
}

export async function getUserById(id: number): Promise<AuthUser | null> {
  const [rows] = await db.execute<UserPublicRow[]>(
    `SELECT id, full_name, email, phone, role, created_at
     FROM users
     WHERE id = ?
     LIMIT 1`,
    [id],
  );

  const row = rows[0];
  return row ? mapPublicUser(row) : null;
}

export async function getUserByEmail(email: string): Promise<AuthUser | null> {
  const [rows] = await db.execute<UserPublicRow[]>(
    `SELECT id, full_name, email, phone, role, created_at
     FROM users
     WHERE email = ?
     LIMIT 1`,
    [email],
  );

  const row = rows[0];
  return row ? mapPublicUser(row) : null;
}

export async function getUserByPhone(phone: string): Promise<AuthUser | null> {
  const [rows] = await db.execute<UserPublicRow[]>(
    `SELECT id, full_name, email, phone, role, created_at
     FROM users
     WHERE phone = ?
     LIMIT 1`,
    [phone],
  );

  const row = rows[0];
  return row ? mapPublicUser(row) : null;
}

export async function createUser(input: {
  fullName: string;
  email?: string;
  phone?: string;
  passwordHash: string;
  role?: UserRole;
}): Promise<AuthUser> {
  const [result] = await db.execute<ResultSetHeader>(
    `INSERT INTO users (full_name, email, phone, password_hash, role)
     VALUES (?, ?, ?, ?, ?)`,
    [
      input.fullName,
      input.email ? input.email : null,
      input.phone ? input.phone : null,
      input.passwordHash,
      input.role ?? "user",
    ],
  );

  const user = await getUserById(result.insertId);
  if (!user) {
    throw new Error("Failed to read created user.");
  }

  return user;
}

export async function getUserForLogin(
  identifierType: LoginInput["identifierType"],
  identifier: string,
): Promise<AuthUserWithPassword | null> {
  const fieldName = identifierType === "email" ? "email" : "phone";

  const [rows] = await db.execute<UserWithPasswordRow[]>(
    `SELECT id, full_name, email, phone, role, password_hash, created_at
     FROM users
     WHERE ${fieldName} = ?
     LIMIT 1`,
    [identifier],
  );

  const row = rows[0];
  return row ? mapUserWithPassword(row) : null;
}

export async function listUsersForAdmin(
  searchTerm?: string,
): Promise<AdminManagedUser[]> {
  const normalizedSearchTerm = (searchTerm ?? "").trim();

  const hasSearch = normalizedSearchTerm.length > 0;
  const searchValue = `%${normalizedSearchTerm.toLowerCase()}%`;

  const [rows] = hasSearch
    ? await db.execute<UserPublicRow[]>(
        `SELECT id, full_name, email, phone, role, created_at
         FROM users
         WHERE LOWER(full_name) LIKE ?
            OR LOWER(COALESCE(email, '')) LIKE ?
            OR LOWER(COALESCE(phone, '')) LIKE ?
         ORDER BY created_at DESC`,
        [searchValue, searchValue, searchValue],
      )
    : await db.execute<UserPublicRow[]>(
        `SELECT id, full_name, email, phone, role, created_at
         FROM users
         ORDER BY created_at DESC`,
      );

  return rows.map(mapPublicUser);
}

export async function updateUserRoleById(
  userId: number,
  role: UserRole,
): Promise<boolean> {
  const [result] = await db.execute<ResultSetHeader>(
    `UPDATE users
     SET role = ?,
         updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`,
    [role, userId],
  );

  return result.affectedRows > 0;
}

export async function createSessionRecord(input: {
  sid: string;
  userId: number;
  expiresAt: Date;
}): Promise<void> {
  await db.execute<ResultSetHeader>(
    `INSERT INTO sessions (sid, user_id, expires_at)
     VALUES (?, ?, ?)
     ON DUPLICATE KEY UPDATE
       sid = VALUES(sid),
       expires_at = VALUES(expires_at),
       created_at = CURRENT_TIMESTAMP`,
    [input.sid, input.userId, input.expiresAt],
  );
}

export async function deleteSessionRecord(sid: string): Promise<void> {
  await db.execute<ResultSetHeader>(
    `DELETE FROM sessions WHERE sid = ?`,
    [sid],
  );
}

export async function getUserBySession(
  sid: string,
  userId: number,
): Promise<AuthUser | null> {
  const [rows] = await db.execute<UserPublicRow[]>(
    `SELECT u.id, u.full_name, u.email, u.phone, u.role, u.created_at
     FROM sessions s
     INNER JOIN users u ON u.id = s.user_id
     WHERE s.sid = ?
       AND s.user_id = ?
       AND s.expires_at > UTC_TIMESTAMP()
     LIMIT 1`,
    [sid, userId],
  );

  const row = rows[0];
  return row ? mapPublicUser(row) : null;
}

export async function deleteExpiredSessions(): Promise<void> {
  await db.execute<ResultSetHeader>(
    `DELETE FROM sessions WHERE expires_at <= UTC_TIMESTAMP()`,
  );
}

interface AdminStatsRow extends RowDataPacket {
  users_count: number;
  admins_count: number;
  active_sessions_count: number;
}

export async function getAdminStats(): Promise<{
  usersCount: number;
  adminsCount: number;
  activeSessionsCount: number;
}> {
  const [rows] = await db.execute<AdminStatsRow[]>(
    `SELECT
      (SELECT COUNT(*) FROM users) AS users_count,
      (SELECT COUNT(*) FROM users WHERE role = 'admin') AS admins_count,
      (SELECT COUNT(*) FROM sessions WHERE expires_at > UTC_TIMESTAMP()) AS active_sessions_count`,
  );

  const row = rows[0];

  return {
    usersCount: row?.users_count ?? 0,
    adminsCount: row?.admins_count ?? 0,
    activeSessionsCount: row?.active_sessions_count ?? 0,
  };
}

