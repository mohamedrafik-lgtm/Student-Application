import type { RowDataPacket } from "mysql2/promise";

import { db } from "@/lib/db";
import { isPurchaseStatus, type PurchaseStatus } from "@/lib/purchase-types";

interface AdminBaseStatsRow extends RowDataPacket {
  users_count: number;
  admins_count: number;
  programs_count: number;
  active_plans_count: number;
}

interface PurchaseAggregateRow extends RowDataPacket {
  purchases_count: number;
  pending_purchases_count: number;
  approved_purchases_count: number;
  approved_revenue_egp: number | string;
}

interface AdminRecentPurchaseRow extends RowDataPacket {
  id: number;
  user_full_name: string;
  user_email: string | null;
  plan_name: string;
  status: string;
  created_at: Date | string;
}

interface UserPurchaseAggregateRow extends RowDataPacket {
  total_purchases: number;
  pending_purchases_count: number;
  approved_purchases_count: number;
  approved_revenue_egp: number | string;
}

interface UserRecentPurchaseRow extends RowDataPacket {
  id: number;
  plan_name: string;
  program_name: string;
  status: string;
  amount_egp: number | string;
  created_at: Date | string;
}

interface DashboardPurchaseItem {
  id: number;
  planName: string;
  programName: string | null;
  status: PurchaseStatus;
  amountEgp: number;
  createdAt: string;
}

export interface AdminDashboardData {
  usersCount: number;
  adminsCount: number;
  programsCount: number;
  activePlansCount: number;
  purchasesCount: number;
  pendingPurchasesCount: number;
  approvedPurchasesCount: number;
  approvedRevenueEgp: number;
  recentPurchases: Array<{
    id: number;
    userFullName: string;
    userEmail: string | null;
    planName: string;
    status: PurchaseStatus;
    createdAt: string;
  }>;
}

export interface UserDashboardData {
  totalPurchases: number;
  pendingPurchasesCount: number;
  approvedPurchasesCount: number;
  approvedRevenueEgp: number;
  recentPurchases: DashboardPurchaseItem[];
  latestApprovedPurchase: DashboardPurchaseItem | null;
}

function toIso(value: Date | string): string {
  if (value instanceof Date) {
    return value.toISOString();
  }

  return new Date(value).toISOString();
}

function isMissingTableError(error: unknown): boolean {
  return (
    typeof error === "object" &&
    error !== null &&
    "code" in error &&
    (error as { code?: string }).code === "ER_NO_SUCH_TABLE"
  );
}

export async function getAdminDashboardData(): Promise<AdminDashboardData> {
  const [baseRows] = await db.execute<AdminBaseStatsRow[]>(
    `SELECT
      (SELECT COUNT(*) FROM users) AS users_count,
      (SELECT COUNT(*) FROM users WHERE role = 'admin') AS admins_count,
      (SELECT COUNT(*) FROM programs) AS programs_count,
      (SELECT COUNT(*) FROM plans WHERE is_active = 1) AS active_plans_count`,
  );

  const base = baseRows[0];

  let purchaseStats: Pick<PurchaseAggregateRow, "purchases_count" | "pending_purchases_count" | "approved_purchases_count" | "approved_revenue_egp"> = {
    purchases_count: 0,
    pending_purchases_count: 0,
    approved_purchases_count: 0,
    approved_revenue_egp: 0,
  };

  let recentPurchases: AdminDashboardData["recentPurchases"] = [];

  try {
    const [purchaseStatsRows] = await db.execute<PurchaseAggregateRow[]>(
      `SELECT
        COUNT(*) AS purchases_count,
        SUM(CASE WHEN status IN ('in_review', 'preparing') THEN 1 ELSE 0 END) AS pending_purchases_count,
        SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) AS approved_purchases_count,
        COALESCE(SUM(CASE WHEN status = 'approved' THEN amount_egp ELSE 0 END), 0) AS approved_revenue_egp
       FROM purchases`,
    );

    purchaseStats = purchaseStatsRows[0] ?? purchaseStats;

    const [recentRows] = await db.execute<AdminRecentPurchaseRow[]>(
      `SELECT
        pr.id,
        u.full_name AS user_full_name,
        u.email AS user_email,
        pl.name AS plan_name,
        pr.status,
        pr.created_at
       FROM purchases pr
       INNER JOIN users u ON u.id = pr.user_id
       INNER JOIN plans pl ON pl.id = pr.plan_id
       ORDER BY pr.created_at DESC
       LIMIT 8`,
    );

    recentPurchases = recentRows.map((row) => ({
      id: row.id,
      userFullName: row.user_full_name,
      userEmail: row.user_email,
      planName: row.plan_name,
      status: isPurchaseStatus(row.status) ? row.status : "in_review",
      createdAt: toIso(row.created_at),
    }));
  } catch (error) {
    if (!isMissingTableError(error)) {
      throw error;
    }
  }

  return {
    usersCount: Number(base?.users_count ?? 0),
    adminsCount: Number(base?.admins_count ?? 0),
    programsCount: Number(base?.programs_count ?? 0),
    activePlansCount: Number(base?.active_plans_count ?? 0),
    purchasesCount: Number(purchaseStats.purchases_count ?? 0),
    pendingPurchasesCount: Number(purchaseStats.pending_purchases_count ?? 0),
    approvedPurchasesCount: Number(purchaseStats.approved_purchases_count ?? 0),
    approvedRevenueEgp: Number(purchaseStats.approved_revenue_egp ?? 0),
    recentPurchases,
  };
}

export async function getUserDashboardData(userId: number): Promise<UserDashboardData> {
  let aggregate: Pick<UserPurchaseAggregateRow, "total_purchases" | "pending_purchases_count" | "approved_purchases_count" | "approved_revenue_egp"> = {
    total_purchases: 0,
    pending_purchases_count: 0,
    approved_purchases_count: 0,
    approved_revenue_egp: 0,
  };

  let recentPurchases: DashboardPurchaseItem[] = [];

  try {
    const [aggregateRows] = await db.execute<UserPurchaseAggregateRow[]>(
      `SELECT
        COUNT(*) AS total_purchases,
        SUM(CASE WHEN status IN ('in_review', 'preparing') THEN 1 ELSE 0 END) AS pending_purchases_count,
        SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) AS approved_purchases_count,
        COALESCE(SUM(CASE WHEN status = 'approved' THEN amount_egp ELSE 0 END), 0) AS approved_revenue_egp
       FROM purchases
       WHERE user_id = ?`,
      [userId],
    );

    aggregate = aggregateRows[0] ?? aggregate;

    const [recentRows] = await db.execute<UserRecentPurchaseRow[]>(
      `SELECT
        pr.id,
        pl.name AS plan_name,
        pg.name AS program_name,
        pr.status,
        pr.amount_egp,
        pr.created_at
       FROM purchases pr
       INNER JOIN plans pl ON pl.id = pr.plan_id
       INNER JOIN programs pg ON pg.id = pl.program_id
       WHERE pr.user_id = ?
       ORDER BY pr.created_at DESC
       LIMIT 6`,
      [userId],
    );

    recentPurchases = recentRows.map((row) => ({
      id: row.id,
      planName: row.plan_name,
      programName: row.program_name,
      status: isPurchaseStatus(row.status) ? row.status : "in_review",
      amountEgp: Number(row.amount_egp),
      createdAt: toIso(row.created_at),
    }));
  } catch (error) {
    if (!isMissingTableError(error)) {
      throw error;
    }
  }

  const latestApprovedPurchase =
    recentPurchases.find((purchase) => purchase.status === "approved") ?? null;

  return {
    totalPurchases: Number(aggregate.total_purchases ?? 0),
    pendingPurchasesCount: Number(aggregate.pending_purchases_count ?? 0),
    approvedPurchasesCount: Number(aggregate.approved_purchases_count ?? 0),
    approvedRevenueEgp: Number(aggregate.approved_revenue_egp ?? 0),
    recentPurchases,
    latestApprovedPurchase,
  };
}
