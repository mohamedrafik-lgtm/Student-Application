export const PAYMENT_METHOD_CODES = ["vodafone_cash"] as const;

export type PaymentMethodCode = (typeof PAYMENT_METHOD_CODES)[number];

export const PAYMENT_METHOD_LABELS: Record<PaymentMethodCode, string> = {
  vodafone_cash: "فودافون كاش",
};

export function isPaymentMethodCode(value: unknown): value is PaymentMethodCode {
  return typeof value === "string" && PAYMENT_METHOD_CODES.includes(value as PaymentMethodCode);
}

export const PURCHASE_STATUSES = [
  "in_review",
  "preparing",
  "approved",
  "rejected",
] as const;

export type PurchaseStatus = (typeof PURCHASE_STATUSES)[number];

export const PURCHASE_STATUS_LABELS: Record<PurchaseStatus, string> = {
  in_review: "قيد التحضير والمراجعة",
  preparing: "قيد التحضير",
  approved: "مقبول",
  rejected: "مرفوض",
};

export function isPurchaseStatus(value: unknown): value is PurchaseStatus {
  return typeof value === "string" && PURCHASE_STATUSES.includes(value as PurchaseStatus);
}
