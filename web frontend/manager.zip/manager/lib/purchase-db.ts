import type { ResultSetHeader, RowDataPacket } from "mysql2/promise";

import type { UserRole } from "@/lib/auth-types";
import { db } from "@/lib/db";
import { isPlanDurationCode, type PlanDurationCode } from "@/lib/plan-duration";
import {
  isPaymentMethodCode,
  isPurchaseStatus,
  type PaymentMethodCode,
  type PurchaseStatus,
} from "@/lib/purchase-types";

interface PaymentMethodRow extends RowDataPacket {
  id: number;
  method_code: string;
  phone_number: string;
  is_active: number;
  created_at: Date | string;
  updated_at: Date | string;
}

interface PurchaseRow extends RowDataPacket {
  id: number;
  user_id: number;
  user_full_name?: string;
  user_phone?: string | null;
  plan_id: number;
  plan_name?: string;
  program_name?: string;
  payment_method_id: number | null;
  payment_method_code: string;
  payment_phone_to: string;
  transfer_from_phone: string;
  amount_egp: number | string;
  status: string;
  admin_note: string | null;
  created_at: Date | string;
  updated_at: Date | string;
}

interface PublicPlanRow extends RowDataPacket {
  id: number;
  program_id: number;
  program_name: string;
  name: string;
  description: string;
  price_egp: number | string;
  duration_code: string | null;
  duration_custom_label: string | null;
}

interface PurchaseMessageRow extends RowDataPacket {
  id: number;
  purchase_id: number;
  sender_user_id: number;
  sender_role: string;
  sender_full_name?: string;
  message_text: string;
  created_at: Date | string;
}

export interface PaymentMethod {
  id: number;
  methodCode: PaymentMethodCode;
  phoneNumber: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface PublicPlanForPurchase {
  id: number;
  programId: number;
  programName: string;
  name: string;
  description: string;
  priceEgp: number;
  durationCode: PlanDurationCode;
  durationCustomLabel: string | null;
}

export interface PurchaseItem {
  id: number;
  userId: number;
  userFullName: string | null;
  userPhone: string | null;
  planId: number;
  planName: string | null;
  programName: string | null;
  paymentMethodId: number | null;
  paymentMethodCode: PaymentMethodCode;
  paymentPhoneTo: string;
  transferFromPhone: string;
  amountEgp: number;
  status: PurchaseStatus;
  adminNote: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface PurchaseMessage {
  id: number;
  purchaseId: number;
  senderUserId: number;
  senderRole: UserRole;
  senderFullName: string | null;
  messageText: string;
  createdAt: string;
}

function toIso(value: Date | string): string {
  if (value instanceof Date) {
    return value.toISOString();
  }

  return new Date(value).toISOString();
}

function isMissingTableError(error: unknown): boolean {
  return (
    typeof error === "object" &&
    error !== null &&
    "code" in error &&
    (error as { code?: string }).code === "ER_NO_SUCH_TABLE"
  );
}

function mapPaymentMethod(row: PaymentMethodRow): PaymentMethod {
  return {
    id: row.id,
    methodCode: isPaymentMethodCode(row.method_code) ? row.method_code : "vodafone_cash",
    phoneNumber: row.phone_number,
    isActive: row.is_active === 1,
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

function mapPurchase(row: PurchaseRow): PurchaseItem {
  return {
    id: row.id,
    userId: row.user_id,
    userFullName: row.user_full_name ?? null,
    userPhone: row.user_phone ?? null,
    planId: row.plan_id,
    planName: row.plan_name ?? null,
    programName: row.program_name ?? null,
    paymentMethodId: row.payment_method_id,
    paymentMethodCode: isPaymentMethodCode(row.payment_method_code)
      ? row.payment_method_code
      : "vodafone_cash",
    paymentPhoneTo: row.payment_phone_to,
    transferFromPhone: row.transfer_from_phone,
    amountEgp: Number(row.amount_egp),
    status: isPurchaseStatus(row.status) ? row.status : "in_review",
    adminNote: row.admin_note,
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

function mapPublicPlanForPurchase(row: PublicPlanRow): PublicPlanForPurchase {
  const code = row.duration_code ?? "";
  return {
    id: row.id,
    programId: row.program_id,
    programName: row.program_name,
    name: row.name,
    description: row.description,
    priceEgp: Number(row.price_egp),
    durationCode: isPlanDurationCode(code) ? code : "unspecified",
    durationCustomLabel: row.duration_custom_label ?? null,
  };
}

function mapPurchaseMessage(row: PurchaseMessageRow): PurchaseMessage {
  return {
    id: row.id,
    purchaseId: row.purchase_id,
    senderUserId: row.sender_user_id,
    senderRole: row.sender_role === "admin" ? "admin" : "user",
    senderFullName: row.sender_full_name ?? null,
    messageText: row.message_text,
    createdAt: toIso(row.created_at),
  };
}

export async function listPaymentMethodsForAdmin(): Promise<PaymentMethod[]> {
  const [rows] = await db.execute<PaymentMethodRow[]>(
    `SELECT id, method_code, phone_number, is_active, created_at, updated_at
     FROM payment_methods
     ORDER BY created_at DESC`,
  );

  return rows.map(mapPaymentMethod);
}

export async function listActiveVodafoneCashMethods(): Promise<PaymentMethod[]> {
  const [rows] = await db.execute<PaymentMethodRow[]>(
    `SELECT id, method_code, phone_number, is_active, created_at, updated_at
     FROM payment_methods
     WHERE method_code = 'vodafone_cash'
       AND is_active = 1
     ORDER BY created_at DESC`,
  );

  return rows.map(mapPaymentMethod);
}

export async function createVodafoneCashMethod(phoneNumber: string): Promise<number> {
  const [result] = await db.execute<ResultSetHeader>(
    `INSERT INTO payment_methods (method_code, phone_number, is_active)
     VALUES ('vodafone_cash', ?, 1)`,
    [phoneNumber.trim()],
  );

  return result.insertId;
}

export async function setPaymentMethodActiveStatus(
  paymentMethodId: number,
  isActive: boolean,
): Promise<boolean> {
  const [result] = await db.execute<ResultSetHeader>(
    `UPDATE payment_methods
     SET is_active = ?,
         updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`,
    [isActive ? 1 : 0, paymentMethodId],
  );

  return result.affectedRows > 0;
}

export async function deletePaymentMethodById(paymentMethodId: number): Promise<boolean> {
  const [result] = await db.execute<ResultSetHeader>(
    `DELETE FROM payment_methods
     WHERE id = ?`,
    [paymentMethodId],
  );

  return result.affectedRows > 0;
}

export async function getPublicPlanForPurchaseById(
  planId: number,
): Promise<PublicPlanForPurchase | null> {
  const [rows] = await db.execute<PublicPlanRow[]>(
    `SELECT pl.id, pl.program_id, p.name AS program_name, pl.name, pl.description, pl.price_egp, pl.duration_code, pl.duration_custom_label
     FROM plans pl
     INNER JOIN programs p ON p.id = pl.program_id
     WHERE pl.id = ?
       AND pl.is_active = 1
     LIMIT 1`,
    [planId],
  );

  const row = rows[0];
  return row ? mapPublicPlanForPurchase(row) : null;
}

export async function createPurchaseRequest(input: {
  userId: number;
  planId: number;
  paymentMethodId: number;
  transferFromPhone: string;
}): Promise<number | null> {
  const [result] = await db.execute<ResultSetHeader>(
    `INSERT INTO purchases (
      user_id,
      plan_id,
      payment_method_id,
      payment_method_code,
      payment_phone_to,
      transfer_from_phone,
      amount_egp,
      status
    )
    SELECT
      ?,
      pl.id,
      pm.id,
      pm.method_code,
      pm.phone_number,
      ?,
      pl.price_egp,
      'in_review'
    FROM plans pl
    INNER JOIN payment_methods pm ON pm.id = ?
    WHERE pl.id = ?
      AND pl.is_active = 1
      AND pm.is_active = 1
    LIMIT 1`,
    [
      input.userId,
      input.transferFromPhone.trim(),
      input.paymentMethodId,
      input.planId,
    ],
  );

  return result.affectedRows > 0 ? result.insertId : null;
}

export async function listPurchasesForUser(userId: number): Promise<PurchaseItem[]> {
  const [rows] = await db.execute<PurchaseRow[]>(
    `SELECT
      pr.id,
      pr.user_id,
      pr.plan_id,
      pl.name AS plan_name,
      pg.name AS program_name,
      pr.payment_method_id,
      pr.payment_method_code,
      pr.payment_phone_to,
      pr.transfer_from_phone,
      pr.amount_egp,
      pr.status,
      pr.admin_note,
      pr.created_at,
      pr.updated_at
     FROM purchases pr
     INNER JOIN plans pl ON pl.id = pr.plan_id
     INNER JOIN programs pg ON pg.id = pl.program_id
     WHERE pr.user_id = ?
     ORDER BY pr.created_at DESC`,
    [userId],
  );

  return rows.map(mapPurchase);
}

export async function listPurchasesForAdmin(searchTerm?: string): Promise<PurchaseItem[]> {
  const normalizedSearchTerm = (searchTerm ?? "").trim().toLowerCase();
  const hasSearch = normalizedSearchTerm.length > 0;

  const [rows] = hasSearch
    ? await db.execute<PurchaseRow[]>(
        `SELECT
          pr.id,
          pr.user_id,
          u.full_name AS user_full_name,
          u.phone AS user_phone,
          pr.plan_id,
          pl.name AS plan_name,
          pg.name AS program_name,
          pr.payment_method_id,
          pr.payment_method_code,
          pr.payment_phone_to,
          pr.transfer_from_phone,
          pr.amount_egp,
          pr.status,
          pr.admin_note,
          pr.created_at,
          pr.updated_at
         FROM purchases pr
         INNER JOIN users u ON u.id = pr.user_id
         INNER JOIN plans pl ON pl.id = pr.plan_id
         INNER JOIN programs pg ON pg.id = pl.program_id
         WHERE LOWER(COALESCE(u.full_name, '')) LIKE ?
            OR LOWER(COALESCE(u.phone, '')) LIKE ?
            OR LOWER(COALESCE(pl.name, '')) LIKE ?
            OR LOWER(COALESCE(pg.name, '')) LIKE ?
            OR LOWER(COALESCE(pr.payment_phone_to, '')) LIKE ?
            OR LOWER(COALESCE(pr.transfer_from_phone, '')) LIKE ?
            OR LOWER(COALESCE(pr.status, '')) LIKE ?
            OR CAST(pr.id AS CHAR) LIKE ?
         ORDER BY pr.created_at DESC`,
        [
          `%${normalizedSearchTerm}%`,
          `%${normalizedSearchTerm}%`,
          `%${normalizedSearchTerm}%`,
          `%${normalizedSearchTerm}%`,
          `%${normalizedSearchTerm}%`,
          `%${normalizedSearchTerm}%`,
          `%${normalizedSearchTerm}%`,
          `%${normalizedSearchTerm}%`,
        ],
      )
    : await db.execute<PurchaseRow[]>(
        `SELECT
          pr.id,
          pr.user_id,
          u.full_name AS user_full_name,
          u.phone AS user_phone,
          pr.plan_id,
          pl.name AS plan_name,
          pg.name AS program_name,
          pr.payment_method_id,
          pr.payment_method_code,
          pr.payment_phone_to,
          pr.transfer_from_phone,
          pr.amount_egp,
          pr.status,
          pr.admin_note,
          pr.created_at,
          pr.updated_at
         FROM purchases pr
         INNER JOIN users u ON u.id = pr.user_id
         INNER JOIN plans pl ON pl.id = pr.plan_id
         INNER JOIN programs pg ON pg.id = pl.program_id
         ORDER BY pr.created_at DESC`,
      );

  return rows.map(mapPurchase);
}

export async function getPurchaseByIdForUser(
  userId: number,
  purchaseId: number,
): Promise<PurchaseItem | null> {
  const [rows] = await db.execute<PurchaseRow[]>(
    `SELECT
      pr.id,
      pr.user_id,
      pr.plan_id,
      pl.name AS plan_name,
      pg.name AS program_name,
      pr.payment_method_id,
      pr.payment_method_code,
      pr.payment_phone_to,
      pr.transfer_from_phone,
      pr.amount_egp,
      pr.status,
      pr.admin_note,
      pr.created_at,
      pr.updated_at
     FROM purchases pr
     INNER JOIN plans pl ON pl.id = pr.plan_id
     INNER JOIN programs pg ON pg.id = pl.program_id
     WHERE pr.id = ?
       AND pr.user_id = ?
     LIMIT 1`,
    [purchaseId, userId],
  );

  const row = rows[0];
  return row ? mapPurchase(row) : null;
}

export async function getPurchaseByIdForAdmin(
  purchaseId: number,
): Promise<PurchaseItem | null> {
  const [rows] = await db.execute<PurchaseRow[]>(
    `SELECT
      pr.id,
      pr.user_id,
      u.full_name AS user_full_name,
      u.phone AS user_phone,
      pr.plan_id,
      pl.name AS plan_name,
      pg.name AS program_name,
      pr.payment_method_id,
      pr.payment_method_code,
      pr.payment_phone_to,
      pr.transfer_from_phone,
      pr.amount_egp,
      pr.status,
      pr.admin_note,
      pr.created_at,
      pr.updated_at
     FROM purchases pr
     INNER JOIN users u ON u.id = pr.user_id
     INNER JOIN plans pl ON pl.id = pr.plan_id
     INNER JOIN programs pg ON pg.id = pl.program_id
     WHERE pr.id = ?
     LIMIT 1`,
    [purchaseId],
  );

  const row = rows[0];
  return row ? mapPurchase(row) : null;
}

export async function listPurchaseMessages(
  purchaseId: number,
): Promise<PurchaseMessage[]> {
  try {
    const [rows] = await db.execute<PurchaseMessageRow[]>(
      `SELECT
        pm.id,
        pm.purchase_id,
        pm.sender_user_id,
        pm.sender_role,
        u.full_name AS sender_full_name,
        pm.message_text,
        pm.created_at
       FROM purchase_messages pm
       INNER JOIN users u ON u.id = pm.sender_user_id
       WHERE pm.purchase_id = ?
       ORDER BY pm.created_at ASC, pm.id ASC`,
      [purchaseId],
    );

    return rows.map(mapPurchaseMessage);
  } catch (error) {
    if (isMissingTableError(error)) {
      return [];
    }

    throw error;
  }
}

export async function createPurchaseMessage(input: {
  purchaseId: number;
  senderUserId: number;
  senderRole: UserRole;
  messageText: string;
}): Promise<PurchaseMessage | null> {
  try {
    const [result] = await db.execute<ResultSetHeader>(
      `INSERT INTO purchase_messages (purchase_id, sender_user_id, sender_role, message_text)
       VALUES (?, ?, ?, ?)`,
      [
        input.purchaseId,
        input.senderUserId,
        input.senderRole,
        input.messageText.trim(),
      ],
    );

    const [rows] = await db.execute<PurchaseMessageRow[]>(
      `SELECT
        pm.id,
        pm.purchase_id,
        pm.sender_user_id,
        pm.sender_role,
        u.full_name AS sender_full_name,
        pm.message_text,
        pm.created_at
       FROM purchase_messages pm
       INNER JOIN users u ON u.id = pm.sender_user_id
       WHERE pm.id = ?
       LIMIT 1`,
      [result.insertId],
    );

    const row = rows[0];
    return row ? mapPurchaseMessage(row) : null;
  } catch (error) {
    if (isMissingTableError(error)) {
      return null;
    }

    throw error;
  }
}

export async function updatePurchaseStatusById(input: {
  purchaseId: number;
  status: PurchaseStatus;
  adminNote: string | null;
}): Promise<boolean> {
  const [result] = await db.execute<ResultSetHeader>(
    `UPDATE purchases
     SET status = ?,
         admin_note = ?,
         updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`,
    [input.status, input.adminNote, input.purchaseId],
  );

  return result.affectedRows > 0;
}
