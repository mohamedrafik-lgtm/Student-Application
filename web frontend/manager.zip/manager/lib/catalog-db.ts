import type { ResultSetHeader, RowDataPacket } from "mysql2/promise";

import { db } from "@/lib/db";
import { isPlanDurationCode, type PlanDurationCode } from "@/lib/plan-duration";

interface ProgramRow extends RowDataPacket {
  id: number;
  name: string;
  description: string;
  created_at: Date | string;
  updated_at: Date | string;
  plans_count?: number | string;
}

interface PlanRow extends RowDataPacket {
  id: number;
  program_id: number;
  program_name?: string;
  name: string;
  description: string;
  price_egp: number | string;
  is_active: number;
  duration_code?: string | null;
  duration_custom_label?: string | null;
  created_at: Date | string;
  updated_at: Date | string;
}

export interface Program {
  id: number;
  name: string;
  description: string;
  createdAt: string;
  updatedAt: string;
}

export interface ProgramWithStats extends Program {
  plansCount: number;
}

export interface Plan {
  id: number;
  programId: number;
  name: string;
  description: string;
  priceEgp: number;
  isActive: boolean;
  durationCode: PlanDurationCode;
  durationCustomLabel: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface PlanWithProgram extends Plan {
  programName: string;
}

function toIso(value: Date | string): string {
  if (value instanceof Date) {
    return value.toISOString();
  }
  return new Date(value).toISOString();
}

function isUnknownColumnError(error: unknown): boolean {
  return (
    typeof error === "object" &&
    error !== null &&
    "code" in error &&
    (error as { code?: string }).code === "ER_BAD_FIELD_ERROR"
  );
}

function mapProgram(row: ProgramRow): Program {
  return {
    id: row.id,
    name: row.name,
    description: row.description,
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

function mapPlan(row: PlanRow): Plan {
  const code = row.duration_code ?? "";
  const durationCode: PlanDurationCode = isPlanDurationCode(code) ? code : "unspecified";

  return {
    id: row.id,
    programId: row.program_id,
    name: row.name,
    description: row.description,
    priceEgp: Number(row.price_egp),
    isActive: row.is_active === 1,
    durationCode,
    durationCustomLabel: row.duration_custom_label ?? null,
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

export async function listProgramsForAdmin(): Promise<Program[]> {
  const [rows] = await db.execute<ProgramRow[]>(
    `SELECT id, name, description, created_at, updated_at
     FROM programs
     ORDER BY created_at DESC`,
  );

  return rows.map(mapProgram);
}

export async function listProgramsWithPlanCounts(): Promise<ProgramWithStats[]> {
  const [rows] = await db.execute<ProgramRow[]>(
    `SELECT p.id, p.name, p.description, p.created_at, p.updated_at,
            COUNT(pl.id) AS plans_count
     FROM programs p
     LEFT JOIN plans pl ON pl.program_id = p.id AND pl.is_active = 1
     GROUP BY p.id, p.name, p.description, p.created_at, p.updated_at
     ORDER BY p.created_at DESC`,
  );

  return rows.map((row) => ({
    ...mapProgram(row),
    plansCount: Number(row.plans_count ?? 0),
  }));
}

export async function getProgramById(programId: number): Promise<Program | null> {
  const [rows] = await db.execute<ProgramRow[]>(
    `SELECT id, name, description, created_at, updated_at
     FROM programs
     WHERE id = ?
     LIMIT 1`,
    [programId],
  );

  const row = rows[0];
  return row ? mapProgram(row) : null;
}

export async function createProgram(input: {
  name: string;
  description: string;
}): Promise<number> {
  const [result] = await db.execute<ResultSetHeader>(
    `INSERT INTO programs (name, description)
     VALUES (?, ?)`,
    [input.name.trim(), input.description.trim()],
  );

  return result.insertId;
}

export async function updateProgram(input: {
  id: number;
  name: string;
  description: string;
}): Promise<boolean> {
  const [result] = await db.execute<ResultSetHeader>(
    `UPDATE programs
     SET name = ?,
         description = ?,
         updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`,
    [input.name.trim(), input.description.trim(), input.id],
  );

  return result.affectedRows > 0;
}

export async function deleteProgram(programId: number): Promise<boolean> {
  const [result] = await db.execute<ResultSetHeader>(
    `DELETE FROM programs WHERE id = ?`,
    [programId],
  );

  return result.affectedRows > 0;
}

export async function listPlansByProgramId(programId: number): Promise<Plan[]> {
  let rows: PlanRow[];

  try {
    const [nextRows] = await db.execute<PlanRow[]>(
      `SELECT id, program_id, name, description, price_egp, is_active, duration_code, duration_custom_label, created_at, updated_at
       FROM plans
       WHERE program_id = ?
       ORDER BY created_at DESC`,
      [programId],
    );
    rows = nextRows;
  } catch (error) {
    if (!isUnknownColumnError(error)) {
      throw error;
    }

    const [legacyRows] = await db.execute<PlanRow[]>(
      `SELECT id, program_id, name, description, price_egp, is_active, created_at, updated_at
       FROM plans
       WHERE program_id = ?
       ORDER BY created_at DESC`,
      [programId],
    );
    rows = legacyRows;
  }

  return rows.map(mapPlan);
}

export async function listPublicPlans(programId?: number): Promise<PlanWithProgram[]> {
  const hasProgramFilter = Number.isInteger(programId) && Number(programId) > 0;
  const normalizedProgramId = hasProgramFilter ? Number(programId) : 0;

  let rows: PlanRow[];

  try {
    const [nextRows] = hasProgramFilter
      ? await db.execute<PlanRow[]>(
          `SELECT pl.id, pl.program_id, p.name AS program_name, pl.name, pl.description, pl.price_egp, pl.is_active, pl.duration_code, pl.duration_custom_label, pl.created_at, pl.updated_at
           FROM plans pl
           INNER JOIN programs p ON p.id = pl.program_id
           WHERE pl.is_active = 1
             AND pl.program_id = ?
           ORDER BY pl.created_at DESC`,
          [normalizedProgramId],
        )
      : await db.execute<PlanRow[]>(
          `SELECT pl.id, pl.program_id, p.name AS program_name, pl.name, pl.description, pl.price_egp, pl.is_active, pl.duration_code, pl.duration_custom_label, pl.created_at, pl.updated_at
           FROM plans pl
           INNER JOIN programs p ON p.id = pl.program_id
           WHERE pl.is_active = 1
           ORDER BY pl.created_at DESC`,
        );

    rows = nextRows;
  } catch (error) {
    if (!isUnknownColumnError(error)) {
      throw error;
    }

    const [legacyRows] = hasProgramFilter
      ? await db.execute<PlanRow[]>(
          `SELECT pl.id, pl.program_id, p.name AS program_name, pl.name, pl.description, pl.price_egp, pl.is_active, pl.created_at, pl.updated_at
           FROM plans pl
           INNER JOIN programs p ON p.id = pl.program_id
           WHERE pl.is_active = 1
             AND pl.program_id = ?
           ORDER BY pl.created_at DESC`,
          [normalizedProgramId],
        )
      : await db.execute<PlanRow[]>(
          `SELECT pl.id, pl.program_id, p.name AS program_name, pl.name, pl.description, pl.price_egp, pl.is_active, pl.created_at, pl.updated_at
           FROM plans pl
           INNER JOIN programs p ON p.id = pl.program_id
           WHERE pl.is_active = 1
           ORDER BY pl.created_at DESC`,
        );

    rows = legacyRows;
  }

  return rows.map((row) => ({
    ...mapPlan(row),
    programName: row.program_name ?? "",
  }));
}

export async function createPlan(input: {
  programId: number;
  name: string;
  description: string;
  priceEgp: number;
  durationCode: PlanDurationCode;
  durationCustomLabel: string | null;
}): Promise<number> {
  let result: ResultSetHeader;

  try {
    const [nextResult] = await db.execute<ResultSetHeader>(
      `INSERT INTO plans (program_id, name, description, price_egp, is_active, duration_code, duration_custom_label)
       VALUES (?, ?, ?, ?, 1, ?, ?)`,
      [
        input.programId,
        input.name.trim(),
        input.description.trim(),
        input.priceEgp,
        input.durationCode,
        input.durationCode === "custom" ? input.durationCustomLabel?.trim() ?? null : null,
      ],
    );
    result = nextResult;
  } catch (error) {
    if (!isUnknownColumnError(error)) {
      throw error;
    }

    const [legacyResult] = await db.execute<ResultSetHeader>(
      `INSERT INTO plans (program_id, name, description, price_egp, is_active)
       VALUES (?, ?, ?, ?, 1)`,
      [input.programId, input.name.trim(), input.description.trim(), input.priceEgp],
    );
    result = legacyResult;
  }

  return result.insertId;
}

export async function updatePlan(input: {
  id: number;
  name: string;
  description: string;
  priceEgp: number;
  isActive: boolean;
  durationCode: PlanDurationCode;
  durationCustomLabel: string | null;
}): Promise<boolean> {
  let result: ResultSetHeader;

  try {
    const [nextResult] = await db.execute<ResultSetHeader>(
      `UPDATE plans
       SET name = ?,
           description = ?,
           price_egp = ?,
           is_active = ?,
           duration_code = ?,
           duration_custom_label = ?,
           updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`,
      [
        input.name.trim(),
        input.description.trim(),
        input.priceEgp,
        input.isActive ? 1 : 0,
        input.durationCode,
        input.durationCode === "custom" ? input.durationCustomLabel?.trim() ?? null : null,
        input.id,
      ],
    );
    result = nextResult;
  } catch (error) {
    if (!isUnknownColumnError(error)) {
      throw error;
    }

    const [legacyResult] = await db.execute<ResultSetHeader>(
      `UPDATE plans
       SET name = ?,
           description = ?,
           price_egp = ?,
           is_active = ?,
           updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`,
      [
        input.name.trim(),
        input.description.trim(),
        input.priceEgp,
        input.isActive ? 1 : 0,
        input.id,
      ],
    );
    result = legacyResult;
  }

  return result.affectedRows > 0;
}

export async function deletePlan(planId: number): Promise<boolean> {
  const [result] = await db.execute<ResultSetHeader>(
    `DELETE FROM plans WHERE id = ?`,
    [planId],
  );

  return result.affectedRows > 0;
}
