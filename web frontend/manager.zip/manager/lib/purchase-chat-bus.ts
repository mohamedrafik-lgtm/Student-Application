type PurchaseChatEvent = "purchase-message";

type PurchaseChatListener = (payload: unknown) => void;

const globalForPurchaseChat = globalThis as typeof globalThis & {
  __purchaseChatListeners?: Map<number, Set<PurchaseChatListener>>;
};

const listeners =
  globalForPurchaseChat.__purchaseChatListeners ?? new Map<number, Set<PurchaseChatListener>>();

globalForPurchaseChat.__purchaseChatListeners = listeners;

export function subscribeToPurchaseChat(
  purchaseId: number,
  listener: PurchaseChatListener,
): () => void {
  const purchaseListeners = listeners.get(purchaseId) ?? new Set<PurchaseChatListener>();
  purchaseListeners.add(listener);
  listeners.set(purchaseId, purchaseListeners);

  return () => {
    const currentListeners = listeners.get(purchaseId);
    if (!currentListeners) {
      return;
    }

    currentListeners.delete(listener);

    if (currentListeners.size === 0) {
      listeners.delete(purchaseId);
    }
  };
}

export function broadcastPurchaseChatMessage(
  purchaseId: number,
  payload: unknown,
): void {
  const purchaseListeners = listeners.get(purchaseId);
  if (!purchaseListeners || purchaseListeners.size === 0) {
    return;
  }

  for (const listener of purchaseListeners) {
    listener(payload);
  }
}

export function toSseEvent(eventName: PurchaseChatEvent, payload: unknown): string {
  return `event: ${eventName}\ndata: ${JSON.stringify(payload)}\n\n`;
}
