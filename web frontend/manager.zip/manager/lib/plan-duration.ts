export const PLAN_DURATION_CODES = [
  "unspecified",
  "month_1",
  "month_3",
  "month_6",
  "year_1",
  "year_2",
  "year_3",
  "custom",
] as const;

export type PlanDurationCode = (typeof PLAN_DURATION_CODES)[number];

export const PLAN_DURATION_LABELS: Record<PlanDurationCode, string> = {
  unspecified: "غير محدد",
  month_1: "شهر",
  month_3: "3 شهور",
  month_6: "6 شهور",
  year_1: "سنة",
  year_2: "سنتين",
  year_3: "3 سنوات",
  custom: "مخصص",
};

export function isPlanDurationCode(value: string): value is PlanDurationCode {
  return (PLAN_DURATION_CODES as readonly string[]).includes(value);
}

export function normalizePlanDurationCustomLabel(value: FormDataEntryValue | string | null): string | null {
  const normalized = typeof value === "string" ? value.trim() : "";
  return normalized ? normalized : null;
}

export function resolvePlanDurationInput(input: {
  rawCode: FormDataEntryValue | null;
  rawCustomLabel: FormDataEntryValue | null;
}): { code: PlanDurationCode; customLabel: string | null } | null {
  if (typeof input.rawCode !== "string") {
    return null;
  }

  const code = input.rawCode.trim();
  if (!isPlanDurationCode(code)) {
    return null;
  }

  const customLabel = normalizePlanDurationCustomLabel(input.rawCustomLabel);
  if (code === "custom" && !customLabel) {
    return null;
  }

  return {
    code,
    customLabel: code === "custom" ? customLabel : null,
  };
}

export function getPlanDurationLabel(code: PlanDurationCode, customLabel?: string | null): string {
  if (code === "custom") {
    return customLabel?.trim() ? customLabel.trim() : PLAN_DURATION_LABELS.custom;
  }

  return PLAN_DURATION_LABELS[code];
}
