import sanitizeHtml from "sanitize-html";

const PROGRAM_ALLOWED_TAGS = [
  "p",
  "br",
  "strong",
  "em",
  "u",
  "s",
  "blockquote",
  "ul",
  "ol",
  "li",
  "h2",
  "h3",
  "h4",
  "a",
  "span",
  "img",
] as const;

const PROGRAM_ALLOWED_ATTRIBUTES: sanitizeHtml.IOptions["allowedAttributes"] = {
  a: ["href", "target", "rel"],
  p: ["style"],
  h2: ["style"],
  h3: ["style"],
  h4: ["style"],
  span: ["style"],
  img: ["src", "alt", "title", "style", "data-width"],
};

const PROGRAM_ALLOWED_STYLES: sanitizeHtml.IOptions["allowedStyles"] = {
  p: {
    "text-align": [/^(left|right|center|justify)$/],
  },
  h2: {
    "text-align": [/^(left|right|center|justify)$/],
  },
  h3: {
    "text-align": [/^(left|right|center|justify)$/],
  },
  h4: {
    "text-align": [/^(left|right|center|justify)$/],
  },
  span: {
    color: [/^#[0-9a-fA-F]{3,8}$/, /^rgb\([0-9\s,%.]+\)$/],
    "background-color": [/^#[0-9a-fA-F]{3,8}$/, /^rgb\([0-9\s,%.]+\)$/],
  },
  img: {
    margin: [/^[0-9\s.a-z%-]+$/i],
    display: [/^block$/],
    height: [/^auto$/],
    width: [/^[0-9.]+(px|%)$/],
    "max-width": [/^[0-9.]+(px|%)$/],
  },
};

function normalizeNewlines(value: string): string {
  return value.replace(/\r\n/g, "\n").trim();
}

export function sanitizeProgramDescription(input: string): string {
  return sanitizeHtml(normalizeNewlines(input), {
    allowedTags: [...PROGRAM_ALLOWED_TAGS],
    allowedAttributes: PROGRAM_ALLOWED_ATTRIBUTES,
    allowedStyles: PROGRAM_ALLOWED_STYLES,
    allowedSchemes: ["http", "https"],
    allowProtocolRelative: false,
    transformTags: {
      a: sanitizeHtml.simpleTransform("a", {
        target: "_blank",
        rel: "noopener noreferrer nofollow",
      }),
    },
  }).trim();
}

export function extractPlainTextFromHtml(input: string): string {
  const textOnly = sanitizeHtml(input, {
    allowedTags: [],
    allowedAttributes: {},
  });

  return textOnly.replace(/\s+/g, " ").trim();
}
