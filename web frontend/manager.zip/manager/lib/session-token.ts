import { SignJWT, jwtVerify, type JWTPayload } from "jose";

import { isUserRole, type UserRole } from "@/lib/auth-types";
import { env } from "@/lib/env";

export const SESSION_COOKIE_NAME = "tiba_session";
export const SESSION_TTL_SECONDS = 60 * 60 * 24 * 7;

const secretKey = new TextEncoder().encode(env.AUTH_JWT_SECRET);

export interface SessionPayload extends JWTPayload {
  uid: number;
  sid: string;
  role: UserRole;
}

function isSessionPayload(payload: JWTPayload): payload is SessionPayload {
  return (
    typeof payload.uid === "number" &&
    typeof payload.sid === "string" &&
    isUserRole(payload.role)
  );
}

export async function createSessionToken(
  userId: number,
  role: UserRole,
): Promise<{
  token: string;
  sid: string;
  expiresAt: Date;
}> {
  const sid = crypto.randomUUID();
  const expiresAt = new Date(Date.now() + SESSION_TTL_SECONDS * 1000);

  const token = await new SignJWT({ uid: userId, sid, role })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(Math.floor(expiresAt.getTime() / 1000))
    .sign(secretKey);

  return { token, sid, expiresAt };
}

export async function verifySessionToken(
  token: string,
): Promise<SessionPayload | null> {
  try {
    const { payload } = await jwtVerify(token, secretKey, {
      algorithms: ["HS256"],
    });

    if (!isSessionPayload(payload)) {
      return null;
    }

    return payload;
  } catch {
    return null;
  }
}

export function getSessionCookieOptions() {
  return {
    httpOnly: true,
    secure: env.NODE_ENV === "production",
    sameSite: "strict" as const,
    path: "/",
    maxAge: SESSION_TTL_SECONDS,
    priority: "high" as const,
  };
}

export function getExpiredSessionCookieOptions() {
  return {
    ...getSessionCookieOptions(),
    maxAge: 0,
    expires: new Date(0),
  };
}
