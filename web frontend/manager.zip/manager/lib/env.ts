const requiredEnv = (key: string): string => {
  const value = process.env[key];
  if (!value) {
    throw new Error(`Missing required environment variable: ${key}`);
  }
  return value;
};

const parsedPort = Number.parseInt(process.env.DB_PORT ?? "3306", 10);
if (Number.isNaN(parsedPort)) {
  throw new Error("DB_PORT must be a valid number.");
}

export const env = {
  NODE_ENV: process.env.NODE_ENV ?? "development",
  APP_NAME: process.env.APP_NAME ?? "TIBA Software Product Management",
  DB_HOST: requiredEnv("DB_HOST"),
  DB_PORT: parsedPort,
  DB_USER: requiredEnv("DB_USER"),
  DB_PASSWORD: process.env.DB_PASSWORD ?? "",
  DB_NAME: requiredEnv("DB_NAME"),
  AUTH_JWT_SECRET: requiredEnv("AUTH_JWT_SECRET"),
} as const;
