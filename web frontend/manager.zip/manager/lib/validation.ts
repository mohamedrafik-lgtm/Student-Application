import { z } from "zod";

const phonePattern = /^(?:\+?[1-9]\d{7,14}|0\d{8,14})$/;
const emailSchema = z.string().email();
const phoneSchema = z.string().regex(phonePattern);

function normalizeEmail(value: string): string {
  return value.trim().toLowerCase();
}

export function normalizePhone(value: string): string {
  const cleaned = value.trim();
  if (!cleaned) {
    return "";
  }

  let normalized = cleaned.replace(/[\s().-]/g, "");

  if (normalized.startsWith("00")) {
    normalized = `+${normalized.slice(2)}`;
  }

  if (normalized.startsWith("+")) {
    normalized = `+${normalized.slice(1).replace(/\D/g, "")}`;
  } else {
    normalized = normalized.replace(/\D/g, "");
  }

  return normalized;
}

const passwordSchema = z.string().min(1, "كلمة المرور مطلوبة.").max(255);

export const registerInputSchema = z
  .object({
    fullName: z
      .string()
      .trim()
      .min(2, "Full name must be at least 2 characters.")
      .max(120, "Full name is too long."),
    email: z.string().trim().max(190).optional().default(""),
    phone: z.string().trim().max(30).optional().default(""),
    password: passwordSchema,
  })
  .transform((data) => ({
    ...data,
    email: data.email ? normalizeEmail(data.email) : "",
    phone: data.phone ? normalizePhone(data.phone) : "",
  }))
  .superRefine((data, ctx) => {
    if (!data.email && !data.phone) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["email"],
        message: "Provide an email or phone number.",
      });
    }

    if (data.email && !emailSchema.safeParse(data.email).success) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["email"],
        message: "Email format is invalid.",
      });
    }

    if (data.phone && !phoneSchema.safeParse(data.phone).success) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["phone"],
        message: "Phone format is invalid.",
      });
    }
  });

export type RegisterInput = z.output<typeof registerInputSchema>;

export const loginInputSchema = z
  .object({
    identifier: z
      .string()
      .trim()
      .min(3, "Email or phone is required.")
      .max(190, "Identifier is too long."),
    password: z.string().min(1, "Password is required.").max(128),
  })
  .transform((data) => {
    const cleanedIdentifier = data.identifier.trim();

    if (cleanedIdentifier.includes("@")) {
      return {
        password: data.password,
        identifierType: "email" as const,
        identifier: normalizeEmail(cleanedIdentifier),
      };
    }

    return {
      password: data.password,
      identifierType: "phone" as const,
      identifier: normalizePhone(cleanedIdentifier),
    };
  })
  .superRefine((data, ctx) => {
    if (data.identifierType === "email") {
      if (!emailSchema.safeParse(data.identifier).success) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ["identifier"],
          message: "Email format is invalid.",
        });
      }
      return;
    }

    if (!phoneSchema.safeParse(data.identifier).success) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["identifier"],
        message: "Phone format is invalid.",
      });
    }
  });

export type LoginInput = z.output<typeof loginInputSchema>;
