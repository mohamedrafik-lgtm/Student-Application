import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'TIBA | Subscription Flow',
  description: 'Advanced ERP Subscription Management Portal By TIBA Software',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang='ar' dir='rtl' className='antialiased'>
      <body className='bg-slate-50 text-slate-900 min-h-screen selection:bg-brand-500 selection:text-white'>
        {children}
      </body>
    </html>
  );
}