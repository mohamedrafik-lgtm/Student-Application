"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Lock, Mail, ArrowLeft, Hexagon, AlertCircle } from "lucide-react";

function extractFirstApiError(data: unknown): string {
  if (typeof data !== "object" || data === null) {
    return "حدث خطأ غير متوقع.";
  }

  const response = data as {
    message?: unknown;
    errors?: Record<string, string[] | undefined>;
  };

  if (response.errors && typeof response.errors === "object") {
    const first = Object.values(response.errors).find(
      (messages) => Array.isArray(messages) && messages.length > 0,
    );
    if (first && first[0]) {
      return first[0];
    }
  }

  if (typeof response.message === "string" && response.message.trim()) {
    return response.message;
  }

  return "تعذر اتمام العملية. حاول مرة أخرى.";
}

export default function LoginPage() {
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ identifier, password }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(extractFirstApiError(data));
      }

      if (data?.user?.role === "admin") {
        router.replace("/admin");
      } else {
        router.replace("/dashboard");
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen bg-slate-50 text-slate-900">
      
      {/* Right Side - Form */}
      <div className="w-full lg:w-[480px] xl:w-[540px] flex flex-col px-8 xl:px-12 py-10 bg-white relative z-10 shadow-[20px_0_40px_-20px_rgba(0,0,0,0.05)]">
        
        {/* Logo */}
        <div className="flex items-center gap-3 text-brand-600 mb-16 mt-6">
          <Hexagon className="w-10 h-10 fill-brand-100 stroke-brand-600 stroke-[1.5]" />
          <span className="font-bold text-2xl tracking-tight text-slate-900">طيبة سوفتوير</span>
        </div>

        <div className="flex-1 flex flex-col justify-center max-w-sm w-full mx-auto animate-in">
          <div className="flex items-center gap-2 mb-2">
            <h1 className="text-3xl font-bold text-slate-900">مرحباً بك مجدداً</h1>
            <span className="text-brand-500 animate-[wave_2.5s_ease-in-out_infinite] origin-[70%_70%] inline-block">
              <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-hand"><path d="M18 11V6a2 2 0 0 0-2-2v0a2 2 0 0 0-2 2v0"/><path d="M14 10V4a2 2 0 0 0-2-2v0a2 2 0 0 0-2 2v0"/><path d="M10 10.5V6a2 2 0 0 0-2-2v0a2 2 0 0 0-2 2v0"/><path d="M15 21 5.8 11.8a2 2 0 1 1 2.8-2.9l2.4 2.4"/></svg>
            </span>
          </div>
          <p className="text-slate-500 mb-10 text-sm">سجل دخولك للوصول إلى لوحة التحكم الخاصة باشتراكاتك.</p>

          {error && (
            <div className="mb-6 p-4 rounded-xl bg-red-50 text-red-600 border border-red-100 text-sm font-medium flex items-start gap-3 items-center">
              <AlertCircle size={20} className="flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-5">
            <div className="space-y-2">
              <label className="text-sm font-extrabold text-slate-800 block">البريد الإلكتروني أو رقم الهاتف</label>
              <div className="relative group mt-2.5">
                <Mail className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-brand-600 transition-all w-5 h-5 pointer-events-none group-focus-within:scale-110" />
                <input
                  type="text"
                  required
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  className="w-full bg-slate-50/50 border border-slate-200/80 text-slate-900 rounded-2xl px-12 py-4 focus:outline-none focus:ring-4 focus:ring-brand-500/10 focus:border-brand-500 transition-all hover:bg-slate-50 text-left font-sans shadow-[0_2px_8px_-2px_rgba(0,0,0,0.02)]"
                  placeholder="name@domain.com أو 01012345678"
                  dir="ltr"
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-sm font-extrabold text-slate-800 block">كلمة المرور</label>
                <Link href="#" className="flex-shrink-0 mx-2 text-[13px] font-bold text-brand-600 hover:text-brand-700 transition-colors bg-brand-50 hover:bg-brand-100 px-3 py-1.5 rounded-lg">نسيت الكلمة؟</Link>
              </div>
              <div className="relative group mt-2.5">
                <Lock className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-brand-600 transition-all w-5 h-5 pointer-events-none group-focus-within:scale-110" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-slate-50/50 border border-slate-200/80 text-slate-900 rounded-2xl px-12 py-4 focus:outline-none focus:ring-4 focus:ring-brand-500/10 focus:border-brand-500 transition-all hover:bg-slate-50 text-left font-sans tracking-widest shadow-[0_2px_8px_-2px_rgba(0,0,0,0.02)]"
                  placeholder="&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;"
                  dir="ltr"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-2xl py-4 transition-all duration-300 shadow-[0_8px_30px_-4px_rgba(15,23,42,0.2)] hover:shadow-[0_12px_40px_-4px_rgba(15,23,42,0.3)] flex items-center justify-center gap-3 group mt-10 disabled:opacity-70 disabled:cursor-not-allowed hover:-translate-y-0.5"
            >
              {loading ? "جاري الدخول..." : "تسجيل الدخول للنظام"}
              {!loading && <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1.5 transition-transform" />}
            </button>
          </form>

          <p className="mt-8 text-center text-sm text-slate-500 font-medium">
            ليس لديك حساب؟{" "}
            <Link href="/register" className="font-bold text-brand-600 hover:text-brand-700 transition-colors">
              إنشاء حساب جديد
            </Link>
          </p>
        </div>
      </div>

      {/* Left Side - Showcase Cover */}
      <div className="hidden lg:flex flex-1 relative bg-slate-900 overflow-hidden text-center items-center justify-center p-12">
        <div className="absolute inset-0" style={{ backgroundImage: "radial-gradient(ellipse at center, rgba(15, 23, 42, 0.4) 0%, #020617 100%)" }} />
        <div className="absolute top-[-20%] right-[-10%] w-[600px] h-[600px] bg-brand-500/20 rounded-full blur-[140px] mix-blend-screen pointer-events-none" />
        <div className="absolute bottom-[-20%] left-[-10%] w-[600px] h-[600px] bg-indigo-500/20 rounded-full blur-[140px] mix-blend-screen pointer-events-none" />
        
        {/* Content Showcase */}
        <div className="relative z-10 max-w-xl text-center right-0 flex flex-col items-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 backdrop-blur-xl border border-white/10 text-white text-xs font-bold tracking-wider mb-8 uppercase">
            <span className="flex h-2 w-2 rounded-full bg-brand-400 shadow-[0_0_8px_rgba(20,184,166,0.8)]"></span>
            رؤية موحدة لبيانات شركتك
          </div>
          <h2 className="text-4xl lg:text-5xl font-extrabold tracking-tight text-white mb-6 leading-[1.35] drop-shadow-sm">
            بوابة الإدارة المركزية<br/>
            بعالم طيبة سوفتوير
          </h2>
          <p className="text-slate-400 text-lg leading-relaxed max-w-lg mb-12">
            تمتع بالسيطرة الكاملة والمطلقة على كافة اشتراكاتك والوصول إلى أحدث بيانات الفوترة والإحصائيات الخاصة بعملك.
          </p>
          
          <div className="grid grid-cols-2 gap-px bg-white/10 w-full overflow-hidden rounded-2xl border border-white/10 backdrop-blur-sm">
            <div className="bg-slate-900/60 p-6 flex flex-col items-center justify-center text-center hover:bg-slate-800/60 transition-colors">
              <span className="block text-3xl font-bold text-white mb-1">٩٩.٩٪</span>
              <span className="block text-xs uppercase text-slate-400 tracking-wider">تشغيل مستقر</span>
            </div>
            <div className="bg-slate-900/60 p-6 flex flex-col items-center justify-center text-center hover:bg-slate-800/60 transition-colors">
              <span className="block text-3xl font-bold text-white mb-1">٢٤/٧</span>
              <span className="block text-xs uppercase text-slate-400 tracking-wider">دعم وحماية</span>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
}