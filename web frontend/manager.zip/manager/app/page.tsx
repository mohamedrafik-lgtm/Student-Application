import Link from "next/link";
import { Changa, Tajawal } from "next/font/google";

import PublicMobileMenu from "@/components/public-mobile-menu";
import { getCurrentUser } from "@/lib/auth-session";
import { listProgramsWithPlanCounts } from "@/lib/catalog-db";
import { extractPlainTextFromHtml } from "@/lib/rich-text";

const changa = Changa({
  subsets: ["arabic", "latin"],
  weight: ["600", "700", "800"],
});

const tajawal = Tajawal({
  subsets: ["arabic", "latin"],
  weight: ["400", "500", "700", "800"],
});

function createSnippet(value: string, maxLength = 140): string {
  const plain = extractPlainTextFromHtml(value);
  if (!plain) {
    return "برنامج احترافي ضمن حلول طيبة سوفتوير للتحول الرقمي وإدارة العمليات.";
  }
  if (plain.length <= maxLength) {
    return plain;
  }
  return `${plain.slice(0, maxLength).trim()}...`;
}

export default async function HomePage() {
  const currentUser = await getCurrentUser();
  const programs = await listProgramsWithPlanCounts();

  const totalPrograms = programs.length;
  const totalPlans = programs.reduce((sum, program) => sum + program.plansCount, 0);

  const dashboardHref = currentUser?.role === "admin" ? "/admin" : "/dashboard";
  const mobileLinks = [
    { href: "#about", label: "من نحن", isAnchor: true },
    { href: "#programs", label: "البرامج", isAnchor: true },
    { href: "#subscribe", label: "كيف أشترك", isAnchor: true },
  ];
  const mobilePrimaryAction = currentUser
    ? { href: dashboardHref, label: "دخول لوحة التحكم" }
    : { href: "/register", label: "إنشاء حساب" };
  const mobileSecondaryAction = currentUser ? undefined : { href: "/login", label: "تسجيل الدخول" };

  return (
    <div className={`${tajawal.className} min-h-screen bg-slate-50 text-slate-900`}>
      <div className="pointer-events-none fixed inset-0 -z-10 [background:radial-gradient(900px_360px_at_0%_0%,rgba(20,184,166,0.14),transparent_60%),radial-gradient(900px_360px_at_100%_0%,rgba(15,118,110,0.11),transparent_55%),linear-gradient(to_bottom,#f8fafc,#effaf7)]" />

      <div className="mx-auto w-full max-w-7xl px-4 pb-12 pt-6 sm:px-6 lg:px-8">
        <header className="sticky top-4 z-30 rounded-3xl border border-brand-100 bg-white/80 p-3 shadow-[0_18px_40px_-30px_rgba(20,184,166,0.35)] backdrop-blur-xl">
          <div className="flex items-center justify-between gap-2 rounded-2xl border border-brand-100 bg-white px-3 py-2.5 sm:gap-3 sm:px-4 sm:py-3">
            <Link href="/" className="group flex min-w-0 items-center gap-2.5 sm:gap-3">
              <span className="relative grid h-11 w-11 place-items-center">
                <span className="absolute inset-0 rounded-full bg-brand-100/80 blur-sm" />
                <span className="absolute inset-0 [clip-path:polygon(50%_0%,0%_100%,100%_100%)] bg-linear-to-b from-brand-500 via-brand-600 to-brand-700 shadow-[0_16px_26px_-14px_rgba(20,184,166,0.75)] transition-transform group-hover:scale-105" />
                <span className="absolute inset-x-2 bottom-1 top-3 [clip-path:polygon(50%_0%,0%_100%,100%_100%)] bg-white/25" />
                <span className="absolute left-1/2 top-0.5 h-1.5 w-1.5 -translate-x-1/2 rounded-full bg-emerald-200" />
              </span>
              <span className="min-w-0">
                <span className={`${changa.className} block truncate text-sm font-extrabold tracking-wide text-slate-900 sm:text-base`}>TIBA SOFTWARE</span>
                <span className="hidden text-[11px] font-bold text-slate-500 sm:block">Enterprise Solutions</span>
              </span>
            </Link>

            <nav className="hidden items-center gap-7 lg:flex">
              <a href="#about" className="text-sm font-bold text-slate-600 transition-colors hover:text-brand-700">
                من نحن
              </a>
              <a href="#programs" className="text-sm font-bold text-slate-600 transition-colors hover:text-brand-700">
                البرامج
              </a>
              <a href="#subscribe" className="text-sm font-bold text-slate-600 transition-colors hover:text-brand-700">
                كيف أشترك
              </a>
            </nav>

            <div className="hidden items-center gap-2 lg:flex">
              {currentUser ? (
                <Link
                  href={dashboardHref}
                  className="rounded-xl bg-brand-600 px-4 py-2.5 text-sm font-extrabold text-white transition-colors hover:bg-brand-700"
                >
                  دخول لوحة التحكم
                </Link>
              ) : (
                <>
                  <Link
                    href="/login"
                    className="rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-extrabold text-slate-700 transition-colors hover:bg-slate-50"
                  >
                    تسجيل الدخول
                  </Link>
                  <Link
                    href="/register"
                    className="rounded-xl bg-teal-600 px-4 py-2.5 text-sm font-extrabold text-white transition-colors hover:bg-teal-700"
                  >
                    إنشاء حساب
                  </Link>
                </>
              )}
            </div>

            <PublicMobileMenu
              links={mobileLinks}
              primaryAction={mobilePrimaryAction}
              secondaryAction={mobileSecondaryAction}
            />
          </div>
        </header>

        <main className="mt-7 space-y-7">
          <section className="relative overflow-hidden rounded-[28px] border border-brand-100 bg-white px-7 py-10 shadow-[0_28px_70px_-42px_rgba(20,184,166,0.28)] lg:px-10 lg:py-12">
            <div className="pointer-events-none absolute -left-20 -top-24 h-64 w-64 rounded-full bg-brand-100/65 blur-3xl" />
            <div className="pointer-events-none absolute -bottom-24 -right-16 h-72 w-72 rounded-full bg-emerald-100/65 blur-3xl" />

            <div className="grid grid-cols-1 gap-10 lg:grid-cols-[1.2fr_0.8fr] lg:items-center">
              <div className="relative z-10">
                <span className="inline-flex rounded-full border border-brand-100 bg-brand-50 px-3 py-1 text-xs font-black text-brand-700">
                  رائدون في تكنولوجيا المعلومات
                </span>

                <h1 className={`${changa.className} mt-4 text-4xl font-extrabold leading-tight text-slate-900 lg:text-6xl`}>
                  برامج أعمال
                  <span className="mt-1 block text-brand-700">بتنفيذ احترافي واضح</span>
                </h1>

                <p className="mt-5 max-w-2xl text-base font-semibold leading-8 text-slate-600 lg:text-lg">
                  في طيبة سوفتوير نبني حلولًا عملية للشركات والمؤسسات. ابدأ باختيار البرنامج المناسب، ثم انتقل مباشرة إلى صفحة باقاته. الاشتراك يتم بعد تسجيل حساب.
                </p>

                <div className="mt-8 flex flex-wrap gap-3">
                  <a
                    href="#programs"
                    className="rounded-xl bg-brand-600 px-5 py-3 text-sm font-black text-white transition-colors hover:bg-brand-700"
                  >
                    تصفح البرامج
                  </a>
                  <Link
                    href={currentUser ? dashboardHref : "/register"}
                    className="rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-black text-slate-700 transition-colors hover:bg-slate-50"
                  >
                    {currentUser ? "الانتقال للحساب" : "أنشئ حسابك"}
                  </Link>
                </div>
              </div>

              <div className="relative z-10 grid grid-cols-2 gap-3">
                <div className="rounded-2xl border border-brand-100 bg-brand-50/60 p-4">
                  <p className="text-3xl font-black text-slate-900">{totalPrograms}</p>
                  <p className="mt-1 text-xs font-bold text-slate-500">برنامج متاح</p>
                </div>
                <div className="rounded-2xl border border-brand-100 bg-brand-50/60 p-4">
                  <p className="text-3xl font-black text-slate-900">{totalPlans}</p>
                  <p className="mt-1 text-xs font-bold text-slate-500">باقة منشورة</p>
                </div>
                <div className="col-span-2 rounded-2xl border border-brand-100 bg-brand-50/60 p-4">
                  <p className="text-2xl font-black text-brand-700">24/7</p>
                  <p className="mt-1 text-xs font-bold text-slate-500">فريق دعم ومتابعة مستمر</p>
                </div>
              </div>
            </div>
          </section>

          <section id="about" className="grid grid-cols-1 gap-4 lg:grid-cols-3">
            <div className="rounded-3xl border border-brand-100 bg-white p-6">
              <p className={`${changa.className} text-lg font-extrabold text-slate-900`}>خبرة تشغيلية</p>
              <p className="mt-2 text-sm font-semibold leading-7 text-slate-600">
                حلول مصممة وفق احتياجات بيئات العمل العربية مع واجهة واضحة وسهلة.
              </p>
            </div>
            <div className="rounded-3xl border border-brand-100 bg-white p-6">
              <p className={`${changa.className} text-lg font-extrabold text-slate-900`}>توسع مرن</p>
              <p className="mt-2 text-sm font-semibold leading-7 text-slate-600">
                باقات متعددة المدد والأسعار لتبدأ بما يناسبك ثم تتوسع بثقة.
              </p>
            </div>
            <div id="subscribe" className="rounded-3xl border border-brand-100 bg-white p-6">
              <p className={`${changa.className} text-lg font-extrabold text-slate-900`}>اشتراك منظم</p>
              <p className="mt-2 text-sm font-semibold leading-7 text-slate-600">
                عرض برامج ثم باقات كل برنامج، وبعد التسجيل يمكنك طلب الاشتراك ومتابعته.
              </p>
            </div>
          </section>

          <section id="programs">
            <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
              <div>
                <h2 className={`${changa.className} text-3xl font-extrabold text-slate-900`}>برامجنا</h2>
                <p className="mt-1 text-sm font-semibold text-slate-500">اختر برنامجًا لعرض باقاته في صفحة مستقلة.</p>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
              {programs.map((program, index) => (
                <article
                  key={program.id}
                  className="group relative overflow-hidden rounded-3xl border border-brand-100 bg-white p-6 shadow-[0_18px_40px_-32px_rgba(20,184,166,0.28)] transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_24px_48px_-30px_rgba(13,148,136,0.3)]"
                >
                  <div className="absolute -left-3 -top-3 rounded-2xl border border-brand-100 bg-brand-50 px-3 py-1 text-xs font-black text-brand-700">
                    برنامج {index + 1}
                  </div>

                  <div className="pt-4">
                    <h3 className={`${changa.className} text-xl font-extrabold text-slate-900`}>{program.name}</h3>
                    <p className="mt-3 text-sm font-semibold leading-7 text-slate-600">{createSnippet(program.description)}</p>
                  </div>

                  <div className="mt-6 flex items-center justify-between gap-2">
                    <div className="inline-flex rounded-lg border border-teal-100 bg-teal-50 px-2.5 py-1 text-xs font-black text-teal-700">
                      الباقات: {program.plansCount}
                    </div>
                    <Link
                      href={`/programs/${program.id}`}
                      className="rounded-xl bg-brand-600 px-3.5 py-2 text-xs font-black text-white transition-colors hover:bg-brand-700"
                    >
                      عرض الباقات
                    </Link>
                  </div>
                </article>
              ))}

              {programs.length === 0 && (
                <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-8 text-center text-sm font-semibold text-slate-500 md:col-span-2 xl:col-span-3">
                  لا توجد برامج منشورة حاليًا.
                </div>
              )}
            </div>
          </section>
        </main>

        <footer className="mt-12 border-t border-brand-100 pt-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="text-xs font-bold text-slate-500">© {new Date().getFullYear()} TIBA SOFTWARE - جميع الحقوق محفوظة</p>
            {!currentUser && (
              <div className="flex items-center gap-2">
                <Link href="/login" className="text-xs font-black text-slate-600 hover:text-brand-700">
                  تسجيل الدخول
                </Link>
                <span className="text-slate-400">•</span>
                <Link href="/register" className="text-xs font-black text-slate-600 hover:text-brand-700">
                  إنشاء حساب
                </Link>
              </div>
            )}
          </div>
        </footer>
      </div>
    </div>
  );
}
