import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { CheckCircle2, PlusCircle, Trash2, Wallet } from "lucide-react";

import AppShell from "@/components/app-shell";
import { getCurrentUser } from "@/lib/auth-session";
import {
  createVodafoneCashMethod,
  deletePaymentMethodById,
  listPaymentMethodsForAdmin,
  setPaymentMethodActiveStatus,
} from "@/lib/purchase-db";
import { PAYMENT_METHOD_LABELS } from "@/lib/purchase-types";

function normalizeText(value: FormDataEntryValue | null): string {
  return typeof value === "string" ? value.trim() : "";
}

async function addVodafoneCashNumberAction(formData: FormData): Promise<void> {
  "use server";

  const user = await getCurrentUser();
  if (!user || user.role !== "admin") {
    redirect("/login");
  }

  const phoneNumber = normalizeText(formData.get("phoneNumber"));

  if (!phoneNumber || phoneNumber.length < 7) {
    return;
  }

  try {
    await createVodafoneCashMethod(phoneNumber);
  } catch {
    return;
  }

  revalidatePath("/admin/payment-methods");
  revalidatePath("/dashboard/purchases/new");
}

async function togglePaymentMethodAction(formData: FormData): Promise<void> {
  "use server";

  const user = await getCurrentUser();
  if (!user || user.role !== "admin") {
    redirect("/login");
  }

  const paymentMethodId = Number(formData.get("paymentMethodId"));
  const nextStatus = normalizeText(formData.get("nextStatus"));

  if (!Number.isInteger(paymentMethodId) || paymentMethodId <= 0) {
    return;
  }

  await setPaymentMethodActiveStatus(paymentMethodId, nextStatus === "1");

  revalidatePath("/admin/payment-methods");
  revalidatePath("/dashboard/purchases/new");
}

async function deletePaymentMethodAction(formData: FormData): Promise<void> {
  "use server";

  const user = await getCurrentUser();
  if (!user || user.role !== "admin") {
    redirect("/login");
  }

  const paymentMethodId = Number(formData.get("paymentMethodId"));

  if (!Number.isInteger(paymentMethodId) || paymentMethodId <= 0) {
    return;
  }

  await deletePaymentMethodById(paymentMethodId);

  revalidatePath("/admin/payment-methods");
  revalidatePath("/dashboard/purchases/new");
}

export default async function AdminPaymentMethodsPage() {
  const currentUser = await getCurrentUser();

  if (!currentUser) {
    redirect("/login");
  }

  if (currentUser.role !== "admin") {
    redirect("/dashboard");
  }

  const methods = await listPaymentMethodsForAdmin();

  return (
    <AppShell userRole={currentUser.role} username={currentUser.fullName}>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">طرق الدفع</h1>
          <p className="text-slate-500">الطريقة المتاحة حاليًا: فودافون كاش. أضف رقمًا واحدًا أو عدة أرقام.</p>
        </div>
        <div className="inline-flex items-center gap-2 bg-brand-50 text-brand-700 px-4 py-2 rounded-xl border border-brand-100">
          <Wallet size={18} />
          <span className="font-bold text-sm">عدد الأرقام: {methods.length}</span>
        </div>
      </div>

      <div className="mb-6 rounded-3xl border border-slate-200/70 bg-white p-5 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.02)]">
        <h2 className="mb-4 text-lg font-extrabold text-slate-900">إضافة رقم فودافون كاش</h2>
        <form action={addVodafoneCashNumberAction} className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <input
            type="text"
            name="phoneNumber"
            required
            placeholder="مثال: 01012345678"
            className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-800 sm:max-w-sm"
          />
          <button
            type="submit"
            className="inline-flex items-center justify-center gap-2 rounded-xl bg-slate-900 px-4 py-3 text-sm font-bold text-white hover:bg-slate-800"
          >
            <PlusCircle size={16} />
            إضافة الرقم
          </button>
        </form>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {methods.map((method) => (
          <div
            key={method.id}
            className="rounded-3xl border border-slate-200/70 bg-white p-5 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.02)]"
          >
            <div className="mb-3 flex flex-wrap items-start justify-between gap-3">
              <div>
                <h3 className="text-base font-extrabold text-slate-900">{PAYMENT_METHOD_LABELS[method.methodCode]}</h3>
                <p className="mt-1 text-sm font-bold text-slate-700">{method.phoneNumber}</p>
              </div>
              <span
                className={`rounded-lg border px-2.5 py-1 text-xs font-bold ${
                  method.isActive
                    ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                    : "border-amber-200 bg-amber-50 text-amber-700"
                }`}
              >
                {method.isActive ? "متاح" : "موقوف"}
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <form action={togglePaymentMethodAction}>
                <input type="hidden" name="paymentMethodId" value={method.id} />
                <input type="hidden" name="nextStatus" value={method.isActive ? "0" : "1"} />
                <button
                  type="submit"
                  className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm font-bold text-slate-700 hover:bg-slate-100"
                >
                  <CheckCircle2 size={16} />
                  {method.isActive ? "إيقاف" : "تفعيل"}
                </button>
              </form>

              <form action={deletePaymentMethodAction}>
                <input type="hidden" name="paymentMethodId" value={method.id} />
                <button
                  type="submit"
                  className="inline-flex items-center gap-2 rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-sm font-bold text-rose-700 hover:bg-rose-100"
                >
                  <Trash2 size={16} />
                  حذف الرقم
                </button>
              </form>
            </div>
          </div>
        ))}

        {methods.length === 0 && (
          <div className="rounded-2xl border border-dashed border-slate-200 bg-white p-8 text-center text-sm font-semibold text-slate-500">
            لا توجد أرقام مضافة حتى الآن.
          </div>
        )}
      </div>
    </AppShell>
  );
}
