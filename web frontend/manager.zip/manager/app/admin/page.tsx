import { redirect } from "next/navigation";
import AppShell from "../../components/app-shell";
import { getCurrentUser } from "@/lib/auth-session";
import { getAdminDashboardData } from "@/lib/dashboard-db";
import { PURCHASE_STATUS_LABELS } from "@/lib/purchase-types";
import { Users, CreditCard, Activity, ArrowUpRight, BarChart3, Database } from "lucide-react";

function formatArabicNumber(value: number): string {
  return new Intl.NumberFormat("ar-EG", {
    maximumFractionDigits: 0,
  }).format(value);
}

function formatEgp(value: number): string {
  return `${new Intl.NumberFormat("ar-EG", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(value)} ج`;
}

function formatRelativeTime(isoDate: string): string {
  const deltaMs = Date.now() - new Date(isoDate).getTime();
  const minute = 60_000;
  const hour = 60 * minute;
  const day = 24 * hour;

  if (deltaMs < hour) {
    const minutes = Math.max(1, Math.floor(deltaMs / minute));
    return `منذ ${formatArabicNumber(minutes)} دقيقة`;
  }

  if (deltaMs < day) {
    const hours = Math.max(1, Math.floor(deltaMs / hour));
    return `منذ ${formatArabicNumber(hours)} ساعة`;
  }

  const days = Math.max(1, Math.floor(deltaMs / day));
  return `منذ ${formatArabicNumber(days)} يوم`;
}

export default async function AdminPage() {
  const user = await getCurrentUser();

  if (!user) {
    redirect("/login");
  }

  if (user.role !== "admin") {
    redirect("/dashboard");
  }

  const dashboardData = await getAdminDashboardData();

  const kpis = [
    {
      title: "إجمالي المشتركين",
      value: formatArabicNumber(dashboardData.usersCount),
      change: `مدراء: ${formatArabicNumber(dashboardData.adminsCount)}`,
      icon: <Users size={20} className="text-indigo-600" />,
    },
    {
      title: "إيرادات الطلبات المقبولة",
      value: formatEgp(dashboardData.approvedRevenueEgp),
      change: `طلبات مقبولة: ${formatArabicNumber(dashboardData.approvedPurchasesCount)}`,
      icon: <CreditCard size={20} className="text-emerald-600" />,
    },
    {
      title: "طلبات قيد التحضير والمراجعة",
      value: formatArabicNumber(dashboardData.pendingPurchasesCount),
      change: `إجمالي الطلبات: ${formatArabicNumber(dashboardData.purchasesCount)}`,
      icon: <Activity size={20} className="text-rose-600" />,
    },
    {
      title: "الباقات النشطة",
      value: formatArabicNumber(dashboardData.activePlansCount),
      change: `البرامج: ${formatArabicNumber(dashboardData.programsCount)}`,
      icon: <Database size={20} className="text-blue-600" />,
    },
  ];

  return (
    <AppShell userRole={user.role} username={user.fullName}>
      <div className="flex justify-between items-end mb-10">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">
            لوحة الإدارة الرئيسية
          </h1>
          <p className="text-slate-500">نظرة شاملة على أداء المنصة والاشتراكات.</p>
        </div>
        <button className="hidden sm:flex bg-slate-900 hover:bg-slate-800 text-white font-medium px-4 py-2.5 rounded-xl transition-all items-center gap-2">
          <BarChart3 size={18} />
          تصدير تقرير
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
        {kpis.map((kpi, idx) => (
          <div key={idx} className="bg-white p-7 rounded-3xl border border-slate-200/60 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.02)] hover:shadow-[0_8px_30px_-4px_rgba(20,184,166,0.1)] hover:border-brand-100 transition-all duration-500 overflow-hidden relative group flex flex-col gap-4">
            <div className="absolute top-0 left-0 w-32 h-32 bg-linear-to-br from-indigo-50 to-transparent rounded-full blur-3xl -ml-16 -mt-16 transition-transform group-hover:scale-150 duration-700 opacity-60"></div>
            
            <div className="flex justify-between items-start w-full relative z-10">
              <div className="w-14 h-14 bg-slate-50 border border-slate-100/80 rounded-2xl flex items-center justify-center shadow-sm group-hover:scale-110 group-hover:bg-white transition-all duration-500">
                {kpi.icon}
              </div>
              <span className={`text-xs font-bold px-2.5 py-1.5 rounded-lg flex items-center gap-1 shadow-sm ${kpi.change.includes('-') ? 'text-rose-700 bg-rose-50 border-rose-100' : kpi.change.includes('+') ? 'text-emerald-700 bg-emerald-50 border-emerald-100' : 'text-slate-700 bg-slate-100 border-slate-200'} border`}>
                {kpi.change}
                {(kpi.change.includes("+") || kpi.change.includes("-")) && (
                  <ArrowUpRight size={14} className={kpi.change.includes('-') ? 'rotate-90' : ''} />
                )}
              </span>
            </div>
            
            <div className="relative z-10 mt-2">
              <p className="text-sm font-bold text-slate-500 mb-1.5">{kpi.title}</p>
              <h3 className="text-3xl font-extrabold text-slate-900 tracking-tight">{kpi.value}</h3>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-3xl shadow-[0_4px_20px_-4px_rgba(0,0,0,0.02)] border border-slate-200/60 p-8">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-xl font-extrabold text-slate-900 tracking-tight">أحدث العمليات</h2>
          <button className="text-brand-600 hover:text-brand-700 bg-brand-50 hover:bg-brand-100 px-4 py-2 rounded-xl text-sm font-bold transition-colors">عرض الكل</button>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-right border-collapse">
            <thead>
              <tr className="border-b border-slate-100">
                <th className="py-4 font-semibold text-slate-400 text-sm">المستخدم</th>
                <th className="py-4 font-semibold text-slate-400 text-sm">الباقة</th>
                <th className="py-4 font-semibold text-slate-400 text-sm">التاريخ</th>
                <th className="py-4 font-semibold text-slate-400 text-sm">الحالة</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {dashboardData.recentPurchases.map((purchase) => (
                <tr key={purchase.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="py-4">
                    <div className="flex gap-3 items-center">
                      <div className="w-8 h-8 rounded-full bg-slate-200 text-xs font-bold text-slate-700 flex items-center justify-center">
                        {purchase.userFullName.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <p className="font-semibold text-slate-900 text-sm">{purchase.userFullName}</p>
                        <p className="text-xs text-slate-500">{purchase.userEmail ?? "بدون بريد إلكتروني"}</p>
                      </div>
                    </div>
                  </td>
                  <td className="py-4 text-sm font-medium text-slate-700">{purchase.planName}</td>
                  <td className="py-4 text-sm text-slate-500">{formatRelativeTime(purchase.createdAt)}</td>
                  <td className="py-4">
                    <span
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${
                        purchase.status === "approved"
                          ? "bg-emerald-50 text-emerald-700 border-emerald-100"
                          : purchase.status === "rejected"
                            ? "bg-rose-50 text-rose-700 border-rose-100"
                            : "bg-amber-50 text-amber-700 border-amber-100"
                      }`}
                    >
                      {PURCHASE_STATUS_LABELS[purchase.status]}
                    </span>
                  </td>
                </tr>
              ))}

              {dashboardData.recentPurchases.length === 0 && (
                <tr>
                  <td className="py-6 text-center text-sm font-semibold text-slate-500" colSpan={4}>
                    لا توجد عمليات شراء لعرضها بعد.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </AppShell>
  );
}

