import Link from "next/link";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { ArrowRight, FolderPlus, PlusCircle } from "lucide-react";

import AppShell from "@/components/app-shell";
import RichTextEditorField from "@/components/rich-text-editor-field";
import { getCurrentUser } from "@/lib/auth-session";
import { createProgram } from "@/lib/catalog-db";
import { extractPlainTextFromHtml, sanitizeProgramDescription } from "@/lib/rich-text";

function normalizeText(value: FormDataEntryValue | null): string {
  return typeof value === "string" ? value.trim() : "";
}

async function createProgramAction(formData: FormData): Promise<void> {
  "use server";

  const user = await getCurrentUser();
  if (!user || user.role !== "admin") {
    redirect("/login");
  }

  const name = normalizeText(formData.get("name"));
  const rawDescription = normalizeText(formData.get("description"));
  const description = sanitizeProgramDescription(rawDescription);
  const plainDescription = extractPlainTextFromHtml(description);

  if (!name || !plainDescription) {
    return;
  }

  try {
    await createProgram({ name, description });
  } catch {
    return;
  }

  revalidatePath("/admin/programs");
  revalidatePath("/dashboard/programs");
  redirect("/admin/programs");
}

export default async function AdminNewProgramPage() {
  const currentUser = await getCurrentUser();

  if (!currentUser) {
    redirect("/login");
  }

  if (currentUser.role !== "admin") {
    redirect("/dashboard");
  }

  return (
    <AppShell userRole={currentUser.role} username={currentUser.fullName}>
      <div className="mb-6 flex items-center justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">إضافة برنامج جديد</h1>
          <p className="text-slate-500">أدخل اسم البرنامج واكتب التفاصيل بالمحرر المتقدم.</p>
        </div>
        <div className="inline-flex items-center gap-2 bg-brand-50 text-brand-700 px-4 py-2 rounded-xl border border-brand-100">
          <FolderPlus size={18} />
          <span className="font-bold text-sm">برنامج جديد</span>
        </div>
      </div>

      <div className="mb-6">
        <Link
          href="/admin/programs"
          className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700 hover:bg-slate-50"
        >
          <ArrowRight size={16} />
          الرجوع إلى إدارة البرامج
        </Link>
      </div>

      <div className="rounded-3xl border border-slate-200/70 bg-white p-5 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.02)] md:p-6">
        <form action={createProgramAction} className="grid grid-cols-1 gap-3 md:grid-cols-2">
          <input
            type="text"
            name="name"
            required
            placeholder="اسم البرنامج"
            className="rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-800"
          />

          <div className="md:col-span-2">
            <RichTextEditorField
              name="description"
              placeholder="وصف البرنامج مع العناوين، النقاط، الألوان، الروابط والصور"
            />
          </div>

          <div className="md:col-span-2">
            <button
              type="submit"
              className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-bold text-white transition-colors hover:bg-slate-800 md:w-fit"
            >
              <PlusCircle size={16} />
              حفظ البرنامج
            </button>
          </div>
        </form>
      </div>
    </AppShell>
  );
}
