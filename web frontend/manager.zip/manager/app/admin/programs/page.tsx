import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import Link from "next/link";
import { CheckCircle2, FolderKanban, PencilLine, Search, Trash2 } from "lucide-react";

import AppShell from "@/components/app-shell";
import RichTextEditorField from "@/components/rich-text-editor-field";
import { getCurrentUser } from "@/lib/auth-session";
import {
  deleteProgram,
  listProgramsForAdmin,
  updateProgram,
} from "@/lib/catalog-db";
import { extractPlainTextFromHtml, sanitizeProgramDescription } from "@/lib/rich-text";

function normalizeText(value: FormDataEntryValue | null): string {
  return typeof value === "string" ? value.trim() : "";
}

function containsQuery(text: string, query: string): boolean {
  return text.toLocaleLowerCase("ar").includes(query.toLocaleLowerCase("ar"));
}

function shortenText(text: string, max = 120): string {
  if (text.length <= max) {
    return text;
  }

  return `${text.slice(0, max).trim()}...`;
}

async function updateProgramAction(formData: FormData): Promise<void> {
  "use server";

  const user = await getCurrentUser();
  if (!user || user.role !== "admin") {
    redirect("/login");
  }

  const programId = Number(formData.get("programId"));
  const returnQuery = normalizeText(formData.get("q"));
  const name = normalizeText(formData.get("name"));
  const rawDescription = normalizeText(formData.get("description"));
  const description = sanitizeProgramDescription(rawDescription);
  const plainDescription = extractPlainTextFromHtml(description);

  if (!Number.isInteger(programId) || programId <= 0 || !name || !plainDescription) {
    return;
  }

  try {
    await updateProgram({ id: programId, name, description });
  } catch {
    return;
  }

  revalidatePath("/admin/programs");
  revalidatePath("/admin/plans");
  revalidatePath("/dashboard/programs");
  revalidatePath("/dashboard/plans");

  const params = new URLSearchParams();
  if (returnQuery) {
    params.set("q", returnQuery);
  }
  params.set("updated", "1");

  redirect(`/admin/programs?${params.toString()}`);
}

async function deleteProgramAction(formData: FormData): Promise<void> {
  "use server";

  const user = await getCurrentUser();
  if (!user || user.role !== "admin") {
    redirect("/login");
  }

  const programId = Number(formData.get("programId"));
  if (!Number.isInteger(programId) || programId <= 0) {
    return;
  }

  await deleteProgram(programId);

  revalidatePath("/admin/programs");
  revalidatePath("/admin/plans");
  revalidatePath("/dashboard/programs");
  revalidatePath("/dashboard/plans");
}

export default async function AdminProgramsPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; updated?: string }>;
}) {
  const currentUser = await getCurrentUser();

  if (!currentUser) {
    redirect("/login");
  }

  if (currentUser.role !== "admin") {
    redirect("/dashboard");
  }

  const programs = await listProgramsForAdmin();
  const params = await searchParams;
  const query = typeof params.q === "string" ? params.q.trim() : "";
  const wasUpdated = params.updated === "1";

  const filteredPrograms = !query
    ? programs
    : programs.filter(
        (program) =>
          containsQuery(program.name, query) ||
          containsQuery(extractPlainTextFromHtml(program.description), query),
      );

  return (
    <AppShell userRole={currentUser.role} username={currentUser.fullName}>
      <div className="flex flex-wrap items-end justify-between gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">إدارة البرامج</h1>
          <p className="text-slate-500">واجهة سريعة لإضافة البرامج وتحديثها بدون ازدحام في النماذج.</p>
        </div>
        <div className="inline-flex items-center gap-2 bg-brand-50 text-brand-700 px-4 py-2 rounded-xl border border-brand-100">
          <FolderKanban size={18} />
          <span className="font-bold text-sm">عدد البرامج: {programs.length}</span>
        </div>
      </div>

      <div className="mb-6 flex flex-wrap items-center gap-2">
        <a
          href="/admin/programs"
          className="inline-flex items-center rounded-xl bg-slate-900 px-4 py-2 text-sm font-bold text-white"
        >
          البرامج
        </a>
        <a
          href="/admin/plans"
          className="inline-flex items-center rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700 hover:bg-slate-50"
        >
          إدارة الباقات
        </a>
        <Link
          href="/admin/programs/new"
          className="inline-flex items-center rounded-xl border border-brand-200 bg-brand-50 px-4 py-2 text-sm font-bold text-brand-700 hover:bg-brand-100"
        >
          إضافة برنامج جديد
        </Link>
      </div>

      {wasUpdated && (
        <div className="mb-4 inline-flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-2 text-sm font-bold text-emerald-700">
          <CheckCircle2 size={16} />
          تم حفظ التعديل بنجاح.
        </div>
      )}

      <form action="/admin/programs" method="get" className="mb-6">
        <div className="relative max-w-xl">
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
          <input
            type="text"
            name="q"
            defaultValue={query}
            placeholder="ابحث باسم البرنامج أو جزء من الوصف"
            className="w-full rounded-2xl border border-slate-200 bg-white py-3.5 pr-12 pl-4 text-sm font-semibold text-slate-700 placeholder:text-slate-400 focus:border-brand-500 focus:outline-none focus:ring-4 focus:ring-brand-500/10"
          />
        </div>
      </form>

      <div className="mb-3 text-sm font-semibold text-slate-500">
        {query ? `نتائج البحث: ${filteredPrograms.length}` : `جميع البرامج: ${filteredPrograms.length}`}
      </div>

      <div className="grid grid-cols-1 gap-4">
        {filteredPrograms.map((program) => (
          <div
            key={program.id}
            className="rounded-3xl border border-slate-200/70 bg-white p-5 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.02)]"
          >
            <div className="mb-3 flex flex-wrap items-start justify-between gap-3">
              <div>
                <h3 className="text-base font-extrabold text-slate-900">{program.name}</h3>
                <p className="mt-1 text-sm text-slate-600">
                  {shortenText(extractPlainTextFromHtml(program.description))}
                </p>
              </div>
              <span className="rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1 text-xs font-bold text-slate-600">
                #{program.id}
              </span>
            </div>

            <details className="group rounded-2xl border border-slate-200 bg-slate-50/70 p-3">
              <summary className="flex cursor-pointer list-none items-center gap-2 text-sm font-bold text-slate-700">
                <PencilLine size={16} />
                تعديل البرنامج
              </summary>
              <form action={updateProgramAction} className="mt-3 space-y-3">
                <input type="hidden" name="programId" value={program.id} />
                <input type="hidden" name="q" value={query} />
                <input
                  type="text"
                  name="name"
                  defaultValue={program.name}
                  required
                  className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-bold text-slate-800"
                />
                <RichTextEditorField
                  name="description"
                  initialValue={program.description}
                  placeholder="تعديل وصف البرنامج"
                />
                <button
                  type="submit"
                  className="rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-bold text-white transition-colors hover:bg-slate-800"
                >
                  حفظ التعديل
                </button>
              </form>
            </details>

            <form action={deleteProgramAction} className="mt-3">
              <input type="hidden" name="programId" value={program.id} />
              <button
                type="submit"
                className="inline-flex items-center gap-2 rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-sm font-bold text-rose-700 transition-colors hover:bg-rose-100"
              >
                <Trash2 size={16} />
                حذف البرنامج
              </button>
            </form>
          </div>
        ))}

        {filteredPrograms.length === 0 && (
          <div className="rounded-2xl border border-dashed border-slate-200 bg-white p-8 text-center text-sm font-semibold text-slate-500">
            {query ? "لا توجد نتائج مطابقة للبحث." : "لا توجد برامج حتى الآن."}
          </div>
        )}
      </div>
    </AppShell>
  );
}
