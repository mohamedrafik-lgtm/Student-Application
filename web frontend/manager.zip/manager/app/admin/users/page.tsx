import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { Search, ShieldCheck, UserRoundCog, Users } from "lucide-react";

import AppShell from "@/components/app-shell";
import { getCurrentUser } from "@/lib/auth-session";
import { isUserRole, USER_ROLES } from "@/lib/auth-types";
import { listUsersForAdmin, updateUserRoleById } from "@/lib/auth-db";

async function updateUserRoleAction(formData: FormData): Promise<void> {
  "use server";

  const currentUser = await getCurrentUser();
  if (!currentUser || currentUser.role !== "admin") {
    redirect("/login");
  }

  const userIdValue = formData.get("userId");
  const roleValue = formData.get("role");

  const userId = Number(userIdValue);
  if (!Number.isInteger(userId) || userId <= 0) {
    return;
  }

  if (typeof roleValue !== "string" || !isUserRole(roleValue)) {
    return;
  }

  // Prevent the current admin from removing their own admin role.
  if (userId === currentUser.id && roleValue !== "admin") {
    return;
  }

  await updateUserRoleById(userId, roleValue);
  revalidatePath("/admin/users");
}

export default async function AdminUsersPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const currentUser = await getCurrentUser();

  if (!currentUser) {
    redirect("/login");
  }

  if (currentUser.role !== "admin") {
    redirect("/dashboard");
  }

  const params = await searchParams;
  const query = typeof params.q === "string" ? params.q.trim() : "";

  const users = await listUsersForAdmin(query);

  return (
    <AppShell userRole={currentUser.role} username={currentUser.fullName}>
      <div className="flex flex-wrap items-end justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">إدارة المستخدمين والأدوار</h1>
          <p className="text-slate-500">تحكم في صلاحيات المستخدمين داخل النظام بشكل آمن.</p>
        </div>
        <div className="inline-flex items-center gap-2 bg-brand-50 text-brand-700 px-4 py-2 rounded-xl border border-brand-100">
          <Users size={18} />
          <span className="font-bold text-sm">إجمالي المستخدمين: {users.length}</span>
        </div>
      </div>

      <form action="/admin/users" method="get" className="mb-6">
        <div className="relative max-w-xl">
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            type="text"
            name="q"
            defaultValue={query}
            placeholder="ابحث بالاسم أو البريد الإلكتروني أو رقم الهاتف"
            className="w-full bg-white border border-slate-200 rounded-2xl py-3.5 pr-12 pl-4 text-sm font-semibold text-slate-700 placeholder:text-slate-400 focus:outline-none focus:ring-4 focus:ring-brand-500/10 focus:border-brand-500"
            dir="rtl"
          />
        </div>
      </form>

      <div className="bg-white rounded-3xl border border-slate-200/70 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.02)] overflow-hidden">
        <div className="px-6 py-5 border-b border-slate-100 flex items-center gap-2">
          <UserRoundCog size={18} className="text-brand-600" />
          <h2 className="text-lg font-extrabold text-slate-900">قائمة المستخدمين</h2>
        </div>

        <div className="md:hidden p-4 space-y-3">
          {users.map((managedUser) => {
            const isCurrentAdmin = managedUser.id === currentUser.id;
            return (
              <div key={managedUser.id} className="rounded-2xl border border-slate-200 bg-white p-4 shadow-[0_2px_12px_-4px_rgba(0,0,0,0.04)]">
                <div className="flex items-center gap-3 mb-3">
                  <div className="h-10 w-10 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center font-bold">
                    {managedUser.fullName.charAt(0).toUpperCase()}
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-bold text-slate-900 truncate">{managedUser.fullName}</p>
                    <p className="text-xs text-slate-500 truncate">{managedUser.email ?? "-"}</p>
                    <p className="text-xs text-slate-500 truncate">{managedUser.phone ?? "-"}</p>
                  </div>
                </div>

                <div className="flex items-center justify-between gap-2 mb-3">
                  <span className={`inline-flex px-2.5 py-1 rounded-lg text-xs font-bold ${
                    managedUser.role === "admin"
                      ? "bg-indigo-50 text-indigo-700 border border-indigo-100"
                      : "bg-emerald-50 text-emerald-700 border border-emerald-100"
                  }`}>
                    {managedUser.role === "admin" ? "مدير" : "مستخدم"}
                  </span>
                  {isCurrentAdmin && (
                    <span className="inline-flex items-center gap-1 text-xs text-brand-700 bg-brand-50 border border-brand-100 px-2 py-0.5 rounded-md">
                      <ShieldCheck size={12} />
                      حسابك الحالي
                    </span>
                  )}
                </div>

                <form action={updateUserRoleAction} className="flex items-center gap-2">
                  <input type="hidden" name="userId" value={managedUser.id} />
                  <select
                    name="role"
                    defaultValue={managedUser.role}
                    className="flex-1 bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm font-semibold text-slate-700"
                    disabled={isCurrentAdmin}
                  >
                    {USER_ROLES.map((role) => (
                      <option key={role} value={role}>
                        {role === "admin" ? "مدير" : "مستخدم"}
                      </option>
                    ))}
                  </select>
                  <button
                    type="submit"
                    className="bg-slate-900 hover:bg-slate-800 text-white text-sm font-bold px-3.5 py-2 rounded-xl transition-colors disabled:opacity-50"
                    disabled={isCurrentAdmin}
                  >
                    حفظ
                  </button>
                </form>
              </div>
            );
          })}

          {users.length === 0 && (
            <div className="px-4 py-8 text-center text-sm font-semibold text-slate-500 border border-dashed border-slate-200 rounded-2xl">
              لا توجد نتائج مطابقة للبحث.
            </div>
          )}
        </div>

        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-right">
            <thead className="bg-slate-50">
              <tr>
                <th className="px-6 py-3 text-xs font-bold text-slate-500">المستخدم</th>
                <th className="px-6 py-3 text-xs font-bold text-slate-500">البريد الإلكتروني</th>
                <th className="px-6 py-3 text-xs font-bold text-slate-500">الهاتف</th>
                <th className="px-6 py-3 text-xs font-bold text-slate-500">الدور الحالي</th>
                <th className="px-6 py-3 text-xs font-bold text-slate-500">تعديل الدور</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {users.map((managedUser) => {
                const isCurrentAdmin = managedUser.id === currentUser.id;
                return (
                  <tr key={managedUser.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center font-bold">
                          {managedUser.fullName.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <p className="text-sm font-bold text-slate-900">{managedUser.fullName}</p>
                          {isCurrentAdmin && (
                            <span className="inline-flex items-center gap-1 text-xs text-brand-700 bg-brand-50 border border-brand-100 px-2 py-0.5 rounded-md mt-1">
                              <ShieldCheck size={12} />
                              حسابك الحالي
                            </span>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-700">{managedUser.email ?? "-"}</td>
                    <td className="px-6 py-4 text-sm text-slate-700">{managedUser.phone ?? "-"}</td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex px-2.5 py-1 rounded-lg text-xs font-bold ${
                        managedUser.role === "admin"
                          ? "bg-indigo-50 text-indigo-700 border border-indigo-100"
                          : "bg-emerald-50 text-emerald-700 border border-emerald-100"
                      }`}>
                        {managedUser.role === "admin" ? "مدير" : "مستخدم"}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <form action={updateUserRoleAction} className="flex items-center gap-2">
                        <input type="hidden" name="userId" value={managedUser.id} />
                        <select
                          name="role"
                          defaultValue={managedUser.role}
                          className="bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm font-semibold text-slate-700"
                          disabled={isCurrentAdmin}
                        >
                          {USER_ROLES.map((role) => (
                            <option key={role} value={role}>
                              {role === "admin" ? "مدير" : "مستخدم"}
                            </option>
                          ))}
                        </select>
                        <button
                          type="submit"
                          className="bg-slate-900 hover:bg-slate-800 text-white text-sm font-bold px-3.5 py-2 rounded-xl transition-colors disabled:opacity-50"
                          disabled={isCurrentAdmin}
                        >
                          حفظ
                        </button>
                      </form>
                    </td>
                  </tr>
                );
              })}
              {users.length === 0 && (
                <tr>
                  <td className="px-6 py-10 text-center text-sm font-semibold text-slate-500" colSpan={5}>
                    لا توجد نتائج مطابقة للبحث.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </AppShell>
  );
}
