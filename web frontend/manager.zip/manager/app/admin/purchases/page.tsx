import Link from "next/link";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { ClipboardCheck, Search, ShoppingCart } from "lucide-react";

import AppShell from "@/components/app-shell";
import { getCurrentUser } from "@/lib/auth-session";
import { listPurchasesForAdmin, updatePurchaseStatusById } from "@/lib/purchase-db";
import {
  isPurchaseStatus,
  PURCHASE_STATUSES,
  PURCHASE_STATUS_LABELS,
} from "@/lib/purchase-types";

export const dynamic = "force-dynamic";

function normalizeText(value: FormDataEntryValue | null): string {
  return typeof value === "string" ? value.trim() : "";
}

async function updatePurchaseStatusAction(formData: FormData): Promise<void> {
  "use server";

  const user = await getCurrentUser();
  if (!user || user.role !== "admin") {
    redirect("/login");
  }

  const purchaseId = Number(formData.get("purchaseId"));
  const status = normalizeText(formData.get("status"));
  const adminNote = normalizeText(formData.get("adminNote"));
  const searchQuery = normalizeText(formData.get("searchQuery"));

  if (!Number.isInteger(purchaseId) || purchaseId <= 0 || !isPurchaseStatus(status)) {
    return;
  }

  await updatePurchaseStatusById({
    purchaseId,
    status,
    adminNote: adminNote || null,
  });

  revalidatePath("/admin/purchases");
  revalidatePath("/dashboard/purchases");
  revalidatePath(`/admin/purchases/${purchaseId}`);
  revalidatePath(`/dashboard/purchases/${purchaseId}`);

  const params = new URLSearchParams();
  params.set("updated", String(purchaseId));

  if (searchQuery) {
    params.set("q", searchQuery);
  }

  redirect(`/admin/purchases?${params.toString()}`);
}

function formatEgp(value: number): string {
  return new Intl.NumberFormat("ar-EG", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(value);
}

function formatDate(isoDate: string): string {
  return new Intl.DateTimeFormat("ar-EG", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(new Date(isoDate));
}

export default async function AdminPurchasesPage({
  searchParams,
}: {
  searchParams: Promise<{ updated?: string; q?: string }>;
}) {
  const currentUser = await getCurrentUser();

  if (!currentUser) {
    redirect("/login");
  }

  if (currentUser.role !== "admin") {
    redirect("/dashboard");
  }

  const params = await searchParams;
  const query = typeof params.q === "string" ? params.q.trim() : "";
  const purchases = await listPurchasesForAdmin(query);

  return (
    <AppShell userRole={currentUser.role} username={currentUser.fullName}>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">مراجعة المشتريات</h1>
          <p className="text-slate-500">راجع طلبات الشراء وحدد حالة كل طلب.</p>
        </div>
        <div className="inline-flex items-center gap-2 rounded-xl border border-brand-100 bg-brand-50 px-4 py-2 text-brand-700">
          <ShoppingCart size={18} />
          <span className="text-sm font-bold">
            {query ? `نتائج البحث: ${purchases.length}` : `إجمالي الطلبات: ${purchases.length}`}
          </span>
        </div>
      </div>

      <form action="/admin/purchases" method="get" className="mb-4">
        <div className="relative max-w-xl">
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            type="text"
            name="q"
            defaultValue={query}
            placeholder="ابحث باسم المشتري، هاتفه، اسم الباقة، رقم التحويل أو رقم الطلب"
            className="w-full rounded-2xl border border-slate-200 bg-white py-3.5 pr-12 pl-4 text-sm font-semibold text-slate-700 placeholder:text-slate-400 focus:border-brand-500 focus:outline-none focus:ring-4 focus:ring-brand-500/10"
            dir="rtl"
          />
        </div>
      </form>

      {params.updated && (
        <div className="mb-4 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-bold text-emerald-700">
          تم تحديث حالة الطلب بنجاح.
        </div>
      )}

      <div className="grid grid-cols-1 gap-4">
        {purchases.map((purchase) => (
          <div
            key={purchase.id}
            className="rounded-3xl border border-slate-200/70 bg-white p-5 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.02)]"
          >
            <div className="mb-4 flex flex-wrap items-start justify-between gap-3 border-b border-slate-100 pb-4">
              <div>
                <h2 className="text-base font-extrabold text-slate-900">
                  {purchase.userFullName ?? "مستخدم"} - {purchase.planName ?? "باقة"}
                </h2>
                <p className="mt-1 text-sm text-slate-600">رقم الطلب: #{purchase.id}</p>
                <p className="mt-1 text-sm text-slate-600">تاريخ الإنشاء: {formatDate(purchase.createdAt)}</p>
              </div>
              <span
                className={`rounded-lg border px-2.5 py-1 text-xs font-bold ${
                  purchase.status === "approved"
                    ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                    : purchase.status === "rejected"
                      ? "border-rose-200 bg-rose-50 text-rose-700"
                      : "border-amber-200 bg-amber-50 text-amber-700"
                }`}
              >
                {PURCHASE_STATUS_LABELS[purchase.status]}
              </span>
            </div>

            <div className="mb-4 grid grid-cols-1 gap-2 md:grid-cols-2">
              <div className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm font-semibold text-slate-700">
                البرنامج: {purchase.programName ?? "-"}
              </div>
              <div className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm font-semibold text-slate-700">
                المبلغ: {formatEgp(purchase.amountEgp)} جنيه
              </div>
              <div className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm font-semibold text-slate-700">
                هاتف المشتري: {purchase.userPhone ?? "-"}
              </div>
              <div className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm font-semibold text-slate-700">
                رقم التحويل إليه: {purchase.paymentPhoneTo}
              </div>
              <div className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm font-semibold text-slate-700 md:col-span-2">
                رقم المحول منه: {purchase.transferFromPhone}
              </div>
            </div>

            <form action={updatePurchaseStatusAction} className="grid grid-cols-1 gap-3 md:grid-cols-3">
              <input type="hidden" name="purchaseId" value={purchase.id} />
              <input type="hidden" name="searchQuery" value={query} />

              <select
                name="status"
                defaultValue={purchase.status}
                className="rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-700"
              >
                {PURCHASE_STATUSES.map((status) => (
                  <option key={status} value={status}>
                    {PURCHASE_STATUS_LABELS[status]}
                  </option>
                ))}
              </select>

              <input
                type="text"
                name="adminNote"
                defaultValue={purchase.adminNote ?? ""}
                placeholder="ملاحظة الإدارة (اختياري)"
                className="rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-700 md:col-span-2"
              />

              <div className="md:col-span-3">
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="submit"
                    className="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-bold text-white hover:bg-slate-800"
                  >
                    <ClipboardCheck size={16} />
                    حفظ حالة الطلب
                  </button>
                  <Link
                    href={`/admin/purchases/${purchase.id}`}
                    className="inline-flex rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-bold text-slate-700 hover:bg-slate-50"
                  >
                    فتح التفاصيل والمحادثة
                  </Link>
                </div>
              </div>
            </form>
          </div>
        ))}

        {purchases.length === 0 && (
          <div className="rounded-2xl border border-dashed border-slate-200 bg-white p-8 text-center text-sm font-semibold text-slate-500">
            {query ? "لا توجد نتائج مطابقة للبحث." : "لا توجد طلبات شراء حتى الآن."}
          </div>
        )}
      </div>
    </AppShell>
  );
}
