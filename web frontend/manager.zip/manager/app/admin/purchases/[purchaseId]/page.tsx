import Link from "next/link";
import { redirect } from "next/navigation";
import { ArrowRight } from "lucide-react";

import AppShell from "@/components/app-shell";
import PurchaseLiveChat from "@/components/purchase-live-chat";
import { getCurrentUser } from "@/lib/auth-session";
import {
  getPurchaseByIdForAdmin,
  listPurchaseMessages,
} from "@/lib/purchase-db";
import { PURCHASE_STATUS_LABELS } from "@/lib/purchase-types";

function formatEgp(value: number): string {
  return new Intl.NumberFormat("ar-EG", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(value);
}

export default async function AdminPurchaseDetailsPage({
  params,
}: {
  params: Promise<{ purchaseId: string }>;
}) {
  const user = await getCurrentUser();

  if (!user) {
    redirect("/login");
  }

  if (user.role !== "admin") {
    redirect("/dashboard");
  }

  const routeParams = await params;
  const purchaseId = Number(routeParams.purchaseId);

  if (!Number.isInteger(purchaseId) || purchaseId <= 0) {
    redirect("/admin/purchases");
  }

  const purchase = await getPurchaseByIdForAdmin(purchaseId);
  if (!purchase) {
    redirect("/admin/purchases");
  }

  const initialMessages = await listPurchaseMessages(purchase.id);

  return (
    <AppShell userRole={user.role} username={user.fullName}>
      <div className="mb-6">
        <Link
          href="/admin/purchases"
          className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700 hover:bg-slate-50"
        >
          <ArrowRight size={16} />
          الرجوع إلى مراجعة المشتريات
        </Link>
      </div>

      <div className="mb-6 rounded-3xl border border-slate-200/70 bg-white p-5 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.02)]">
        <div className="mb-3 flex flex-wrap items-start justify-between gap-3">
          <div>
            <h1 className="text-2xl font-extrabold text-slate-900">
              {purchase.userFullName ?? "مستخدم"} - {purchase.planName ?? "باقة"}
            </h1>
            <p className="mt-1 text-sm text-slate-600">البرنامج: {purchase.programName ?? "-"}</p>
            <p className="mt-1 text-sm text-slate-600">المبلغ: {formatEgp(purchase.amountEgp)} جنيه</p>
            <p className="mt-1 text-sm text-slate-600">هاتف المشتري: {purchase.userPhone ?? "-"}</p>
            <p className="mt-1 text-sm text-slate-600">التحويل إلى: {purchase.paymentPhoneTo}</p>
            <p className="mt-1 text-sm text-slate-600">التحويل من: {purchase.transferFromPhone}</p>
          </div>
          <span
            className={`rounded-lg border px-2.5 py-1 text-xs font-bold ${
              purchase.status === "approved"
                ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                : purchase.status === "rejected"
                  ? "border-rose-200 bg-rose-50 text-rose-700"
                  : "border-amber-200 bg-amber-50 text-amber-700"
            }`}
          >
            {PURCHASE_STATUS_LABELS[purchase.status]}
          </span>
        </div>
      </div>

      <PurchaseLiveChat
        purchaseId={purchase.id}
        currentUserId={user.id}
        currentUserRole={user.role}
        initialMessages={initialMessages}
      />
    </AppShell>
  );
}
