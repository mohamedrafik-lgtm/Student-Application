import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import Link from "next/link";
import { Layers3, PencilLine, Search, Trash2 } from "lucide-react";

import AppShell from "@/components/app-shell";
import { getCurrentUser } from "@/lib/auth-session";
import {
  deletePlan,
  listPlansByProgramId,
  listProgramsForAdmin,
  updatePlan,
} from "@/lib/catalog-db";
import {
  getPlanDurationLabel,
  PLAN_DURATION_CODES,
  PLAN_DURATION_LABELS,
  resolvePlanDurationInput,
} from "@/lib/plan-duration";

function normalizeText(value: FormDataEntryValue | null): string {
  return typeof value === "string" ? value.trim() : "";
}

function containsQuery(text: string, query: string): boolean {
  return text.toLocaleLowerCase("ar").includes(query.toLocaleLowerCase("ar"));
}

function formatEgp(value: number): string {
  return new Intl.NumberFormat("ar-EG", {
    maximumFractionDigits: 2,
    minimumFractionDigits: 0,
  }).format(value);
}

function shortenText(text: string, max = 140): string {
  if (text.length <= max) {
    return text;
  }

  return `${text.slice(0, max).trim()}...`;
}

function normalizePrice(value: FormDataEntryValue | null): number | null {
  const parsed = Number(typeof value === "string" ? value.trim() : "");
  if (!Number.isFinite(parsed) || parsed < 0) {
    return null;
  }
  return parsed;
}

async function updatePlanAction(formData: FormData): Promise<void> {
  "use server";

  const user = await getCurrentUser();
  if (!user || user.role !== "admin") {
    redirect("/login");
  }

  const planId = Number(formData.get("planId"));
  const name = normalizeText(formData.get("name"));
  const description = normalizeText(formData.get("description"));
  const priceEgp = normalizePrice(formData.get("priceEgp"));
  const isActive = normalizeText(formData.get("isActive")) === "on";
  const durationInput = resolvePlanDurationInput({
    rawCode: formData.get("durationCode"),
    rawCustomLabel: formData.get("durationCustomLabel"),
  });

  if (
    !Number.isInteger(planId) ||
    planId <= 0 ||
    !name ||
    !description ||
    priceEgp === null ||
    !durationInput
  ) {
    return;
  }

  await updatePlan({
    id: planId,
    name,
    description,
    priceEgp,
    isActive,
    durationCode: durationInput.code,
    durationCustomLabel: durationInput.customLabel,
  });

  revalidatePath("/admin/plans");
  revalidatePath("/dashboard/plans");
  revalidatePath("/dashboard/programs");
}

async function deletePlanAction(formData: FormData): Promise<void> {
  "use server";

  const user = await getCurrentUser();
  if (!user || user.role !== "admin") {
    redirect("/login");
  }

  const planId = Number(formData.get("planId"));
  if (!Number.isInteger(planId) || planId <= 0) {
    return;
  }

  await deletePlan(planId);

  revalidatePath("/admin/plans");
  revalidatePath("/dashboard/plans");
  revalidatePath("/dashboard/programs");
}

export default async function AdminPlansPage({
  searchParams,
}: {
  searchParams: Promise<{ programId?: string; q?: string }>;
}) {
  const currentUser = await getCurrentUser();

  if (!currentUser) {
    redirect("/login");
  }

  if (currentUser.role !== "admin") {
    redirect("/dashboard");
  }

  const programs = await listProgramsForAdmin();
  const params = await searchParams;
  const requestedProgramId = Number(params.programId);
  const query = typeof params.q === "string" ? params.q.trim() : "";

  const selectedProgram =
    programs.find((program) => program.id === requestedProgramId) ?? programs[0] ?? null;

  const plans = selectedProgram ? await listPlansByProgramId(selectedProgram.id) : [];
  const filteredPlans = !query
    ? plans
    : plans.filter(
        (plan) =>
          containsQuery(plan.name, query) ||
          containsQuery(plan.description, query) ||
          containsQuery(getPlanDurationLabel(plan.durationCode, plan.durationCustomLabel), query),
      );
  const activeCount = filteredPlans.filter((plan) => plan.isActive).length;
  const inactiveCount = filteredPlans.length - activeCount;

  return (
    <AppShell userRole={currentUser.role} username={currentUser.fullName}>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">إدارة الباقات</h1>
          <p className="text-slate-500">فلترة سريعة للباقات مع تعديل عند الطلب بدل ازدحام النماذج.</p>
        </div>
        <div className="inline-flex items-center gap-2 bg-brand-50 text-brand-700 px-4 py-2 rounded-xl border border-brand-100">
          <Layers3 size={18} />
          <span className="font-bold text-sm">عدد الباقات: {filteredPlans.length}</span>
        </div>
      </div>

      <div className="mb-6 flex flex-wrap items-center gap-2">
        <a
          href="/admin/programs"
          className="inline-flex items-center rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700 hover:bg-slate-50"
        >
          إدارة البرامج
        </a>
        <a
          href="/admin/plans"
          className="inline-flex items-center rounded-xl bg-slate-900 px-4 py-2 text-sm font-bold text-white"
        >
          الباقات
        </a>
        <Link
          href={selectedProgram ? `/admin/plans/new?programId=${selectedProgram.id}` : "/admin/plans/new"}
          className="inline-flex items-center rounded-xl border border-brand-200 bg-brand-50 px-4 py-2 text-sm font-bold text-brand-700 hover:bg-brand-100"
        >
          إضافة باقة جديدة
        </Link>
      </div>

      <form method="get" action="/admin/plans" className="mb-6 rounded-3xl border border-slate-200/70 bg-white p-5">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
          <div>
            <label className="mb-2 block text-sm font-extrabold text-slate-800">البرنامج</label>
            <select
              name="programId"
              defaultValue={selectedProgram?.id}
              className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-700"
            >
              {programs.map((program) => (
                <option key={program.id} value={program.id}>
                  {program.name}
                </option>
              ))}
            </select>
          </div>
          <div className="md:col-span-2">
            <label className="mb-2 block text-sm font-extrabold text-slate-800">بحث داخل الباقات</label>
            <div className="relative">
              <Search className="absolute right-4 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                name="q"
                defaultValue={query}
                placeholder="ابحث باسم الباقة أو الوصف"
                className="w-full rounded-xl border border-slate-200 bg-white py-3 pr-12 pl-4 text-sm font-semibold text-slate-700"
              />
            </div>
          </div>
        </div>
        <div className="mt-3">
          <button
            type="submit"
            className="w-full rounded-xl bg-slate-900 px-4 py-3 text-sm font-bold text-white transition-colors hover:bg-slate-800 md:w-auto"
          >
            تطبيق الفلاتر
          </button>
        </div>
      </form>

      {selectedProgram ? (
        <>
          <div className="mb-6 grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div className="rounded-2xl border border-slate-200 bg-white p-4">
              <p className="text-xs font-bold text-slate-500">إجمالي النتائج</p>
              <p className="mt-1 text-2xl font-extrabold text-slate-900">{filteredPlans.length}</p>
            </div>
            <div className="rounded-2xl border border-emerald-200 bg-emerald-50/60 p-4">
              <p className="text-xs font-bold text-emerald-700">باقات نشطة</p>
              <p className="mt-1 text-2xl font-extrabold text-emerald-800">{activeCount}</p>
            </div>
            <div className="rounded-2xl border border-amber-200 bg-amber-50/60 p-4">
              <p className="text-xs font-bold text-amber-700">باقات غير نشطة</p>
              <p className="mt-1 text-2xl font-extrabold text-amber-800">{inactiveCount}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {filteredPlans.map((plan) => (
              <div key={plan.id} className="rounded-3xl border border-slate-200/70 bg-white p-5 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.02)]">
                <div className="mb-3 flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <h3 className="text-base font-extrabold text-slate-900">{plan.name}</h3>
                    <p className="mt-1 text-sm text-slate-600">{shortenText(plan.description)}</p>
                    <div className="mt-2 flex flex-wrap items-center gap-2">
                      <span className="rounded-lg border border-brand-100 bg-brand-50 px-2.5 py-1 text-xs font-bold text-brand-700">
                        {formatEgp(plan.priceEgp)} جنيه
                      </span>
                      <span className="rounded-lg border border-indigo-100 bg-indigo-50 px-2.5 py-1 text-xs font-bold text-indigo-700">
                        {getPlanDurationLabel(plan.durationCode, plan.durationCustomLabel)}
                      </span>
                      <span
                        className={`rounded-lg border px-2.5 py-1 text-xs font-bold ${
                          plan.isActive
                            ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                            : "border-amber-200 bg-amber-50 text-amber-700"
                        }`}
                      >
                        {plan.isActive ? "نشطة" : "غير نشطة"}
                      </span>
                    </div>
                  </div>
                  <span className="rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1 text-xs font-bold text-slate-600">
                    #{plan.id}
                  </span>
                </div>

                <details className="group rounded-2xl border border-slate-200 bg-slate-50/70 p-3">
                  <summary className="flex cursor-pointer list-none items-center gap-2 text-sm font-bold text-slate-700">
                    <PencilLine size={16} />
                    تعديل الباقة
                  </summary>
                  <form action={updatePlanAction} className="mt-3 space-y-3">
                    <input type="hidden" name="planId" value={plan.id} />
                    <input
                      type="text"
                      name="name"
                      defaultValue={plan.name}
                      required
                      className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-bold text-slate-800"
                    />
                    <textarea
                      name="description"
                      defaultValue={plan.description}
                      rows={6}
                      required
                      className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-medium text-slate-700"
                    />
                    <input
                      type="number"
                      name="priceEgp"
                      defaultValue={plan.priceEgp}
                      min="0"
                      step="0.01"
                      required
                      className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-800"
                    />
                    <select
                      name="durationCode"
                      defaultValue={plan.durationCode}
                      className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-700"
                    >
                      {PLAN_DURATION_CODES.map((durationCode) => (
                        <option key={durationCode} value={durationCode}>
                          {PLAN_DURATION_LABELS[durationCode]}
                        </option>
                      ))}
                    </select>
                    <input
                      type="text"
                      name="durationCustomLabel"
                      defaultValue={plan.durationCustomLabel ?? ""}
                      placeholder="في حالة مخصص اكتب المدة"
                      className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-800"
                    />
                    <label className="inline-flex items-center gap-2 text-sm font-semibold text-slate-700">
                      <input type="checkbox" name="isActive" defaultChecked={plan.isActive} className="h-4 w-4" />
                      الباقة نشطة للمستخدمين
                    </label>
                    <button
                      type="submit"
                      className="rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-bold text-white transition-colors hover:bg-slate-800"
                    >
                      حفظ التعديل
                    </button>
                  </form>
                </details>

                <form action={deletePlanAction} className="mt-3">
                  <input type="hidden" name="planId" value={plan.id} />
                  <button
                    type="submit"
                    className="inline-flex items-center gap-2 rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-sm font-bold text-rose-700 transition-colors hover:bg-rose-100"
                  >
                    <Trash2 size={16} />
                    حذف الباقة
                  </button>
                </form>
              </div>
            ))}

            {filteredPlans.length === 0 && (
              <div className="rounded-2xl border border-dashed border-slate-200 bg-white p-8 text-center text-sm font-semibold text-slate-500">
                {query ? "لا توجد نتائج مطابقة للبحث في هذا البرنامج." : "لا توجد باقات لهذا البرنامج حتى الآن."}
              </div>
            )}
          </div>
        </>
      ) : (
        <div className="text-center text-sm font-semibold text-slate-500 bg-white border border-dashed border-slate-200 rounded-2xl p-8">
          لا توجد برامج بعد. أضف برنامجًا أولًا من صفحة إدارة البرامج.
        </div>
      )}
    </AppShell>
  );
}
