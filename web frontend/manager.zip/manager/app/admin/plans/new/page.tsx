import Link from "next/link";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { ArrowRight, Layers3, PlusCircle } from "lucide-react";

import AppShell from "@/components/app-shell";
import { getCurrentUser } from "@/lib/auth-session";
import { createPlan, listProgramsForAdmin } from "@/lib/catalog-db";
import { PLAN_DURATION_CODES, PLAN_DURATION_LABELS, resolvePlanDurationInput } from "@/lib/plan-duration";

function normalizeText(value: FormDataEntryValue | null): string {
  return typeof value === "string" ? value.trim() : "";
}

function normalizePrice(value: FormDataEntryValue | null): number | null {
  const parsed = Number(typeof value === "string" ? value.trim() : "");
  if (!Number.isFinite(parsed) || parsed < 0) {
    return null;
  }
  return parsed;
}

async function createPlanAction(formData: FormData): Promise<void> {
  "use server";

  const user = await getCurrentUser();
  if (!user || user.role !== "admin") {
    redirect("/login");
  }

  const programId = Number(formData.get("programId"));
  const name = normalizeText(formData.get("name"));
  const description = normalizeText(formData.get("description"));
  const priceEgp = normalizePrice(formData.get("priceEgp"));
  const durationInput = resolvePlanDurationInput({
    rawCode: formData.get("durationCode"),
    rawCustomLabel: formData.get("durationCustomLabel"),
  });

  if (
    !Number.isInteger(programId) ||
    programId <= 0 ||
    !name ||
    !description ||
    priceEgp === null ||
    !durationInput
  ) {
    return;
  }

  try {
    await createPlan({
      programId,
      name,
      description,
      priceEgp,
      durationCode: durationInput.code,
      durationCustomLabel: durationInput.customLabel,
    });
  } catch {
    return;
  }

  revalidatePath("/admin/plans");
  revalidatePath("/dashboard/plans");
  revalidatePath("/dashboard/programs");
  redirect(`/admin/plans?programId=${programId}`);
}

export default async function AdminNewPlanPage({
  searchParams,
}: {
  searchParams: Promise<{ programId?: string }>;
}) {
  const currentUser = await getCurrentUser();

  if (!currentUser) {
    redirect("/login");
  }

  if (currentUser.role !== "admin") {
    redirect("/dashboard");
  }

  const programs = await listProgramsForAdmin();
  const params = await searchParams;
  const requestedProgramId = Number(params.programId);

  const selectedProgram =
    programs.find((program) => program.id === requestedProgramId) ?? programs[0] ?? null;

  return (
    <AppShell userRole={currentUser.role} username={currentUser.fullName}>
      <div className="mb-6 flex items-center justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">إضافة باقة جديدة</h1>
          <p className="text-slate-500">أنشئ الباقة واختر البرنامج المناسب لها من صفحة مستقلة.</p>
        </div>
        <div className="inline-flex items-center gap-2 bg-brand-50 text-brand-700 px-4 py-2 rounded-xl border border-brand-100">
          <Layers3 size={18} />
          <span className="font-bold text-sm">باقة جديدة</span>
        </div>
      </div>

      <div className="mb-6">
        <Link
          href={selectedProgram ? `/admin/plans?programId=${selectedProgram.id}` : "/admin/plans"}
          className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700 hover:bg-slate-50"
        >
          <ArrowRight size={16} />
          الرجوع إلى إدارة الباقات
        </Link>
      </div>

      {programs.length > 0 ? (
        <div className="rounded-3xl border border-slate-200/70 bg-white p-5 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.02)] md:p-6">
          <form action={createPlanAction} className="grid grid-cols-1 gap-3 md:grid-cols-2">
            <div className="md:col-span-2">
              <label className="mb-2 block text-sm font-extrabold text-slate-800">البرنامج</label>
              <select
                name="programId"
                defaultValue={selectedProgram?.id}
                className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-700"
              >
                {programs.map((program) => (
                  <option key={program.id} value={program.id}>
                    {program.name}
                  </option>
                ))}
              </select>
            </div>

            <input
              type="text"
              name="name"
              required
              placeholder="اسم الباقة"
              className="rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-800"
            />

            <input
              type="number"
              name="priceEgp"
              min="0"
              step="0.01"
              required
              placeholder="السعر بالجنيه المصري"
              className="rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-800"
            />

            <div>
              <label className="mb-2 block text-sm font-extrabold text-slate-800">مدة الباقة</label>
              <select
                name="durationCode"
                defaultValue="unspecified"
                className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-700"
              >
                {PLAN_DURATION_CODES.map((durationCode) => (
                  <option key={durationCode} value={durationCode}>
                    {PLAN_DURATION_LABELS[durationCode]}
                  </option>
                ))}
              </select>
            </div>

            <input
              type="text"
              name="durationCustomLabel"
              placeholder="في حالة مخصص اكتب المدة (مثال: 45 يومًا)"
              className="rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-800"
            />

            <div className="md:col-span-2">
              <textarea
                name="description"
                rows={6}
                required
                placeholder="الوصف الطويل مع مميزات الباقة"
                className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-medium text-slate-700"
              />
            </div>

            <div className="md:col-span-2">
              <button
                type="submit"
                className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-bold text-white transition-colors hover:bg-slate-800 md:w-fit"
              >
                <PlusCircle size={16} />
                حفظ الباقة
              </button>
            </div>
          </form>
        </div>
      ) : (
        <div className="rounded-2xl border border-dashed border-slate-200 bg-white p-8 text-center text-sm font-semibold text-slate-500">
          لا توجد برامج بعد. أضف برنامجًا أولًا من صفحة إدارة البرامج.
        </div>
      )}
    </AppShell>
  );
}
