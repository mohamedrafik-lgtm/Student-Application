import Link from "next/link";
import { Changa, Tajawal } from "next/font/google";
import { notFound } from "next/navigation";

import PublicMobileMenu from "@/components/public-mobile-menu";
import { getCurrentUser } from "@/lib/auth-session";
import { getProgramById, listPublicPlans } from "@/lib/catalog-db";
import { getPlanDurationLabel } from "@/lib/plan-duration";
import { extractPlainTextFromHtml, sanitizeProgramDescription } from "@/lib/rich-text";

const changa = Changa({
  subsets: ["arabic", "latin"],
  weight: ["600", "700", "800"],
});

const tajawal = Tajawal({
  subsets: ["arabic", "latin"],
  weight: ["400", "500", "700", "800"],
});

function formatEgp(value: number): string {
  return new Intl.NumberFormat("ar-EG", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(value);
}

function createSnippet(value: string, maxLength = 140): string {
  const plain = extractPlainTextFromHtml(value);
  if (!plain) {
    return "تفاصيل واضحة وباقات مرنة مصممة لدعم تشغيل أعمالك بكفاءة.";
  }
  if (plain.length <= maxLength) {
    return plain;
  }
  return `${plain.slice(0, maxLength).trim()}...`;
}

export default async function PublicProgramPlansPage({
  params,
}: {
  params: Promise<{ programId: string }>;
}) {
  const routeParams = await params;
  const programId = Number(routeParams.programId);

  if (!Number.isInteger(programId) || programId <= 0) {
    notFound();
  }

  const [program, plans, currentUser] = await Promise.all([
    getProgramById(programId),
    listPublicPlans(programId),
    getCurrentUser(),
  ]);

  if (!program) {
    notFound();
  }

  const minPrice = plans.length > 0 ? Math.min(...plans.map((plan) => plan.priceEgp)) : null;
  const dashboardHref = currentUser?.role === "admin" ? "/admin" : "/dashboard";
  const formattedProgramDescription = sanitizeProgramDescription(program.description);
  const mobileLinks = [
    { href: "/", label: "الصفحة الرئيسية" },
    { href: "#program-info", label: "البرنامج المختار", isAnchor: true },
    { href: "#steps", label: "خطوات الاشتراك", isAnchor: true },
    { href: "#plans", label: "الباقات", isAnchor: true },
  ];
  const mobilePrimaryAction = currentUser
    ? { href: dashboardHref, label: "لوحة التحكم" }
    : { href: "/register", label: "إنشاء حساب" };
  const mobileSecondaryAction = currentUser ? undefined : { href: "/login", label: "تسجيل الدخول" };

  return (
    <div className={`${tajawal.className} min-h-screen bg-slate-50 text-slate-900`}>
      <div className="pointer-events-none fixed inset-0 -z-10 [background:radial-gradient(900px_360px_at_0%_0%,rgba(20,184,166,0.14),transparent_60%),radial-gradient(900px_360px_at_100%_0%,rgba(15,118,110,0.11),transparent_55%),linear-gradient(to_bottom,#f8fafc,#effaf7)]" />

      <div className="mx-auto w-full max-w-7xl px-4 pb-12 pt-6 sm:px-6 lg:px-8">
        <header className="sticky top-4 z-30 rounded-3xl border border-brand-100 bg-white/80 p-3 shadow-[0_18px_40px_-30px_rgba(20,184,166,0.35)] backdrop-blur-xl">
          <div className="flex items-center justify-between gap-2 rounded-2xl border border-brand-100 bg-white px-3 py-2.5 sm:gap-3 sm:px-4 sm:py-3">
            <Link href="/" className="group flex min-w-0 items-center gap-2.5 sm:gap-3">
              <span className="relative grid h-11 w-11 place-items-center">
                <span className="absolute inset-0 rounded-full bg-brand-100/80 blur-sm" />
                <span className="absolute inset-0 [clip-path:polygon(50%_0%,0%_100%,100%_100%)] bg-linear-to-b from-brand-500 via-brand-600 to-brand-700 shadow-[0_16px_26px_-14px_rgba(20,184,166,0.75)] transition-transform group-hover:scale-105" />
                <span className="absolute inset-x-2 bottom-1 top-3 [clip-path:polygon(50%_0%,0%_100%,100%_100%)] bg-white/25" />
                <span className="absolute left-1/2 top-0.5 h-1.5 w-1.5 -translate-x-1/2 rounded-full bg-emerald-200" />
              </span>
              <span className="min-w-0">
                <span className={`${changa.className} block truncate text-sm font-extrabold tracking-wide text-slate-900 sm:text-base`}>TIBA SOFTWARE</span>
                <span className="hidden text-[11px] font-bold text-slate-500 sm:block">PROGRAM PLANS</span>
              </span>
            </Link>

            <div className="hidden items-center gap-2 lg:flex">
              <Link
                href="/"
                className="rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-extrabold text-slate-700 transition-colors hover:bg-slate-50"
              >
                العودة للبرامج
              </Link>
              {currentUser ? (
                <Link
                  href={dashboardHref}
                  className="rounded-xl bg-brand-600 px-4 py-2.5 text-sm font-extrabold text-white transition-colors hover:bg-brand-700"
                >
                  لوحة التحكم
                </Link>
              ) : (
                <Link
                  href="/register"
                  className="rounded-xl bg-brand-600 px-4 py-2.5 text-sm font-extrabold text-white transition-colors hover:bg-brand-700"
                >
                  إنشاء حساب
                </Link>
              )}
            </div>

            <PublicMobileMenu
              links={mobileLinks}
              primaryAction={mobilePrimaryAction}
              secondaryAction={mobileSecondaryAction}
            />
          </div>
        </header>

        <main className="mt-7">
          <section id="program-info" className="relative overflow-hidden rounded-[28px] border border-brand-100 bg-white px-7 py-10 shadow-[0_28px_70px_-42px_rgba(20,184,166,0.28)] lg:px-10 lg:py-12">
            <div className="pointer-events-none absolute -left-20 -top-24 h-64 w-64 rounded-full bg-brand-100/65 blur-3xl" />
            <div className="pointer-events-none absolute -bottom-24 -right-16 h-72 w-72 rounded-full bg-emerald-100/65 blur-3xl" />

            <p className="relative z-10 text-xs font-black text-brand-700">البرنامج المختار</p>
            <h1 className={`${changa.className} relative z-10 mt-2 text-4xl font-extrabold text-slate-900 lg:text-5xl`}>{program.name}</h1>

            <div className="relative z-10 mt-4 max-w-4xl rounded-2xl border border-brand-100 bg-brand-50/60 p-5">
              {formattedProgramDescription ? (
                <div
                  className="rich-content text-sm md:text-base"
                  dangerouslySetInnerHTML={{
                    __html: formattedProgramDescription,
                  }}
                />
              ) : (
                <p className="text-sm font-semibold leading-8 text-slate-600">لا يوجد وصف متاح لهذا البرنامج حاليًا.</p>
              )}
            </div>

            <div className="relative z-10 mt-6 inline-flex rounded-lg border border-brand-100 bg-brand-50 px-3 py-2 text-xs font-black text-brand-700">
              الاشتراك في أي باقة يتطلب تسجيل حساب.
            </div>
          </section>

          <section id="steps" className="mt-7 grid grid-cols-1 gap-3 md:grid-cols-3">
            <div className="rounded-2xl border border-brand-100 bg-white p-4">
              <p className="text-xs font-black text-slate-500">خطوة 1</p>
              <p className="mt-1 text-sm font-black text-slate-900">اختر الباقة المناسبة</p>
            </div>
            <div className="rounded-2xl border border-brand-100 bg-white p-4">
              <p className="text-xs font-black text-slate-500">خطوة 2</p>
              <p className="mt-1 text-sm font-black text-slate-900">سجل حساب أو ادخل للنظام</p>
            </div>
            <div className="rounded-2xl border border-brand-100 bg-white p-4">
              <p className="text-xs font-black text-slate-500">خطوة 3</p>
              <p className="mt-1 text-sm font-black text-slate-900">أرسل طلب الاشتراك وتابع حالته</p>
            </div>
          </section>

          <section id="plans" className="mt-10">
            <div className="mb-5 flex items-end justify-between gap-3">
              <div>
                <h2 className={`${changa.className} text-3xl font-extrabold text-slate-900`}>باقات {program.name}</h2>
                <p className="mt-1 text-sm font-semibold text-slate-500">اختر الباقة المناسبة وابدأ الاشتراك.</p>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
              {plans.map((plan) => {
                const isNormalUser = currentUser && currentUser.role !== "admin";
                const isAdmin = currentUser?.role === "admin";
                const ctaHref = isNormalUser
                  ? `/dashboard/purchases/new?planId=${plan.id}`
                  : isAdmin
                    ? "/admin"
                    : "/register";
                const ctaLabel = isNormalUser
                  ? "اشترك الآن"
                  : isAdmin
                    ? "لوحة الإدارة"
                    : "أنشئ حساب للاشتراك";
                const isEconomical = minPrice !== null && plan.priceEgp === minPrice;

                return (
                  <article
                    key={plan.id}
                    className="group relative overflow-hidden rounded-3xl border border-brand-100 bg-white p-6 shadow-[0_18px_40px_-32px_rgba(20,184,166,0.28)] transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_24px_48px_-30px_rgba(13,148,136,0.3)]"
                  >
                    {isEconomical && (
                      <span className="absolute left-4 top-4 rounded-full border border-emerald-200 bg-emerald-50 px-2.5 py-1 text-[11px] font-black text-emerald-700">
                        الأكثر اقتصادية
                      </span>
                    )}

                    <h3 className={`${changa.className} text-xl font-extrabold text-slate-900`}>{plan.name}</h3>
                    <p className="mt-2 text-sm font-semibold leading-7 text-slate-600">{createSnippet(plan.description, 120)}</p>

                    <div className="mt-5 border-t border-slate-100 pt-4">
                      <p className="text-2xl font-black text-slate-900">{formatEgp(plan.priceEgp)} ج</p>
                      <p className="mt-1 text-xs font-bold text-slate-500">
                        المدة: {getPlanDurationLabel(plan.durationCode, plan.durationCustomLabel)}
                      </p>
                    </div>

                    <Link
                      href={ctaHref}
                      className="mt-5 inline-flex w-full items-center justify-center rounded-xl bg-brand-600 px-4 py-2.5 text-sm font-black text-white transition-colors hover:bg-brand-700"
                    >
                      {ctaLabel}
                    </Link>
                  </article>
                );
              })}

              {plans.length === 0 && (
                <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-8 text-center text-sm font-semibold text-slate-500 md:col-span-2 xl:col-span-3">
                  لا توجد باقات نشطة لهذا البرنامج حاليًا.
                </div>
              )}
            </div>
          </section>
        </main>
      </div>
    </div>
  );
}
