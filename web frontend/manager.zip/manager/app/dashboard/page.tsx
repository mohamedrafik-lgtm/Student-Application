import Link from "next/link";
import { redirect } from "next/navigation";
import AppShell from "../../components/app-shell";
import { getCurrentUser } from "@/lib/auth-session";
import { getUserDashboardData } from "@/lib/dashboard-db";
import { PURCHASE_STATUS_LABELS } from "@/lib/purchase-types";
import { CreditCard, Rocket, ShieldCheck, Zap } from "lucide-react";

function formatArabicNumber(value: number): string {
  return new Intl.NumberFormat("ar-EG", {
    maximumFractionDigits: 0,
  }).format(value);
}

function formatEgp(value: number): string {
  return `${new Intl.NumberFormat("ar-EG", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(value)} ج`;
}

function formatRelativeTime(isoDate: string): string {
  const deltaMs = Date.now() - new Date(isoDate).getTime();
  const minute = 60_000;
  const hour = 60 * minute;
  const day = 24 * hour;

  if (deltaMs < hour) {
    const minutes = Math.max(1, Math.floor(deltaMs / minute));
    return `منذ ${formatArabicNumber(minutes)} دقيقة`;
  }

  if (deltaMs < day) {
    const hours = Math.max(1, Math.floor(deltaMs / hour));
    return `منذ ${formatArabicNumber(hours)} ساعة`;
  }

  const days = Math.max(1, Math.floor(deltaMs / day));
  return `منذ ${formatArabicNumber(days)} يوم`;
}

export default async function DashboardPage() {
  const user = await getCurrentUser();

  if (!user) {
    redirect("/login");
  }

  if (user.role === "admin") {
    redirect("/admin");
  }

  const dashboardData = await getUserDashboardData(user.id);

  const approvalRate =
    dashboardData.totalPurchases > 0
      ? Math.round((dashboardData.approvedPurchasesCount / dashboardData.totalPurchases) * 100)
      : 0;

  const statCards = [
    {
      title: "إجمالي طلبات الشراء",
      value: formatArabicNumber(dashboardData.totalPurchases),
      icon: <Rocket className="text-brand-500 w-6 h-6" />,
    },
    {
      title: "طلبات قيد المراجعة",
      value: formatArabicNumber(dashboardData.pendingPurchasesCount),
      icon: <Zap className="text-amber-500 w-6 h-6" />,
    },
    {
      title: "الطلبات المقبولة",
      value: formatArabicNumber(dashboardData.approvedPurchasesCount),
      icon: <ShieldCheck className="text-indigo-500 w-6 h-6" />,
    },
    {
      title: "إجمالي مدفوعاتك",
      value: formatEgp(dashboardData.approvedRevenueEgp),
      icon: <CreditCard className="text-emerald-500 w-6 h-6" />,
    },
  ];

  return (
    <AppShell userRole={user.role} username={user.fullName}>
      <div className="flex justify-between items-end mb-8">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-linear-to-l from-slate-900 to-slate-600">
              مرحباً بك، {user.fullName}
            </h1>
            <span className="text-brand-500 animate-[wave_2.5s_ease-in-out_infinite] origin-[70%_70%] inline-block">
              <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 11V6a2 2 0 0 0-2-2v0a2 2 0 0 0-2 2v0"/><path d="M14 10V4a2 2 0 0 0-2-2v0a2 2 0 0 0-2 2v0"/><path d="M10 10.5V6a2 2 0 0 0-2-2v0a2 2 0 0 0-2 2v0"/><path d="M15 21 5.8 11.8a2 2 0 1 1 2.8-2.9l2.4 2.4"/></svg>
            </span>
          </div>
          <p className="text-slate-500">نظرة عامة على اشتراكاتك وخدماتك الفعالة.</p>
        </div>
        <button className="hidden md:inline-flex bg-brand-600 hover:bg-brand-700 text-white font-medium px-5 py-2.5 rounded-xl shadow-lg shadow-brand-500/30 transition-all items-center gap-2">
          ترقية الباقة
        </button>
      </div>

      {/* Stats Area */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
        {statCards.map((card, i) => (
          <div key={i} className="bg-white p-7 rounded-3xl border border-slate-200/60 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.02)] hover:shadow-[0_8px_30px_-4px_rgba(20,184,166,0.1)] hover:border-brand-100 transition-all duration-500 overflow-hidden relative group">
            <div className="absolute top-0 left-0 w-32 h-32 bg-linear-to-br from-brand-50 to-transparent rounded-full blur-3xl -ml-16 -mt-16 transition-transform group-hover:scale-150 duration-700 opacity-60"></div>
            
            <div className="relative z-10 flex flex-col gap-5">
              <div className="w-14 h-14 rounded-2xl bg-slate-50 border border-slate-100/80 flex items-center justify-center shadow-sm group-hover:scale-110 group-hover:bg-white transition-all duration-500">
                {card.icon}
              </div>
              <div>
                <p className="text-sm font-bold text-slate-500 mb-1.5">{card.title}</p>
                <h3 className="text-3xl font-extrabold text-slate-900 tracking-tight">{card.value}</h3>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Main Content Areas */}
      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white border border-slate-100 shadow-sm rounded-3xl p-8">
          <h2 className="text-lg font-bold text-slate-900 mb-6">نشاط الحساب</h2>
          <div className="space-y-6">
            {dashboardData.recentPurchases.map((purchase) => (
              <div key={purchase.id} className="flex gap-4 items-start pb-6 border-b border-slate-50 last:border-b-0 last:pb-0">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                    purchase.status === "approved"
                      ? "bg-emerald-50 text-emerald-600"
                      : purchase.status === "rejected"
                        ? "bg-rose-50 text-rose-600"
                        : "bg-amber-50 text-amber-600"
                  }`}
                >
                  <CreditCard size={20} />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-semibold text-slate-900">
                    {purchase.planName} - {PURCHASE_STATUS_LABELS[purchase.status]}
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    {purchase.programName ?? "بدون برنامج"} - {formatEgp(purchase.amountEgp)} - {formatRelativeTime(purchase.createdAt)}
                  </p>
                </div>
              </div>
            ))}

            {dashboardData.recentPurchases.length === 0 && (
              <div className="rounded-2xl border border-dashed border-slate-200 px-4 py-6 text-center text-sm font-semibold text-slate-500">
                لا يوجد نشاط مشتريات بعد.
              </div>
            )}
          </div>
        </div>

        <div className="bg-linear-to-br from-slate-900 to-slate-800 rounded-3xl p-8 text-white shadow-xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-32 bg-brand-500/20 rounded-full blur-3xl -mr-16 -mt-16 transition-transform group-hover:scale-110 duration-700"></div>
          
          <div className="relative z-10">
            <h2 className="text-xl font-bold text-white mb-2">
              {dashboardData.latestApprovedPurchase?.planName ?? "لا توجد باقة مقبولة بعد"}
            </h2>
            <p className="text-slate-400 text-sm mb-8">
              {dashboardData.latestApprovedPurchase
                ? `آخر باقة مقبولة ضمن برنامج ${dashboardData.latestApprovedPurchase.programName ?? "-"}`
                : "ابدأ باختيار باقة من صفحة البرامج ثم أرسل طلب شراء."}
            </p>
            
            <div className="mb-6">
              <div className="flex justify-between items-center text-sm mb-2">
                <span className="text-slate-300">نسبة الطلبات المقبولة</span>
                <span className="font-bold text-brand-400">{formatArabicNumber(approvalRate)}٪</span>
              </div>
              <div className="w-full bg-slate-700 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-brand-500 h-full rounded-full shadow-[0_0_10px_rgba(20,184,166,0.5)]"
                  style={{ width: `${Math.min(Math.max(approvalRate, 0), 100)}%` }}
                ></div>
              </div>
            </div>
            
            <Link
              href="/dashboard/purchases"
              className="w-full inline-flex items-center justify-center bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/10 transition-colors py-3 rounded-xl font-medium text-sm"
            >
              عرض مشترياتي
            </Link>
          </div>
        </div>
      </div>
    </AppShell>
  );
}

