import Link from "next/link";
import { redirect } from "next/navigation";
import { ArrowLeft, FolderKanban } from "lucide-react";

import AppShell from "@/components/app-shell";
import { getCurrentUser } from "@/lib/auth-session";
import { listProgramsWithPlanCounts } from "@/lib/catalog-db";
import { extractPlainTextFromHtml } from "@/lib/rich-text";

export default async function UserProgramsPage() {
  const user = await getCurrentUser();

  if (!user) {
    redirect("/login");
  }

  if (user.role === "admin") {
    redirect("/admin");
  }

  const programs = await listProgramsWithPlanCounts();

  return (
    <AppShell userRole={user.role} username={user.fullName}>
      <div className="flex flex-wrap items-end justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">البرامج المتاحة</h1>
          <p className="text-slate-500">اختر أي برنامج للانتقال إلى صفحة تفاصيله الكاملة وباقاته.</p>
        </div>
        <div className="inline-flex items-center gap-2 bg-brand-50 text-brand-700 px-4 py-2 rounded-xl border border-brand-100">
          <FolderKanban size={18} />
          <span className="font-bold text-sm">عدد البرامج: {programs.length}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {programs.map((program) => (
          <article
            key={program.id}
            className="bg-white rounded-3xl border border-slate-200/70 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.02)] p-5"
          >
            <h2 className="text-lg font-extrabold text-slate-900 mb-2">{program.name}</h2>
            <p className="text-sm text-slate-600 leading-7 mb-4 line-clamp-4">
              {extractPlainTextFromHtml(program.description)}
            </p>
            <div className="flex items-center justify-between gap-3">
              <span className="text-xs font-bold px-2.5 py-1 rounded-lg bg-brand-50 text-brand-700 border border-brand-100">
                {program.plansCount} باقة متاحة
              </span>
              <Link
                href={`/dashboard/programs/${program.id}`}
                className="inline-flex items-center gap-1 text-sm font-bold text-slate-900 hover:text-brand-700 transition-colors"
              >
                عرض التفاصيل
                <ArrowLeft size={16} />
              </Link>
            </div>
          </article>
        ))}

        {programs.length === 0 && (
          <div className="col-span-full text-center text-sm font-semibold text-slate-500 bg-white border border-dashed border-slate-200 rounded-2xl p-8">
            لا توجد برامج متاحة حاليًا.
          </div>
        )}
      </div>
    </AppShell>
  );
}
