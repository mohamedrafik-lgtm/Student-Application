import Link from "next/link";
import { redirect } from "next/navigation";
import { ArrowRight, CheckCircle2, Layers3 } from "lucide-react";

import AppShell from "@/components/app-shell";
import { getCurrentUser } from "@/lib/auth-session";
import { getProgramById, listPublicPlans } from "@/lib/catalog-db";
import { getPlanDurationLabel } from "@/lib/plan-duration";
import { sanitizeProgramDescription } from "@/lib/rich-text";

function formatEgp(value: number): string {
  return new Intl.NumberFormat("ar-EG", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(value);
}

export default async function UserProgramDetailsPage({
  params,
}: {
  params: Promise<{ programId: string }>;
}) {
  const user = await getCurrentUser();

  if (!user) {
    redirect("/login");
  }

  if (user.role === "admin") {
    redirect("/admin");
  }

  const routeParams = await params;
  const programId = Number(routeParams.programId);

  if (!Number.isInteger(programId) || programId <= 0) {
    redirect("/dashboard/programs");
  }

  const program = await getProgramById(programId);

  if (!program) {
    redirect("/dashboard/programs");
  }

  const plans = await listPublicPlans(program.id);

  return (
    <AppShell userRole={user.role} username={user.fullName}>
      <div className="mb-6">
        <Link
          href="/dashboard/programs"
          className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700 hover:bg-slate-50"
        >
          <ArrowRight size={16} />
          الرجوع إلى البرامج
        </Link>
      </div>

      <section className="bg-white rounded-3xl border border-slate-200/70 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.02)] p-6 mb-6">
        <h1 className="text-2xl md:text-3xl font-extrabold text-slate-900 mb-3">{program.name}</h1>
        <div
          className="rich-content text-sm md:text-base"
          dangerouslySetInnerHTML={{
            __html: sanitizeProgramDescription(program.description),
          }}
        />
      </section>

      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <h2 className="text-xl font-extrabold text-slate-900">باقات البرنامج</h2>
        <span className="inline-flex items-center gap-2 bg-brand-50 text-brand-700 px-3 py-1.5 rounded-xl border border-brand-100 text-sm font-bold">
          <Layers3 size={16} />
          {plans.length} باقة متاحة
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {plans.map((plan) => (
          <article
            key={plan.id}
            className="bg-white rounded-3xl border border-slate-200/70 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.02)] p-5"
          >
            <div className="flex items-start justify-between gap-3 mb-3">
              <div>
                <h3 className="text-lg font-extrabold text-slate-900">{plan.name}</h3>
                <p className="text-xs font-bold text-slate-500 mt-1">كود الباقة #{plan.id}</p>
              </div>
              <div className="flex flex-col items-end gap-1">
                <span className="text-sm font-extrabold text-emerald-700 bg-emerald-50 border border-emerald-100 px-2.5 py-1 rounded-xl">
                  {formatEgp(plan.priceEgp)} جنيه
                </span>
                <span className="text-xs font-bold text-indigo-700 bg-indigo-50 border border-indigo-100 px-2 py-1 rounded-lg">
                  {getPlanDurationLabel(plan.durationCode, plan.durationCustomLabel)}
                </span>
              </div>
            </div>
            <p className="text-sm text-slate-700 leading-7 whitespace-pre-wrap mb-4">{plan.description}</p>
            <Link
              href={`/dashboard/purchases/new?planId=${plan.id}`}
              className="inline-flex items-center gap-2 text-sm font-bold text-brand-700 bg-brand-50 border border-brand-100 px-3.5 py-2 rounded-xl hover:bg-brand-100"
            >
              <CheckCircle2 size={16} />
              اختيار هذه الباقة
            </Link>
          </article>
        ))}

        {plans.length === 0 && (
          <div className="col-span-full text-center text-sm font-semibold text-slate-500 bg-white border border-dashed border-slate-200 rounded-2xl p-8">
            لا توجد باقات متاحة لهذا البرنامج حاليًا.
          </div>
        )}
      </div>
    </AppShell>
  );
}
