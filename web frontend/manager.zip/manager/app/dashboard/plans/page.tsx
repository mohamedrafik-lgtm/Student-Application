import { redirect } from "next/navigation";

export default function UserPlansPage() {
  redirect("/dashboard/programs");
}
