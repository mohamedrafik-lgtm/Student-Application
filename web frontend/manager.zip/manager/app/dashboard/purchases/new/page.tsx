import Link from "next/link";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { ArrowRight, CheckCircle2, Wallet } from "lucide-react";

import AppShell from "@/components/app-shell";
import { getCurrentUser } from "@/lib/auth-session";
import {
  createPurchaseRequest,
  getPublicPlanForPurchaseById,
  listActiveVodafoneCashMethods,
} from "@/lib/purchase-db";
import { getPlanDurationLabel } from "@/lib/plan-duration";

function normalizeText(value: FormDataEntryValue | null): string {
  return typeof value === "string" ? value.trim() : "";
}

function formatEgp(value: number): string {
  return new Intl.NumberFormat("ar-EG", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(value);
}

async function createPurchaseAction(formData: FormData): Promise<void> {
  "use server";

  const user = await getCurrentUser();
  if (!user || user.role !== "user") {
    redirect("/login");
  }

  const planId = Number(formData.get("planId"));
  const paymentMethodId = Number(formData.get("paymentMethodId"));
  const transferFromPhone = normalizeText(formData.get("transferFromPhone"));

  if (
    !Number.isInteger(planId) ||
    planId <= 0 ||
    !Number.isInteger(paymentMethodId) ||
    paymentMethodId <= 0 ||
    transferFromPhone.length < 7
  ) {
    return;
  }

  const createdId = await createPurchaseRequest({
    userId: user.id,
    planId,
    paymentMethodId,
    transferFromPhone,
  });

  if (!createdId) {
    return;
  }

  revalidatePath("/dashboard/purchases");
  revalidatePath("/admin/purchases");
  redirect("/dashboard/purchases?created=1");
}

export default async function UserNewPurchasePage({
  searchParams,
}: {
  searchParams: Promise<{ planId?: string }>;
}) {
  const user = await getCurrentUser();

  if (!user) {
    redirect("/login");
  }

  if (user.role === "admin") {
    redirect("/admin");
  }

  const params = await searchParams;
  const planId = Number(params.planId);

  if (!Number.isInteger(planId) || planId <= 0) {
    redirect("/dashboard/programs");
  }

  const [plan, methods] = await Promise.all([
    getPublicPlanForPurchaseById(planId),
    listActiveVodafoneCashMethods(),
  ]);

  if (!plan) {
    redirect("/dashboard/programs");
  }

  const selectedMethod = methods.length > 0 ? methods[Math.floor(Math.random() * methods.length)] : null;

  return (
    <AppShell userRole={user.role} username={user.fullName}>
      <div className="mb-6">
        <Link
          href={`/dashboard/programs/${plan.programId}`}
          className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700 hover:bg-slate-50"
        >
          <ArrowRight size={16} />
          الرجوع إلى تفاصيل البرنامج
        </Link>
      </div>

      <div className="mb-6 rounded-3xl border border-slate-200/70 bg-white p-6 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.02)]">
        <h1 className="text-2xl font-extrabold text-slate-900 mb-2">طلب شراء الباقة</h1>
        <p className="text-slate-600">{plan.programName} - {plan.name}</p>
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <span className="rounded-lg border border-emerald-100 bg-emerald-50 px-2.5 py-1 text-xs font-bold text-emerald-700">
            المبلغ المطلوب: {formatEgp(plan.priceEgp)} جنيه
          </span>
          <span className="rounded-lg border border-indigo-100 bg-indigo-50 px-2.5 py-1 text-xs font-bold text-indigo-700">
            المدة: {getPlanDurationLabel(plan.durationCode, plan.durationCustomLabel)}
          </span>
        </div>
      </div>

      {selectedMethod ? (
        <div className="rounded-3xl border border-slate-200/70 bg-white p-6 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.02)]">
          <div className="mb-4 inline-flex items-center gap-2 rounded-xl border border-brand-100 bg-brand-50 px-4 py-2 text-brand-700">
            <Wallet size={16} />
            رقم فودافون كاش المتاح للتحويل: {selectedMethod.phoneNumber}
          </div>

          <form action={createPurchaseAction} className="space-y-3">
            <input type="hidden" name="planId" value={plan.id} />
            <input type="hidden" name="paymentMethodId" value={selectedMethod.id} />

            <div>
              <label className="mb-2 block text-sm font-extrabold text-slate-800">الرقم الذي تم التحويل منه</label>
              <input
                type="text"
                name="transferFromPhone"
                required
                placeholder="اكتب رقم فودافون كاش الذي حولت منه"
                className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-700"
              />
            </div>

            <button
              type="submit"
              className="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-bold text-white hover:bg-slate-800"
            >
              <CheckCircle2 size={16} />
              تم التحويل
            </button>
          </form>
        </div>
      ) : (
        <div className="rounded-2xl border border-dashed border-slate-200 bg-white p-8 text-center text-sm font-semibold text-slate-500">
          لا يوجد رقم فودافون كاش متاح حاليًا. تواصل مع الإدارة.
        </div>
      )}
    </AppShell>
  );
}
