import Link from "next/link";
import { redirect } from "next/navigation";
import { CheckCircle2, ShoppingCart } from "lucide-react";

import AppShell from "@/components/app-shell";
import { getCurrentUser } from "@/lib/auth-session";
import { listPurchasesForUser } from "@/lib/purchase-db";
import { PURCHASE_STATUS_LABELS } from "@/lib/purchase-types";

function formatEgp(value: number): string {
  return new Intl.NumberFormat("ar-EG", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(value);
}

export default async function UserPurchasesPage({
  searchParams,
}: {
  searchParams: Promise<{ created?: string }>;
}) {
  const user = await getCurrentUser();

  if (!user) {
    redirect("/login");
  }

  if (user.role === "admin") {
    redirect("/admin");
  }

  const params = await searchParams;
  const purchases = await listPurchasesForUser(user.id);

  return (
    <AppShell userRole={user.role} username={user.fullName}>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">مشترياتي</h1>
          <p className="text-slate-500">تابع حالة طلباتك ونتيجة مراجعة الإدارة.</p>
        </div>
        <div className="inline-flex items-center gap-2 rounded-xl border border-brand-100 bg-brand-50 px-4 py-2 text-brand-700">
          <ShoppingCart size={18} />
          <span className="text-sm font-bold">عدد الطلبات: {purchases.length}</span>
        </div>
      </div>

      {params.created === "1" && (
        <div className="mb-4 inline-flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-2 text-sm font-bold text-emerald-700">
          <CheckCircle2 size={16} />
          طلبك قيد التحضير والمراجعة.
        </div>
      )}

      <div className="grid grid-cols-1 gap-4">
        {purchases.map((purchase) => (
          <article
            key={purchase.id}
            className="rounded-3xl border border-slate-200/70 bg-white p-5 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.02)]"
          >
            <div className="mb-3 flex flex-wrap items-start justify-between gap-3">
              <div>
                <h2 className="text-base font-extrabold text-slate-900">{purchase.planName ?? "باقة"}</h2>
                <p className="mt-1 text-sm text-slate-600">البرنامج: {purchase.programName ?? "-"}</p>
                <p className="mt-1 text-sm text-slate-600">المبلغ: {formatEgp(purchase.amountEgp)} جنيه</p>
                <p className="mt-1 text-sm text-slate-600">التحويل إلى: {purchase.paymentPhoneTo}</p>
                <p className="mt-1 text-sm text-slate-600">التحويل من: {purchase.transferFromPhone}</p>
              </div>
              <span
                className={`rounded-lg border px-2.5 py-1 text-xs font-bold ${
                  purchase.status === "approved"
                    ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                    : purchase.status === "rejected"
                      ? "border-rose-200 bg-rose-50 text-rose-700"
                      : "border-amber-200 bg-amber-50 text-amber-700"
                }`}
              >
                {PURCHASE_STATUS_LABELS[purchase.status]}
              </span>
            </div>

            {purchase.adminNote && (
              <p className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm font-semibold text-slate-700">
                ملاحظة الإدارة: {purchase.adminNote}
              </p>
            )}

            <div className="mt-3">
              <Link
                href={`/dashboard/purchases/${purchase.id}`}
                className="inline-flex rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-bold text-slate-700 hover:bg-slate-50"
              >
                فتح التفاصيل والمحادثة
              </Link>
            </div>
          </article>
        ))}

        {purchases.length === 0 && (
          <div className="rounded-2xl border border-dashed border-slate-200 bg-white p-8 text-center text-sm font-semibold text-slate-500">
            لا توجد طلبات شراء بعد. يمكنك اختيار باقة من صفحة البرامج.
            <div className="mt-3">
              <Link
                href="/dashboard/programs"
                className="inline-flex rounded-xl border border-brand-200 bg-brand-50 px-3 py-2 text-sm font-bold text-brand-700 hover:bg-brand-100"
              >
                تصفح البرامج
              </Link>
            </div>
          </div>
        )}
      </div>
    </AppShell>
  );
}
