"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Mail, Lock, User, Phone, ArrowLeft, Hexagon, AlertCircle } from "lucide-react";
import { RegisterInput } from "@/lib/validation";

function extractFirstApiError(data: unknown): string {
  if (typeof data !== "object" || data === null) {
    return "حدث خطأ غير متوقع.";
  }

  const response = data as {
    message?: unknown;
    errors?: Record<string, string[] | undefined>;
  };

  if (response.errors && typeof response.errors === "object") {
    const first = Object.values(response.errors).find(
      (messages) => Array.isArray(messages) && messages.length > 0,
    );
    if (first && first[0]) {
      return first[0];
    }
  }

  if (typeof response.message === "string" && response.message.trim()) {
    return response.message;
  }

  return "تعذر اتمام العملية. حاول مرة أخرى.";
}

export default function RegisterPage() {
  const [formData, setFormData] = useState<RegisterInput>({
    fullName: "",
    email: "",
    phone: "",
    password: "",
  });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(extractFirstApiError(data));
      }

      const destination = data?.user?.role === "admin" ? "/admin" : "/dashboard";
      router.replace(destination);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <div className="flex min-h-screen bg-slate-50 text-slate-900">

      {/* Right Side - Showcase Cover */}
      <div className="hidden lg:flex flex-1 relative bg-slate-900 overflow-hidden text-center items-center justify-center p-12 direction-ltr rtl:order-2">
        <div className="absolute inset-0" style={{ backgroundImage: "radial-gradient(ellipse at bottom, rgba(15, 23, 42, 0.4) 0%, #020617 100%)" }} />
        <div className="absolute top-[-20%] left-[-10%] w-[600px] h-[600px] bg-brand-500/20 rounded-full blur-[140px] mix-blend-screen pointer-events-none" />
        <div className="absolute bottom-[-20%] right-[-10%] w-[600px] h-[600px] bg-indigo-500/20 rounded-full blur-[140px] mix-blend-screen pointer-events-none" />
        
        {/* Content Showcase */}
        <div className="relative z-10 max-w-xl text-center right-0 flex flex-col items-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 backdrop-blur-xl border border-white/10 text-white text-xs font-bold tracking-wider mb-8 uppercase">
            <span className="flex h-2 w-2 rounded-full bg-indigo-400 shadow-[0_0_8px_rgba(99,102,241,0.8)]"></span>
            انضم إلى شبكة طيبة
          </div>
          <h2 className="text-4xl lg:text-5xl font-extrabold tracking-tight text-white mb-6 leading-[1.3] drop-shadow-sm">
            نظام متكامل لتوسيع نطاق <br/> خدمات شركتك
          </h2>
          <p className="text-slate-400 text-lg leading-relaxed max-w-lg mb-12">
            تمتع ببوابة حصرية وعصرية للتحكم في خدماتك الرقمية واستشارات المبيعات والدعم الفني السحابي.
          </p>
        </div>
      </div>

      {/* Left Side - Form */}
      <div className="w-full lg:w-[480px] xl:w-[540px] flex flex-col px-8 xl:px-12 py-10 bg-white relative z-10 shadow-[-20px_0_40px_-20px_rgba(0,0,0,0.05)] rtl:order-1">
        
        <div className="flex-1 flex flex-col justify-center max-w-sm w-full mx-auto animate-in pt-8 pb-4">
          <Hexagon className="w-10 h-10 fill-brand-100 stroke-brand-600 stroke-[1.5] mb-6" />
          
          <h1 className="text-2xl font-bold text-slate-900 mb-2">إنشاء حساب جديد</h1>
          <p className="text-slate-500 mb-8 text-sm leading-relaxed">قم بتسجيل تفاصيل حسابك للوصول لمنصة الإدارة ومزايا النظام.</p>

          {error && (
            <div className="mb-6 p-4 rounded-xl bg-red-50 text-red-600 border border-red-100 text-sm font-medium flex items-start gap-3">
              <AlertCircle size={20} className="flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleRegister} className="space-y-5">
            <div className="space-y-2">
              <label className="text-sm font-extrabold text-slate-800 block">الاسم بالكامل</label>
              <div className="relative group mt-2">
                <User className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-brand-600 transition-all w-5 h-5 pointer-events-none group-focus-within:scale-110" />
                <input
                  name="fullName"
                  required
                  value={formData.fullName}
                  onChange={handleChange}
                  className="w-full bg-slate-50/50 border border-slate-200/80 text-slate-900 rounded-2xl px-12 py-3.5 focus:outline-none focus:ring-4 focus:ring-brand-500/10 focus:border-brand-500 transition-all hover:bg-slate-50 shadow-[0_2px_8px_-2px_rgba(0,0,0,0.02)]"
                  placeholder="محمد أحمد"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-extrabold text-slate-800 block">البريد الإلكتروني</label>
              <div className="relative group mt-2">
                <Mail className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-brand-600 transition-all w-5 h-5 pointer-events-none group-focus-within:scale-110" />
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full bg-slate-50/50 border border-slate-200/80 text-slate-900 rounded-2xl px-12 py-3.5 focus:outline-none focus:ring-4 focus:ring-brand-500/10 focus:border-brand-500 transition-all hover:bg-slate-50 text-left font-sans shadow-[0_2px_8px_-2px_rgba(0,0,0,0.02)]"
                  placeholder="name@domain.com"
                  dir="ltr"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-extrabold text-slate-800 block">رقم الهاتف</label>
              <div className="relative group mt-2">
                <Phone className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-brand-600 transition-all w-5 h-5 pointer-events-none group-focus-within:scale-110" />
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full bg-slate-50/50 border border-slate-200/80 text-slate-900 rounded-2xl px-12 py-3.5 focus:outline-none focus:ring-4 focus:ring-brand-500/10 focus:border-brand-500 transition-all hover:bg-slate-50 text-left font-sans tracking-wide shadow-[0_2px_8px_-2px_rgba(0,0,0,0.02)]"
                  placeholder="01012345678"
                  dir="ltr"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-extrabold text-slate-800 block">كلمة المرور</label>
              <div className="relative group mt-2">
                <Lock className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-brand-600 transition-all w-5 h-5 pointer-events-none group-focus-within:scale-110" />
                <input
                  type="password"
                  name="password"
                  required
                  value={formData.password}
                  onChange={handleChange}
                  className="w-full bg-slate-50/50 border border-slate-200/80 text-slate-900 rounded-2xl px-12 py-3.5 focus:outline-none focus:ring-4 focus:ring-brand-500/10 focus:border-brand-500 transition-all hover:bg-slate-50 text-left font-sans tracking-widest shadow-[0_2px_8px_-2px_rgba(0,0,0,0.02)]"
                  placeholder="&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;"
                  dir="ltr"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-2xl py-4 transition-all duration-300 shadow-[0_8px_30px_-4px_rgba(15,23,42,0.2)] hover:shadow-[0_12px_40px_-4px_rgba(15,23,42,0.3)] flex items-center justify-center gap-3 group mt-10 disabled:opacity-70 disabled:cursor-not-allowed hover:-translate-y-0.5"
            >
              {loading ? "جاري التسجيل..." : "تأكيد وإنشاء حساب"}
              {!loading && <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1.5 transition-transform" />}
            </button>
          </form>

          <p className="mt-8 text-center text-sm text-slate-500 font-medium">
            لديك حساب بالفعل؟{" "}
            <Link href="/login" className="font-bold text-brand-600 hover:text-brand-700 transition-colors ml-1">
              تسجيل الدخول
            </Link>
          </p>
        </div>
      </div>

    </div>
  );
}
