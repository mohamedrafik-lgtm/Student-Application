import { randomUUID } from "node:crypto";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";

import { NextResponse } from "next/server";

import { getCurrentUser } from "@/lib/auth-session";

const MAX_IMAGE_SIZE_BYTES = 5 * 1024 * 1024;
const ALLOWED_MIME_TYPES = new Set([
  "image/png",
  "image/jpeg",
  "image/webp",
  "image/gif",
]);

function extensionFromMimeType(mimeType: string): string {
  switch (mimeType) {
    case "image/png":
      return ".png";
    case "image/jpeg":
      return ".jpg";
    case "image/webp":
      return ".webp";
    case "image/gif":
      return ".gif";
    default:
      return ".bin";
  }
}

export const runtime = "nodejs";

export async function POST(request: Request) {
  const user = await getCurrentUser();

  if (!user || user.role !== "admin") {
    return NextResponse.json({ message: "غير مصرح برفع الصور." }, { status: 403 });
  }

  let formData: FormData;

  try {
    formData = await request.formData();
  } catch {
    return NextResponse.json({ message: "بيانات الطلب غير صالحة." }, { status: 400 });
  }

  const file = formData.get("file");
  if (!(file instanceof File)) {
    return NextResponse.json({ message: "الملف غير موجود." }, { status: 400 });
  }

  if (!ALLOWED_MIME_TYPES.has(file.type)) {
    return NextResponse.json({ message: "نوع الصورة غير مدعوم." }, { status: 400 });
  }

  if (file.size <= 0 || file.size > MAX_IMAGE_SIZE_BYTES) {
    return NextResponse.json({ message: "حجم الصورة يجب أن يكون أقل من 5MB." }, { status: 400 });
  }

  try {
    const buffer = Buffer.from(await file.arrayBuffer());
    const extension = extensionFromMimeType(file.type);
    const fileName = `${Date.now()}-${randomUUID()}${extension}`;

    const uploadDirectory = path.join(process.cwd(), "public", "uploads", "programs");
    await mkdir(uploadDirectory, { recursive: true });

    const outputPath = path.join(uploadDirectory, fileName);
    await writeFile(outputPath, buffer);

    return NextResponse.json(
      {
        url: `/uploads/programs/${fileName}`,
      },
      { status: 201 },
    );
  } catch {
    return NextResponse.json({ message: "تعذر رفع الصورة حاليًا." }, { status: 500 });
  }
}
