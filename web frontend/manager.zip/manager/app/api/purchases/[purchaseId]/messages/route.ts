import { NextResponse } from "next/server";

import { getCurrentUser } from "@/lib/auth-session";
import {
  createPurchaseMessage,
  getPurchaseByIdForAdmin,
  getPurchaseByIdForUser,
  listPurchaseMessages,
} from "@/lib/purchase-db";
import { broadcastPurchaseChatMessage } from "@/lib/purchase-chat-bus";

function normalizeText(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

async function canAccessPurchase(purchaseId: number): Promise<boolean> {
  const user = await getCurrentUser();

  if (!user) {
    return false;
  }

  if (user.role === "admin") {
    const purchase = await getPurchaseByIdForAdmin(purchaseId);
    return Boolean(purchase);
  }

  const purchase = await getPurchaseByIdForUser(user.id, purchaseId);
  return Boolean(purchase);
}

export async function GET(
  _request: Request,
  context: { params: Promise<{ purchaseId: string }> },
) {
  const user = await getCurrentUser();

  if (!user) {
    return NextResponse.json({ message: "غير مصرح." }, { status: 401 });
  }

  const params = await context.params;
  const purchaseId = Number(params.purchaseId);

  if (!Number.isInteger(purchaseId) || purchaseId <= 0) {
    return NextResponse.json({ message: "رقم الطلب غير صالح." }, { status: 400 });
  }

  const allowed = await canAccessPurchase(purchaseId);
  if (!allowed) {
    return NextResponse.json({ message: "لا يمكنك الوصول لهذا الطلب." }, { status: 403 });
  }

  const messages = await listPurchaseMessages(purchaseId);
  return NextResponse.json({ messages });
}

export async function POST(
  request: Request,
  context: { params: Promise<{ purchaseId: string }> },
) {
  const user = await getCurrentUser();

  if (!user) {
    return NextResponse.json({ message: "غير مصرح." }, { status: 401 });
  }

  const params = await context.params;
  const purchaseId = Number(params.purchaseId);

  if (!Number.isInteger(purchaseId) || purchaseId <= 0) {
    return NextResponse.json({ message: "رقم الطلب غير صالح." }, { status: 400 });
  }

  const allowed = await canAccessPurchase(purchaseId);
  if (!allowed) {
    return NextResponse.json({ message: "لا يمكنك الوصول لهذا الطلب." }, { status: 403 });
  }

  let body: unknown;

  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ message: "بيانات غير صالحة." }, { status: 400 });
  }

  const messageText = normalizeText((body as { message?: unknown })?.message);

  if (!messageText || messageText.length > 2000) {
    return NextResponse.json(
      { message: "نص الرسالة مطلوب وبحد أقصى 2000 حرف." },
      { status: 400 },
    );
  }

  const message = await createPurchaseMessage({
    purchaseId,
    senderUserId: user.id,
    senderRole: user.role,
    messageText,
  });

  if (!message) {
    return NextResponse.json({ message: "تعذر إرسال الرسالة." }, { status: 500 });
  }

  broadcastPurchaseChatMessage(purchaseId, message);

  return NextResponse.json({ message }, { status: 201 });
}
