import { NextResponse } from "next/server";

import { getCurrentUser } from "@/lib/auth-session";
import {
  getPurchaseByIdForAdmin,
  getPurchaseByIdForUser,
} from "@/lib/purchase-db";
import {
  subscribeToPurchaseChat,
  toSseEvent,
} from "@/lib/purchase-chat-bus";

export const runtime = "nodejs";

async function canAccessPurchase(purchaseId: number): Promise<boolean> {
  const user = await getCurrentUser();

  if (!user) {
    return false;
  }

  if (user.role === "admin") {
    const purchase = await getPurchaseByIdForAdmin(purchaseId);
    return Boolean(purchase);
  }

  const purchase = await getPurchaseByIdForUser(user.id, purchaseId);
  return Boolean(purchase);
}

export async function GET(
  request: Request,
  context: { params: Promise<{ purchaseId: string }> },
) {
  const user = await getCurrentUser();

  if (!user) {
    return NextResponse.json({ message: "غير مصرح." }, { status: 401 });
  }

  const params = await context.params;
  const purchaseId = Number(params.purchaseId);

  if (!Number.isInteger(purchaseId) || purchaseId <= 0) {
    return NextResponse.json({ message: "رقم الطلب غير صالح." }, { status: 400 });
  }

  const allowed = await canAccessPurchase(purchaseId);
  if (!allowed) {
    return NextResponse.json({ message: "لا يمكنك الوصول لهذا الطلب." }, { status: 403 });
  }

  const encoder = new TextEncoder();

  const stream = new ReadableStream({
    start(controller) {
      controller.enqueue(encoder.encode(": connected\n\n"));

      const unsubscribe = subscribeToPurchaseChat(purchaseId, (payload) => {
        controller.enqueue(encoder.encode(toSseEvent("purchase-message", payload)));
      });

      const heartbeatId = setInterval(() => {
        controller.enqueue(encoder.encode(": ping\n\n"));
      }, 15_000);

      const abortHandler = () => {
        clearInterval(heartbeatId);
        unsubscribe();
        controller.close();
      };

      request.signal.addEventListener("abort", abortHandler);
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
