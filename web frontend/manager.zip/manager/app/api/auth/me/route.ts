import { NextResponse } from "next/server";

import { getCurrentUser } from "@/lib/auth-session";

export async function GET() {
  const user = await getCurrentUser();

  if (!user) {
    return NextResponse.json({ message: "غير مصرح." }, { status: 401 });
  }

  return NextResponse.json({ user });
}
