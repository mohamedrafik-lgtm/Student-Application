import { NextResponse } from "next/server";

import { beginUserSession } from "@/lib/auth-session";
import { createUser, getUserByEmail, getUserByPhone } from "@/lib/auth-db";
import { hashPassword } from "@/lib/password";
import { registerInputSchema } from "@/lib/validation";

function isDuplicateEntryError(error: unknown): boolean {
  return (
    typeof error === "object" &&
    error !== null &&
    "code" in error &&
    (error as { code?: string }).code === "ER_DUP_ENTRY"
  );
}

export async function POST(request: Request) {
  let body: unknown;

  try {
    body = await request.json();
  } catch {
    return NextResponse.json(
      { message: "هيئة الطلب غير صالحة." },
      { status: 400 },
    );
  }

  const parsed = registerInputSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      {
        message: "فشل التحقق من البيانات.",
        errors: parsed.error.flatten().fieldErrors,
      },
      { status: 400 },
    );
  }

  const { fullName, email, phone, password } = parsed.data;

  const [existingByEmail, existingByPhone] = await Promise.all([
    email ? getUserByEmail(email) : Promise.resolve(null),
    phone ? getUserByPhone(phone) : Promise.resolve(null),
  ]);

  if (existingByEmail || existingByPhone) {
    return NextResponse.json(
      { message: "البريد الإلكتروني أو رقم الهاتف مستخدم بالفعل." },
      { status: 409 },
    );
  }

  try {
    const passwordHash = await hashPassword(password);

    const user = await createUser({
      fullName,
      email,
      phone,
      passwordHash,
    });

    await beginUserSession(user.id, user.role);

    return NextResponse.json(
      {
        user: {
          id: user.id,
          fullName: user.fullName,
          email: user.email,
          phone: user.phone,
          role: user.role,
          createdAt: user.createdAt,
        },
      },
      { status: 201 },
    );
  } catch (error) {
    if (isDuplicateEntryError(error)) {
      return NextResponse.json(
        { message: "البريد الإلكتروني أو رقم الهاتف مستخدم بالفعل." },
        { status: 409 },
      );
    }

    return NextResponse.json(
      { message: "تعذر إنشاء الحساب." },
      { status: 500 },
    );
  }
}
