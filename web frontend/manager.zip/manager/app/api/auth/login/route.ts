import { NextResponse } from "next/server";

import { beginUserSession } from "@/lib/auth-session";
import { getUserForLogin } from "@/lib/auth-db";
import { verifyPassword } from "@/lib/password";
import { loginInputSchema } from "@/lib/validation";

const INVALID_CREDENTIALS_MESSAGE = "بيانات الدخول غير صحيحة.";

export async function POST(request: Request) {
  let body: unknown;

  try {
    body = await request.json();
  } catch {
    return NextResponse.json(
      { message: "هيئة الطلب غير صالحة." },
      { status: 400 },
    );
  }

  const parsed = loginInputSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      {
        message: "فشل التحقق من البيانات.",
        errors: parsed.error.flatten().fieldErrors,
      },
      { status: 400 },
    );
  }

  const user = await getUserForLogin(
    parsed.data.identifierType,
    parsed.data.identifier,
  );

  if (!user) {
    return NextResponse.json(
      { message: INVALID_CREDENTIALS_MESSAGE },
      { status: 401 },
    );
  }

  const validPassword = await verifyPassword(parsed.data.password, user.passwordHash);
  if (!validPassword) {
    return NextResponse.json(
      { message: INVALID_CREDENTIALS_MESSAGE },
      { status: 401 },
    );
  }

  await beginUserSession(user.id, user.role);

  const publicUser = {
    id: user.id,
    fullName: user.fullName,
    email: user.email,
    phone: user.phone,
    role: user.role,
    createdAt: user.createdAt,
  };

  return NextResponse.json({ user: publicUser });
}
