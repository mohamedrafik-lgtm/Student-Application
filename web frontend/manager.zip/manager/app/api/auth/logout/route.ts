import { NextResponse } from "next/server";

import { endCurrentSession } from "@/lib/auth-session";

export async function POST() {
  await endCurrentSession();
  return NextResponse.json({ message: "تم تسجيل الخروج بنجاح." });
}
