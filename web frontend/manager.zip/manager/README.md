# TIBA Software Product Management

Secure Next.js 16 authentication starter with:

- Register and login using email or phone number
- Role-based access (`admin` / `user`)
- TypeORM migration and seeding workflow
- Password hashing with bcrypt
- Signed HTTP-only session cookie
- Route protection via `proxy.ts`
- MySQL persistence for users and sessions
- Responsive UI for login, signup, and dashboard

## 1) Install dependencies

```bash
npm install
```

## 2) Configure environment variables

Update `.env` based on `.env.example`:

```env
APP_NAME="TIBA Software Product Management"

DB_HOST="localhost"
DB_PORT="3306"
DB_USER="root"
DB_PASSWORD="your_mysql_password"
DB_NAME="tiba_manager"

AUTH_JWT_SECRET="replace_with_a_long_random_secret_at_least_64_chars"

ADMIN_FULL_NAME="TIBA Super Admin"
ADMIN_EMAIL="admin@tibasoftware.com"
ADMIN_PHONE="+201000000000"
ADMIN_PASSWORD="replace_with_strong_admin_password"
```

## 3) Prepare database (safe)

Use migration flow (recommended):

```bash
npm run db:prepare
```

This will:

- Create database if it does not exist
- Run pending TypeORM migrations only
- Run safe seeders (idempotent, no destructive reset)

## 4) Run the app

Development mode (includes DB prepare automatically):

```bash
npm run dev
```

Production mode (runs migrations and seeders before start):

```bash
npm run start
```

Open `http://localhost:3000`.

## 5) Database scripts

```bash
npm run db:create
npm run db:migrate
npm run db:seed
npm run db:prepare
```

## 6) Seed admin account manually

```bash
npm run seed
```

This creates or updates the admin account using values from `.env`.

## Security notes

- Passwords are never stored in plain text.
- Session cookie is `httpOnly`, `sameSite=strict`, and signed server-side.
- Session records are validated against MySQL (not JWT alone).
- One active session per user is enforced.
- Admin pages are accessible only for `admin` role.
- `synchronize` is disabled in TypeORM, so schema changes are applied by explicit migrations only.
- Input validation is applied on all auth endpoints.

## Available routes

- `/` Landing page
- `/login` Sign in page (email or phone)
- `/register` Signup page (email and/or phone)
- `/dashboard` Protected user dashboard
- `/admin` Protected admin dashboard
- `/api/auth/register`
- `/api/auth/login`
- `/api/auth/logout`
- `/api/auth/me`
