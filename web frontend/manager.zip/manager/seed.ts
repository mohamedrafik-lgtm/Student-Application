import { runSeeders } from "./database/typeorm/scripts/run-seeds";

runSeeders().catch((error) => {
  console.error("Failed to run seed:", error);
  process.exitCode = 1;
});
