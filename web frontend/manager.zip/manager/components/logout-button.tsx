"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export default function LogoutButton() {
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(false);

  const onLogout = async () => {
    setIsLoading(true);

    try {
      await fetch("/api/auth/logout", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      });
    } finally {
      setIsLoading(false);
      router.replace("/login");
      router.refresh();
    }
  };

  return (
    <button
      type="button"
      className="tiba-button tiba-button-secondary"
      onClick={onLogout}
      disabled={isLoading}
    >
      {isLoading ? "جار تسجيل الخروج..." : "تسجيل الخروج"}
    </button>
  );
}
