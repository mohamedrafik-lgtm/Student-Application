"use client";

import { useEffect, useMemo, useState } from "react";
import { MessageCircle, Send } from "lucide-react";

import type { PurchaseMessage } from "@/lib/purchase-db";

type PurchaseLiveChatProps = {
  purchaseId: number;
  currentUserId: number;
  currentUserRole: "admin" | "user";
  initialMessages: PurchaseMessage[];
};

function formatDateTime(value: string): string {
  const date = new Date(value);

  return new Intl.DateTimeFormat("ar-EG", {
    dateStyle: "short",
    timeStyle: "short",
  }).format(date);
}

export default function PurchaseLiveChat({
  purchaseId,
  currentUserId,
  currentUserRole,
  initialMessages,
}: PurchaseLiveChatProps) {
  const [messages, setMessages] = useState<PurchaseMessage[]>(initialMessages);
  const [text, setText] = useState("");
  const [isSending, setIsSending] = useState(false);

  useEffect(() => {
    const eventSource = new EventSource(`/api/purchases/${purchaseId}/stream`);

    const onPurchaseMessage = (event: MessageEvent<string>) => {
      try {
        const message = JSON.parse(event.data) as PurchaseMessage;

        setMessages((prev) => {
          if (prev.some((item) => item.id === message.id)) {
            return prev;
          }

          return [...prev, message];
        });
      } catch {
        // Ignore invalid payloads.
      }
    };

    eventSource.addEventListener("purchase-message", onPurchaseMessage as EventListener);

    return () => {
      eventSource.removeEventListener("purchase-message", onPurchaseMessage as EventListener);
      eventSource.close();
    };
  }, [purchaseId]);

  const sortedMessages = useMemo(
    () => [...messages].sort((a, b) => a.id - b.id),
    [messages],
  );

  const sendMessage = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    const normalizedText = text.trim();
    if (!normalizedText || isSending) {
      return;
    }

    setIsSending(true);

    try {
      const response = await fetch(`/api/purchases/${purchaseId}/messages`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ message: normalizedText }),
      });

      const payload = (await response.json()) as {
        message?: PurchaseMessage | string;
        error?: string;
      };

      if (!response.ok) {
        const apiMessage =
          typeof payload.message === "string"
            ? payload.message
            : typeof payload.error === "string"
              ? payload.error
              : "تعذر إرسال الرسالة.";

        throw new Error(apiMessage);
      }

      if (payload.message && typeof payload.message !== "string") {
        const newMessage = payload.message as PurchaseMessage;
        setMessages((prev) => {
          if (prev.some((item) => item.id === newMessage.id)) {
            return prev;
          }

          return [...prev, newMessage];
        });
      }

      setText("");
    } catch (error) {
      window.alert(error instanceof Error ? error.message : "تعذر إرسال الرسالة.");
    } finally {
      setIsSending(false);
    }
  };

  return (
    <section className="rounded-3xl border border-slate-200/70 bg-white p-5 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.02)]">
      <div className="mb-4 flex items-center gap-2">
        <MessageCircle size={18} className="text-brand-600" />
        <h2 className="text-lg font-extrabold text-slate-900">محادثة مباشرة حول الطلب</h2>
      </div>

      <div className="mb-4 max-h-80 overflow-y-auto rounded-2xl border border-slate-200 bg-slate-50 p-3">
        <div className="space-y-2">
          {sortedMessages.map((message) => {
            const isMine = message.senderUserId === currentUserId;
            const senderLabel =
              message.senderRole === "admin"
                ? "الإدارة"
                : message.senderFullName ?? (currentUserRole === "user" ? "أنت" : "المستخدم");

            return (
              <article
                key={message.id}
                className={`max-w-[85%] rounded-2xl px-3 py-2 text-sm ${
                  isMine
                    ? "mr-auto bg-brand-600 text-white"
                    : "ml-auto bg-white text-slate-700 border border-slate-200"
                }`}
              >
                <p className={`mb-1 text-[11px] font-bold ${isMine ? "text-brand-100" : "text-slate-400"}`}>
                  {senderLabel}
                </p>
                <p className="whitespace-pre-wrap leading-6">{message.messageText}</p>
                <p className={`mt-1 text-[10px] ${isMine ? "text-brand-100" : "text-slate-400"}`}>
                  {formatDateTime(message.createdAt)}
                </p>
              </article>
            );
          })}

          {sortedMessages.length === 0 && (
            <p className="rounded-xl border border-dashed border-slate-200 bg-white px-3 py-4 text-center text-xs font-semibold text-slate-500">
              لا توجد رسائل بعد. اكتب أول رسالة الآن.
            </p>
          )}
        </div>
      </div>

      <form onSubmit={sendMessage} className="flex flex-col gap-2 sm:flex-row sm:items-center">
        <input
          type="text"
          value={text}
          onChange={(event) => setText(event.target.value)}
          placeholder="اكتب رسالتك..."
          className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-700"
        />
        <button
          type="submit"
          disabled={isSending}
          className="inline-flex items-center justify-center gap-2 rounded-xl bg-slate-900 px-4 py-3 text-sm font-bold text-white hover:bg-slate-800 disabled:opacity-60"
        >
          <Send size={16} />
          {isSending ? "جارٍ الإرسال..." : "إرسال"}
        </button>
      </form>
    </section>
  );
}
