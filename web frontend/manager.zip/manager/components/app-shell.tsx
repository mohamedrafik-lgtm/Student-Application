"use client";

import React, { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { 
  Menu, X, LayoutDashboard, Users, LogOut, 
  ChevronRight, Bell, Search, Hexagon, FolderKanban, Layers3, Wallet, ShoppingCart
} from "lucide-react";

type Role = "admin" | "user";

type AppShellProps = {
  children: React.ReactNode;
  userRole: Role;
  username: string;
};

export default function AppShell({ children, userRole, username }: AppShellProps) {
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const pathname = usePathname();

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
      window.location.href = '/login';
    } catch (error) {
      console.error(error);
    }
  };

  const navLinks =
    userRole === "admin"
      ? [
          { name: "لوحة التحكم", href: "/admin", icon: <LayoutDashboard size={20} /> },
          { name: "إدارة البرامج", href: "/admin/programs", icon: <FolderKanban size={20} /> },
          { name: "إدارة الباقات", href: "/admin/plans", icon: <Layers3 size={20} /> },
          { name: "طرق الدفع", href: "/admin/payment-methods", icon: <Wallet size={20} /> },
          { name: "مراجعة المشتريات", href: "/admin/purchases", icon: <ShoppingCart size={20} /> },
          { name: "إدارة المستخدمين", href: "/admin/users", icon: <Users size={20} /> },
        ]
      : [
          { name: "لوحة التحكم", href: "/dashboard", icon: <LayoutDashboard size={20} /> },
          { name: "البرامج", href: "/dashboard/programs", icon: <FolderKanban size={20} /> },
          { name: "مشترياتي", href: "/dashboard/purchases", icon: <ShoppingCart size={20} /> },
        ];

  const activeHref =
    navLinks
      .filter(
        (link) => pathname === link.href || pathname.startsWith(`${link.href}/`),
      )
      .sort((left, right) => right.href.length - left.href.length)[0]?.href ?? null;

  return (
    <div className="flex h-screen w-full bg-slate-50 overflow-hidden text-slate-900">
      
      {/* Mobile Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/40 z-40 lg:hidden backdrop-blur-sm transition-opacity"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside 
        className={`fixed lg:static top-0 right-0 z-50 h-full w-72 bg-white border-l border-slate-200 transform transition-transform duration-300 ease-[cubic-bezier(0.19,1,0.22,1)] ${
          isSidebarOpen ? "translate-x-0" : "translate-x-full lg:translate-x-0"
        } flex flex-col shadow-[0_0_40px_-10px_rgba(0,0,0,0.05)] lg:shadow-none`}
      >
        <div className="flex items-center justify-between p-6 h-20 border-b border-slate-100">
          <div className="flex items-center gap-3 text-brand-600">
            <Hexagon className="w-8 h-8 fill-brand-100 stroke-brand-600 stroke-[1.5]" />
            <span className="font-bold text-xl tracking-tight text-slate-900">طيبة سوفتوير</span>
          </div>
          <button onClick={() => setSidebarOpen(false)} className="lg:hidden text-slate-400 hover:text-slate-600 transition-colors">
            <X size={24} />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto py-6 px-4 space-y-1.5">
          <p className="px-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-5">
            القائمة الرئيسية
          </p>
          {navLinks.map((link) => {
            const isActive = activeHref === link.href;
            return (
              <Link 
                key={link.name} 
                href={link.href}
                className={`
                  flex items-center justify-between px-4 py-3.5 rounded-2xl transition-all duration-300 group relative overflow-hidden
                  ${isActive 
                    ? "bg-brand-50 text-brand-700 shadow-sm border border-brand-100/50" 
                    : "text-slate-600 hover:bg-slate-50 hover:text-slate-900 border border-transparent"}
                `}
              >
                {isActive && <div className="absolute right-0 top-1/2 -translate-y-1/2 w-1 h-8 bg-brand-500 rounded-l-full"></div>}
                <div className="flex items-center gap-3.5 font-bold text-sm">
                  <span className={`${isActive ? "text-brand-600" : "text-slate-400 group-hover:text-brand-500 group-hover:scale-110"} transition-all duration-300`}>
                    {link.icon}
                  </span>
                  {link.name}
                </div>
                {isActive && <ChevronRight size={16} className="text-brand-500 opacity-60" />}
              </Link>
            )
          })}
        </nav>

        <div className="p-5 border-t border-slate-200/60 bg-slate-50/50">
          <div className="flex items-center gap-3.5 p-3 mb-3 rounded-2xl bg-white border border-slate-200/60 shadow-[0_4px_12px_-4px_rgba(0,0,0,0.02)] transition-all hover:shadow-md hover:border-brand-100">
            <div className="h-11 w-11 flex items-center justify-center bg-linear-to-tr from-brand-600 to-brand-400 text-white rounded-xl font-black text-lg shadow-[inset_0_-2px_4px_rgba(0,0,0,0.1)]">
              {username.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-extrabold text-slate-900 truncate tracking-tight">{username}</p>
              <p className="text-xs font-semibold text-brand-600/80 truncate bg-brand-50 inline-block px-2 py-0.5 rounded-md mt-0.5">{userRole === "admin" ? "مدير نظام" : "مستخدم"}</p>
            </div>
          </div>
          <button 
            onClick={handleLogout}
            className="w-full flex items-center justify-center gap-2.5 py-3 px-4 text-sm font-bold text-slate-600 border border-slate-200 hover:border-red-200 bg-white hover:bg-red-50 hover:text-red-600 rounded-2xl transition-all duration-300 focus:ring-2 focus:ring-red-500/20 outline-none group"
          >
            <LogOut size={18} className="group-hover:scale-110 transition-transform" />
            تسجيل الخروج
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-full min-w-0 bg-slate-50/50">
        
        {/* Topbar */}
        <header className="h-24 bg-slate-50/70 backdrop-blur-xl border-b border-slate-200/50 flex items-center justify-between px-6 lg:px-10 sticky top-0 z-30 transition-all">
          <div className="flex items-center gap-5">
            <button 
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-2.5 -ml-2 text-slate-500 hover:text-slate-900 bg-white hover:bg-slate-100 rounded-xl transition-all border border-slate-200/60 shadow-sm"
            >
              <Menu size={22} />
            </button>
            <div className="hidden md:flex relative group">
              <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-slate-400 group-focus-within:text-brand-600 transition-colors" />
              <input 
                type="text" 
                placeholder="ابحث عن مشترك، فاتورة، خدمة..." 
                className="w-80 bg-white border border-slate-200/60 rounded-2xl py-3.5 pr-12 pl-5 text-sm font-semibold focus:ring-4 focus:ring-brand-500/10 focus:border-brand-500 transition-all outline-none text-slate-800 placeholder:text-slate-400 shadow-[0_2px_8px_-2px_rgba(0,0,0,0.02)]"
              />
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <button className="relative w-12 h-12 flex items-center justify-center text-slate-400 bg-white border border-slate-200/60 hover:text-brand-600 hover:border-brand-100 hover:bg-brand-50 rounded-2xl transition-all shadow-[0_2px_8px_-2px_rgba(0,0,0,0.02)] group">
              <Bell size={22} className="group-hover:scale-110 transition-transform" />
              <span className="absolute top-3 right-3 w-2.5 h-2.5 bg-rose-500 rounded-full ring-4 ring-white animate-pulse"></span>
            </button>
          </div>
        </header>

        {/* Dashboard Content Grid */}
        <main className="flex-1 overflow-auto p-6 lg:p-10">
          <div className="max-w-7xl mx-auto animate-in" style={{ animationDelay: '50ms' }}>
            {children}
          </div>
        </main>
      </div>

    </div>
  );
}