"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { createPortal } from "react-dom";

type MobileMenuLink = {
  href: string;
  label: string;
  isAnchor?: boolean;
};

type MobileMenuAction = {
  href: string;
  label: string;
};

export default function PublicMobileMenu({
  links,
  primaryAction,
  secondaryAction,
}: {
  links: MobileMenuLink[];
  primaryAction?: MobileMenuAction;
  secondaryAction?: MobileMenuAction;
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  useEffect(() => {
    const previousBodyOverflow = document.body.style.overflow;
    const previousHtmlOverflow = document.documentElement.style.overflow;

    document.body.style.overflow = isOpen ? "hidden" : previousBodyOverflow;
    document.documentElement.style.overflow = isOpen ? "hidden" : previousHtmlOverflow;

    return () => {
      document.body.style.overflow = previousBodyOverflow;
      document.documentElement.style.overflow = previousHtmlOverflow;
    };
  }, [isOpen]);

  const closeMenu = () => setIsOpen(false);

  const overlay = isOpen ? (
    <div className="fixed inset-0" style={{ zIndex: 9999 }}>
      <div className="absolute inset-0 bg-slate-950/35" onClick={closeMenu} />

      <div className="absolute inset-0 overflow-hidden bg-white">
        <div className="pointer-events-none absolute inset-0 [background:radial-gradient(700px_260px_at_0%_0%,rgba(20,184,166,0.1),transparent_65%),radial-gradient(700px_260px_at_100%_0%,rgba(15,118,110,0.08),transparent_60%)]" />

        <div className="relative mx-auto flex h-full w-full max-w-md flex-col px-4 pb-5 pt-5 sm:px-6">
          <div className="flex items-center justify-between rounded-2xl border border-brand-100 bg-white px-4 py-3 shadow-sm">
            <div>
              <p className="text-[11px] font-black tracking-widest text-slate-500">MENU</p>
              <p className="mt-0.5 text-sm font-extrabold text-slate-800">القائمة</p>
            </div>

            <button
              type="button"
              onClick={closeMenu}
              aria-label="إغلاق القائمة"
              className="flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-700 transition-colors hover:bg-slate-50"
            >
              <svg viewBox="0 0 24 24" fill="none" className="h-5 w-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                <path d="M6 6l12 12" />
                <path d="M18 6 6 18" />
              </svg>
            </button>
          </div>

          <nav className="mt-4 min-h-0 flex-1 overflow-y-auto rounded-3xl border border-brand-100 bg-white/95 p-3 shadow-[0_18px_40px_-30px_rgba(2,6,23,0.35)]">
            <div className="flex flex-col gap-2">
              {links.map((link) =>
                link.isAnchor ? (
                  <a
                    key={`${link.href}-${link.label}`}
                    href={link.href}
                    onClick={closeMenu}
                    className="rounded-2xl border border-brand-100 bg-white px-4 py-3.5 text-sm font-extrabold text-slate-700 transition-colors hover:bg-brand-50 hover:text-brand-700"
                  >
                    {link.label}
                  </a>
                ) : (
                  <Link
                    key={`${link.href}-${link.label}`}
                    href={link.href}
                    onClick={closeMenu}
                    className="rounded-2xl border border-brand-100 bg-white px-4 py-3.5 text-sm font-extrabold text-slate-700 transition-colors hover:bg-brand-50 hover:text-brand-700"
                  >
                    {link.label}
                  </Link>
                ),
              )}
            </div>
          </nav>

          <div className="mt-4 grid grid-cols-1 gap-2 rounded-2xl border border-brand-100 bg-white/95 p-3 shadow-sm">
            {secondaryAction && (
              <Link
                href={secondaryAction.href}
                onClick={closeMenu}
                className="rounded-xl border border-slate-200 bg-white px-4 py-3 text-center text-sm font-extrabold text-slate-700 transition-colors hover:bg-slate-50"
              >
                {secondaryAction.label}
              </Link>
            )}

            {primaryAction && (
              <Link
                href={primaryAction.href}
                onClick={closeMenu}
                className="rounded-xl bg-brand-600 px-4 py-3 text-center text-sm font-extrabold text-white transition-colors hover:bg-brand-700"
              >
                {primaryAction.label}
              </Link>
            )}
          </div>
        </div>
      </div>
    </div>
  ) : null;

  return (
    <div className="flex items-center gap-2 lg:hidden">
      <button
        type="button"
        onClick={() => setIsOpen(true)}
        aria-label="فتح القائمة"
        aria-expanded={isOpen}
        className="flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-700 transition-colors hover:bg-slate-50"
      >
        <svg viewBox="0 0 24 24" fill="none" className="h-5 w-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
          <path d="M4 7h16" />
          <path d="M4 12h16" />
          <path d="M4 17h16" />
        </svg>
      </button>
      {isMounted ? createPortal(overlay, document.body) : null}
    </div>
  );
}