"use client";

import { useMemo, useRef, useState } from "react";
import { EditorContent, useEditor } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Underline from "@tiptap/extension-underline";
import { TextStyleKit } from "@tiptap/extension-text-style";
import Highlight from "@tiptap/extension-highlight";
import TextAlign from "@tiptap/extension-text-align";
import Link from "@tiptap/extension-link";

import ResizableImage from "@/components/tiptap-resizable-image";

type RichTextEditorFieldProps = {
  name: string;
  initialValue?: string;
  placeholder?: string;
};

type EditorSelection = {
  from: number;
  to: number;
};

type ToolbarButtonProps = {
  label: string;
  active?: boolean;
  onClick: () => void;
};

function ToolbarButton({ label, active, onClick }: ToolbarButtonProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-lg border px-2.5 py-1.5 text-xs font-bold transition-colors ${
        active
          ? "border-brand-200 bg-brand-50 text-brand-700"
          : "border-slate-200 bg-white text-slate-700 hover:bg-slate-50"
      }`}
    >
      {label}
    </button>
  );
}

export default function RichTextEditorField({
  name,
  initialValue = "",
  placeholder = "اكتب الوصف...",
}: RichTextEditorFieldProps) {
  const normalizedInitialValue = useMemo(() => {
    const value = initialValue.trim();
    return value ? value : "<p></p>";
  }, [initialValue]);

  const [htmlValue, setHtmlValue] = useState(normalizedInitialValue);
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  const savedSelectionRef = useRef<EditorSelection | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const saveCurrentSelection = (selection?: EditorSelection) => {
    if (selection) {
      savedSelectionRef.current = selection;
      return;
    }

    if (!editor) {
      return;
    }

    const currentSelection = editor.state.selection;
    savedSelectionRef.current = {
      from: currentSelection.from,
      to: currentSelection.to,
    };
  };

  const restoreSavedSelection = () => {
    if (!editor || !savedSelectionRef.current) {
      return;
    }

    editor
      .chain()
      .focus()
      .setTextSelection(savedSelectionRef.current)
      .run();
  };

  const editor = useEditor({
    immediatelyRender: false,
    extensions: [
      StarterKit.configure({
        heading: {
          levels: [2, 3, 4],
        },
      }),
      Underline,
      TextStyleKit.configure({
        backgroundColor: false,
        fontFamily: false,
        fontSize: false,
        lineHeight: false,
      }),
      Highlight.configure({ multicolor: true }),
      ResizableImage.configure({
        inline: true,
        allowBase64: false,
      }),
      TextAlign.configure({
        types: ["heading", "paragraph"],
      }),
      Link.configure({
        openOnClick: false,
        autolink: true,
      }),
    ],
    content: normalizedInitialValue,
    editorProps: {
      attributes: {
        class:
          "rich-editor min-h-40 rounded-b-xl border border-t-0 border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 focus:outline-none",
      },
    },
    onUpdate: ({ editor: currentEditor }) => {
      setHtmlValue(currentEditor.getHTML());
    },
    onSelectionUpdate: ({ editor: currentEditor }) => {
      const selection = currentEditor.state.selection;
      savedSelectionRef.current = {
        from: selection.from,
        to: selection.to,
      };
    },
  });

  const setLink = () => {
    if (!editor) {
      return;
    }

    const previousUrl = editor.getAttributes("link").href as string | undefined;
    const url = window.prompt("أدخل رابط URL", previousUrl ?? "https://");

    if (url === null) {
      return;
    }

    if (!url.trim()) {
      editor.chain().focus().extendMarkRange("link").unsetLink().run();
      return;
    }

    editor.chain().focus().extendMarkRange("link").setLink({ href: url.trim() }).run();
  };

  const uploadImageFromFile = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const inputElement = event.currentTarget;
    const file = inputElement.files?.[0];

    if (!editor || !file) {
      return;
    }

    const formData = new FormData();
    formData.append("file", file);
    setIsUploadingImage(true);

    try {
      const response = await fetch("/api/uploads/image", {
        method: "POST",
        body: formData,
      });

      const data = (await response.json()) as { url?: string; message?: string };
      if (!response.ok || !data.url) {
        throw new Error(data.message ?? "فشل رفع الصورة.");
      }

      restoreSavedSelection();
      editor
        .chain()
        .focus()
        .setImage({
          src: data.url,
          alt: file.name,
          title: file.name,
        })
        .run();
    } catch (error) {
      const message = error instanceof Error ? error.message : "فشل رفع الصورة.";
      window.alert(message);
    } finally {
      setIsUploadingImage(false);
      inputElement.value = "";
    }
  };

  const openImagePicker = () => {
    saveCurrentSelection();
    fileInputRef.current?.click();
  };

  const setTextColor = (color: string) => {
    if (!editor) {
      return;
    }

    if (!editor.schema.marks.textStyle) {
      return;
    }

    restoreSavedSelection();
    editor.chain().focus().setColor(color).run();
  };

  return (
    <div>
      <div className="flex flex-wrap gap-1.5 rounded-t-xl border border-slate-200 bg-slate-50 p-2">
        <ToolbarButton
          label="B"
          active={editor?.isActive("bold")}
          onClick={() => editor?.chain().focus().toggleBold().run()}
        />
        <ToolbarButton
          label="I"
          active={editor?.isActive("italic")}
          onClick={() => editor?.chain().focus().toggleItalic().run()}
        />
        <ToolbarButton
          label="U"
          active={editor?.isActive("underline")}
          onClick={() => editor?.chain().focus().toggleUnderline().run()}
        />
        <ToolbarButton
          label="• قائمة"
          active={editor?.isActive("bulletList")}
          onClick={() => editor?.chain().focus().toggleBulletList().run()}
        />
        <ToolbarButton
          label="1. قائمة"
          active={editor?.isActive("orderedList")}
          onClick={() => editor?.chain().focus().toggleOrderedList().run()}
        />
        <ToolbarButton
          label="H2"
          active={editor?.isActive("heading", { level: 2 })}
          onClick={() => editor?.chain().focus().toggleHeading({ level: 2 }).run()}
        />
        <ToolbarButton
          label="H3"
          active={editor?.isActive("heading", { level: 3 })}
          onClick={() => editor?.chain().focus().toggleHeading({ level: 3 }).run()}
        />
        <ToolbarButton
          label="يمين"
          onClick={() => editor?.chain().focus().setTextAlign("right").run()}
        />
        <ToolbarButton
          label="وسط"
          onClick={() => editor?.chain().focus().setTextAlign("center").run()}
        />
        <ToolbarButton
          label="يسار"
          onClick={() => editor?.chain().focus().setTextAlign("left").run()}
        />
        <ToolbarButton label="رابط" active={editor?.isActive("link")} onClick={setLink} />
        <ToolbarButton
          label={isUploadingImage ? "جاري الرفع..." : "رفع صورة"}
          onClick={openImagePicker}
        />

        <label className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-2 py-1 text-xs font-bold text-slate-700">
          لون
          <input
            type="color"
            onClick={() => saveCurrentSelection()}
            onInput={(event) => setTextColor(event.currentTarget.value)}
            className="h-6 w-6 cursor-pointer rounded border border-slate-200"
            title="اختيار لون النص"
          />
        </label>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="image/png,image/jpeg,image/webp,image/gif"
        className="hidden"
        onChange={uploadImageFromFile}
      />

      <EditorContent editor={editor} />

      {!editor?.getText().trim() && (
        <p className="mt-2 text-xs font-semibold text-slate-400">{placeholder}</p>
      )}

      <input type="hidden" name={name} value={htmlValue} />
    </div>
  );
}
