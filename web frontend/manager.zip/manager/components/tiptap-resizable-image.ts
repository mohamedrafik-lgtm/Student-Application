import Image from "@tiptap/extension-image";
import { ReactNodeViewRenderer } from "@tiptap/react";

import TiptapImageNodeView from "@/components/tiptap-image-node-view";

const DEFAULT_IMAGE_WIDTH = "70%";

function normalizeImageWidth(value: unknown): string {
  const raw = typeof value === "string" ? value.trim() : "";

  if (!raw) {
    return DEFAULT_IMAGE_WIDTH;
  }

  if (/^[0-9]+(px|%)$/.test(raw)) {
    return raw;
  }

  const numeric = Number.parseFloat(raw);
  if (Number.isFinite(numeric) && numeric > 0) {
    return `${Math.min(Math.max(numeric, 10), 100)}%`;
  }

  return DEFAULT_IMAGE_WIDTH;
}

const ResizableImage = Image.extend({
  addAttributes() {
    return {
      ...this.parent?.(),
      width: {
        default: DEFAULT_IMAGE_WIDTH,
        parseHTML: (element) => {
          const widthFromDataset = element.getAttribute("data-width");
          const widthFromStyle = element.style.width;
          const widthFromAttribute = element.getAttribute("width");

          return normalizeImageWidth(widthFromDataset ?? widthFromStyle ?? widthFromAttribute);
        },
        renderHTML: (attributes) => {
          const width = normalizeImageWidth(attributes.width);

          return {
            "data-width": width,
            style: `display:block;margin:0.75rem auto;width:${width};max-width:100%;height:auto;`,
          };
        },
      },
    };
  },

  addNodeView() {
    return ReactNodeViewRenderer(TiptapImageNodeView);
  },
});

export default ResizableImage;
