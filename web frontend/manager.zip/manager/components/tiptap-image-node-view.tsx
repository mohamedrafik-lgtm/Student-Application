"use client";

import { useRef, useState } from "react";
import { NodeViewWrapper, type NodeViewProps } from "@tiptap/react";

type ResizeDirection = "left" | "right";

const MIN_WIDTH_PERCENT = 15;
const MAX_WIDTH_PERCENT = 100;

function normalizeWidthPercent(value: unknown): number {
  const raw = typeof value === "string" ? value.trim() : "";

  if (!raw) {
    return 70;
  }

  if (raw.endsWith("%")) {
    const parsed = Number.parseFloat(raw.slice(0, -1));
    if (Number.isFinite(parsed)) {
      return Math.min(Math.max(parsed, MIN_WIDTH_PERCENT), MAX_WIDTH_PERCENT);
    }
  }

  if (raw.endsWith("px")) {
    const parsed = Number.parseFloat(raw.slice(0, -2));
    if (Number.isFinite(parsed) && parsed > 0) {
      return Math.min(Math.max((parsed / 900) * 100, MIN_WIDTH_PERCENT), MAX_WIDTH_PERCENT);
    }
  }

  return 70;
}

export default function TiptapImageNodeView({
  node,
  selected,
  updateAttributes,
}: NodeViewProps) {
  const wrapperRef = useRef<HTMLDivElement | null>(null);
  const [isResizing, setIsResizing] = useState(false);

  const widthPercent = normalizeWidthPercent(node.attrs.width);

  const startResize = (event: React.MouseEvent<HTMLButtonElement>, direction: ResizeDirection) => {
    event.preventDefault();
    event.stopPropagation();

    const wrapper = wrapperRef.current;
    if (!wrapper) {
      return;
    }

    const proseMirror = wrapper.closest(".ProseMirror") as HTMLElement | null;
    const containerWidth = proseMirror?.clientWidth ?? wrapper.clientWidth;
    if (!containerWidth) {
      return;
    }

    const startX = event.clientX;
    const startWidth = wrapper.getBoundingClientRect().width;
    setIsResizing(true);

    const onMouseMove = (moveEvent: MouseEvent) => {
      const deltaX = moveEvent.clientX - startX;
      const resizedDelta = direction === "right" ? deltaX * 2 : -deltaX * 2;
      const nextWidthPx = Math.max(40, startWidth + resizedDelta);
      const nextPercent = Math.min(
        Math.max((nextWidthPx / containerWidth) * 100, MIN_WIDTH_PERCENT),
        MAX_WIDTH_PERCENT,
      );

      updateAttributes({
        width: `${nextPercent.toFixed(2)}%`,
      });
    };

    const onMouseUp = () => {
      setIsResizing(false);
      document.removeEventListener("mousemove", onMouseMove);
      document.removeEventListener("mouseup", onMouseUp);
    };

    document.addEventListener("mousemove", onMouseMove);
    document.addEventListener("mouseup", onMouseUp);
  };

  return (
    <NodeViewWrapper as="figure" className="my-3">
      <div
        ref={wrapperRef}
        className="group relative mx-auto w-fit max-w-full"
        style={{ width: `${widthPercent}%` }}
      >
        <img
          src={String(node.attrs.src ?? "")}
          alt={String(node.attrs.alt ?? "")}
          title={String(node.attrs.title ?? "")}
          className="block h-auto w-full rounded-lg border border-slate-200"
          draggable={false}
        />

        <button
          type="button"
          onMouseDown={(event) => startResize(event, "left")}
          className={`absolute top-1/2 -left-2 h-4 w-4 -translate-y-1/2 cursor-ew-resize rounded-full border border-brand-300 bg-brand-500 shadow transition-opacity ${
            selected || isResizing ? "opacity-100" : "opacity-0 group-hover:opacity-100"
          }`}
          aria-label="تغيير حجم الصورة من اليسار"
          contentEditable={false}
        />

        <button
          type="button"
          onMouseDown={(event) => startResize(event, "right")}
          className={`absolute top-1/2 -right-2 h-4 w-4 -translate-y-1/2 cursor-ew-resize rounded-full border border-brand-300 bg-brand-500 shadow transition-opacity ${
            selected || isResizing ? "opacity-100" : "opacity-0 group-hover:opacity-100"
          }`}
          aria-label="تغيير حجم الصورة من اليمين"
          contentEditable={false}
        />
      </div>
    </NodeViewWrapper>
  );
}
